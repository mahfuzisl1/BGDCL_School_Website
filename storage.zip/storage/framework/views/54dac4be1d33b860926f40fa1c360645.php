

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Informations</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <strong><?php echo e(ucfirst($section)); ?></strong>
                        <a href="<?php echo e(route('admin.informations.edit', $section)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    </div>
                    <div class="card-body">
                        <p><strong>Content:</strong></p>
                        <p><?php echo e(Str::limit(strip_tags($info['content']), 100, '...') ?? 'No content'); ?></p>

                        <p><strong>File:</strong></p>
                        <?php if($info['file_url']): ?>
                            <a href="<?php echo e($info['file_url']); ?>" target="_blank"><?php echo e($info['file']); ?></a>
                            <br>
                            <a href="<?php echo e(route('admin.informations.download', $section)); ?>" class="btn btn-sm btn-secondary mt-2">Download</a>
                        <?php else: ?>
                            <p>No file uploaded.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\TempAdmin\BGDCL_school_website\resources\views/admin/informations/index.blade.php ENDPATH**/ ?>