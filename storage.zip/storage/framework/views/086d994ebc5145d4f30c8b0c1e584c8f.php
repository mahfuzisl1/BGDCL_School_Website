<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title><?php echo $__env->yieldContent('title', 'Bakhrabad Gas Adarsha Bidyaloy'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        /* Custom fadeIn animation */
        @keyframes fadeIn {
            0% {opacity: 0;}
            100% {opacity: 1;}
        }
        .animate-fadeIn {
            animation: fadeIn 1s ease-in forwards;
        }
    </style>
    <style>
  [x-cloak] {
    display: none !important;
  }
</style>

    <!-- Font Awesome CDN -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
<!-- AOS CSS -->
<link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">


</head>
<body class="bg-white text-gray-800 font-sans min-h-screen flex flex-col">

    
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->yieldContent('fullscreen'); ?>

    
    <main class="flex-grow container mx-auto px-4 py-6 animate-fadeIn">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <footer class="bg-purple-100 text-purple-700 text-center py-6 mt-12">
        &copy; <?php echo e(date('Y')); ?> Bakhrabad Gas Adarsha Bidyaloy. All rights reserved.
    </footer>

    <script src="//unpkg.com/alpinejs" defer></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <!-- AOS JS -->
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    once: true, // animations happen only once
    duration: 800, // animation duration in ms
    offset: 100,   // how far before element is visible
  });
</script>


</body>


</html>
<?php /**PATH C:\Users\TempAdmin\BGDCL_school_website\resources\views/layouts/app.blade.php ENDPATH**/ ?>