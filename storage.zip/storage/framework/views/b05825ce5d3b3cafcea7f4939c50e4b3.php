

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit <?php echo e(ucfirst($section)); ?></h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.informations.update', $section)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group mb-3">
            <label for="content">Content (optional)</label>
            <textarea name="content" id="content" class="form-control" rows="6"><?php echo e(old('content', $content)); ?></textarea>
        </div>

        <div class="form-group mb-3">
            <label for="file">Upload File (image/pdf, max 5MB)</label>
            <input type="file" name="file" class="form-control">
            
            <?php if($fileUrl): ?>
                <p class="mt-2">
                    Current File: <a href="<?php echo e($fileUrl); ?>" target="_blank"><?php echo e($fileName); ?></a>
                </p>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-success">Save</button>
        <a href="<?php echo e(route('admin.informations.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\TempAdmin\BGDCL_school_website\resources\views/admin/informations/edit.blade.php ENDPATH**/ ?>