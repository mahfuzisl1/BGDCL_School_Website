<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Panel - <?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>

    <!-- Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />

    <style>
        .nav-link.active {
            font-weight: bold;
            color: #fff !important;
        }
    </style>
</head>
<body>
    <!-- Admin Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="fas fa-user-shield"></i> Admin Panel
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.notices.index')); ?>"><i class="fas fa-bell"></i> Notices</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.gallery.index')); ?>"><i class="fas fa-image"></i> Gallery</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.students.index')); ?>"><i class="fas fa-user-graduate"></i> Students</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.teachers.index')); ?>"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.staffs.index')); ?>"><i class="fas fa-people-roof"></i> Staffs</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.results.index')); ?>"><i class="fas fa-file-alt"></i> Results</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.examfiles.index')); ?>"><i class="fas fa-calendar-alt"></i> Exam Schedule</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.classmaterials.index')); ?>"><i class="fas fa-book"></i> Class Materials</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.informations.index')); ?>"><i class="fas fa-info-circle"></i> Informations</a></li>
                </ul>

                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-outline-light btn-sm" type="submit">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\TempAdmin\BGDCL_school_website\resources\views/layouts/adminapp.blade.php ENDPATH**/ ?>