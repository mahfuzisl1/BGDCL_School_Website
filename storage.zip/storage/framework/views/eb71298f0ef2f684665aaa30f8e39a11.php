

<?php $__env->startSection('content'); ?>
<section class="bg-white py-10">
    <div class="text-center mb-10">
        <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">
        🖼️ Photo Gallery
    </h1>
   <p class="mt-2 text-lg text-gray-500 italic">
        Capturing moments that matter.
    </p>
    
    <p class="mt-2 text-lg text-gray-500 italic">
        ......................................
    </p>
        <
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="rounded shadow-md overflow-hidden hover:shadow-xl transition-all bg-purple-50">
                    <a href="<?php echo e(asset('storage/' . $gallery->image_path)); ?>" target="_blank">
                        <img src="<?php echo e(asset('storage/' . $gallery->image_path)); ?>" alt="<?php echo e($gallery->title); ?>" class="w-full h-52 object-cover">
                    </a>
                    <div class="p-3">
                        <h3 class="text-lg font-semibold text-purple-900"><?php echo e($gallery->title); ?></h3>
                        <p class="text-sm text-gray-700"><?php echo e($gallery->caption); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-8">
            <?php echo e($galleries->links()); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\TempAdmin\BGDCL_school_website\resources\views/public/gallery/index.blade.php ENDPATH**/ ?>