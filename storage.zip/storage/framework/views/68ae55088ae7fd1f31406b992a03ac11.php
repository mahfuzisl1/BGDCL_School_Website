<?php if(isset($notices) && $notices->count()): ?>
<div class="notice-bar bg-gradient-to-r from-yellow-100 via-yellow-200 to-teal-100 text-black py-2 overflow-hidden flex items-center px-6 font-solaiman" style="box-shadow: inset 0 -3px 5px rgba(0,0,0,0.1); height: 45px;">
    <!-- Label -->
    <div class="notice-label mr-4 font-bold whitespace-nowrap select-none cursor-default" style="flex-shrink: 0;">
        📢 Notice
    </div>

    <!-- Scrolling area -->
    <div class="flex-1 overflow-hidden relative">
        <div class="scrolling-text whitespace-nowrap inline-block animate-scroll-left">
            <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('public.notices.show', $notice->id)); ?>" class="inline-block mx-4 hover:underline font-solaiman">
                    <?php echo e($notice->title); ?>

                </a>
                <span class="red-dot">•</span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('public.notices.show', $notice->id)); ?>" class="inline-block mx-4 hover:underline font-solaiman">
                    <?php echo e($notice->title); ?>

                </a>
                <span class="red-dot">•</span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>

<style>
.notice-bar {
    font-weight: 600;
    user-select: none;
    white-space: nowrap;
}

/* Add font family fallback here as well for safety */
.notice-bar, .notice-bar a {
    font-family: 'SolaimanLipi', 'Noto Sans Bengali', sans-serif;
}

.scrolling-text {
    animation: scroll-left 30s linear infinite;
    will-change: transform;
}

.scrolling-text:hover {
    animation-play-state: paused;
}

.red-dot {
    display: inline-block;
    margin: 0 8px;
    color: #e02424;
    font-weight: bold;
    user-select: none;
}

@keyframes scroll-left {
    0% {
        transform: translateX(0%);
    }
    100% {
        transform: translateX(-50%);
    }
}
</style>
<?php /**PATH C:\Users\TempAdmin\BGDCL_school_website\resources\views/partials/noticebar.blade.php ENDPATH**/ ?>