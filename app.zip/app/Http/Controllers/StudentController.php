<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class StudentController extends Controller
{
    // Display paginated list of students with search
    public function index(Request $request)
    {
        $query = Student::query();

        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function($q) use ($search) {
                $q->where('student_id', 'like', "%$search%")
                  ->orWhere('name', 'like', "%$search%")
                  ->orWhere('class', 'like', "%$search%")
                  ->orWhere('roll', 'like', "%$search%");
            });
        }

        $students = $query->orderBy('class')->orderBy('roll')->paginate(10);

        return view('admin.students.index', compact('students'));
    }

    // Show the form for creating a new student
    public function create()
    {
        return view('admin.students.create');
    }

    // Store a newly created student in database
    public function store(Request $request)
    {
        $validated = $request->validate([
            'student_id' => 'required|unique:students,student_id',
            'name' => 'required|string|max:255',
            'class' => 'required|integer|between:1,10',
            'section' => 'nullable|in:A,B,C,D',
            'roll' => 'nullable|integer',
            'admission_date' => 'nullable|date',
            'dob' => 'required|date',
            'gender' => 'required|in:Male,Female,Other',
            'blood_group' => 'nullable|string|max:10',
            'religion' => 'nullable|string|max:50',
            'nid_or_birth_cert' => 'nullable|string|max:100',
            'guardian_name' => 'nullable|string|max:255',
            'father_name' => 'required|string|max:255',
            'mother_name' => 'required|string|max:255',
            'mobile' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:255',
            'present_address' => 'nullable|string',
            'permanent_address' => 'nullable|string',
            'previous_school' => 'nullable|string|max:255',
            'group' => 'nullable|in:Science,Commerce,Arts',
            'exam_records' => 'nullable|string',
            'status' => 'nullable|in:Active,Inactive,Transferred,Dropped Out',
            'remarks' => 'nullable|string',
            'special_note' => 'nullable|string',

            // File uploads
            'photo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'transfer_certificate' => 'nullable|file|mimes:pdf,jpeg,png,jpg|max:2048',
            'birth_certificate' => 'nullable|file|mimes:pdf,jpeg,png,jpg|max:2048',
            'admission_form' => 'nullable|file|mimes:pdf,jpeg,png,jpg|max:2048',
            'additional_documents' => 'nullable|file|mimes:pdf,jpeg,png,jpg|max:2048',
        ]);

        // Handle file uploads
        $files = ['photo', 'transfer_certificate', 'birth_certificate', 'admission_form', 'additional_documents'];
        foreach ($files as $file) {
            if ($request->hasFile($file)) {
                $validated[$file] = $request->file($file)->store("students/$file", 'public');
            }
        }

        Student::create($validated);

        return redirect()->route('admin.students.index')->with('success', 'Student added successfully.');
    }

    // Show the specified student details
    public function show(Student $student)
    {
        return view('admin.students.show', compact('student'));
    }

    // Show the form for editing the specified student
    public function edit(Student $student)
    {
        return view('admin.students.edit', compact('student'));
    }

    // Update the specified student in database
    public function update(Request $request, Student $student)
    {
        $validated = $request->validate([
            'student_id' => 'required|unique:students,student_id,' . $student->id,
            'name' => 'required|string|max:255',
            'class' => 'required|integer|between:1,10',
            'section' => 'nullable|in:A,B,C,D',
            'roll' => 'nullable|integer',
            'admission_date' => 'nullable|date',
            'dob' => 'required|date',
            'gender' => 'required|in:Male,Female,Other',
            'blood_group' => 'nullable|string|max:10',
            'religion' => 'nullable|string|max:50',
            'nid_or_birth_cert' => 'nullable|string|max:100',
            'guardian_name' => 'nullable|string|max:255',
            'father_name' => 'required|string|max:255',
            'mother_name' => 'required|string|max:255',
            'mobile' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:255',
            'present_address' => 'nullable|string',
            'permanent_address' => 'nullable|string',
            'previous_school' => 'nullable|string|max:255',
            'group' => 'nullable|in:Science,Commerce,Arts',
            'exam_records' => 'nullable|string',
            'status' => 'nullable|in:Active,Inactive,Transferred,Dropped Out',
            'remarks' => 'nullable|string',
            'special_note' => 'nullable|string',

            // File uploads
            'photo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'transfer_certificate' => 'nullable|file|mimes:pdf,jpeg,png,jpg|max:2048',
            'birth_certificate' => 'nullable|file|mimes:pdf,jpeg,png,jpg|max:2048',
            'admission_form' => 'nullable|file|mimes:pdf,jpeg,png,jpg|max:2048',
            'additional_documents' => 'nullable|file|mimes:pdf,jpeg,png,jpg|max:2048',
        ]);

        // Handle file uploads and delete old files if replaced
        $files = ['photo', 'transfer_certificate', 'birth_certificate', 'admission_form', 'additional_documents'];
        foreach ($files as $file) {
            if ($request->hasFile($file)) {
                if ($student->$file && Storage::disk('public')->exists($student->$file)) {
                    Storage::disk('public')->delete($student->$file);
                }
                $validated[$file] = $request->file($file)->store("students/$file", 'public');
            }
        }

        $student->update($validated);

        return redirect()->route('admin.students.index')->with('success', 'Student updated successfully.');
    }

    // Remove the specified student from database
    public function destroy(Student $student)
    {
        // Delete uploaded files first
        $files = ['photo', 'transfer_certificate', 'birth_certificate', 'admission_form', 'additional_documents'];
        foreach ($files as $file) {
            if ($student->$file && Storage::disk('public')->exists($student->$file)) {
                Storage::disk('public')->delete($student->$file);
            }
        }

        $student->delete();

        return redirect()->route('admin.students.index')->with('success', 'Student deleted successfully.');
    }
}
