<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\ContactInfo;

class PublicContactInfoController extends Controller
{
    public function index()
    {
        $contact = ContactInfo::first();
        return view('public.contactinfo.index', compact('contact'));
    }
}
