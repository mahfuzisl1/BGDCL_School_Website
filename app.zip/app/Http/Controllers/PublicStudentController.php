<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class PublicStudentController extends Controller
{
    public function publicIndex(Request $request)
    {
        $query = Student::query();

        // Apply filters
        $filters = ['class', 'section', 'shift', 'group', 'roll', 'search', 'gender', 'religion', 'blood_group'];

        foreach ($filters as $filter) {
            if ($request->filled($filter)) {
                if ($filter === 'search') {
                    $query->where('name', 'like', '%' . $request->input('search') . '%');
                } else {
                    $query->where($filter, $request->input($filter));
                }
            }
        }

        // Clone query for chart data aggregation (efficient DB queries)
        $chartQuery = clone $query;

        $genderChart = $chartQuery->clone()->select('gender')
            ->groupBy('gender')
            ->selectRaw('gender, COUNT(*) as count')
            ->pluck('count', 'gender')->toArray();

        $religionChart = $chartQuery->clone()->select('religion')
            ->groupBy('religion')
            ->selectRaw('religion, COUNT(*) as count')
            ->pluck('count', 'religion')->toArray();

        $bloodGroupChart = $chartQuery->clone()->select('blood_group')
            ->groupBy('blood_group')
            ->selectRaw('blood_group, COUNT(*) as count')
            ->pluck('count', 'blood_group')->toArray();

        $classChart = $chartQuery->clone()->select('class')
            ->groupBy('class')
            ->selectRaw('class, COUNT(*) as count')
            ->pluck('count', 'class')->toArray();

        // Paginate results & keep query string for filters
        $students = $query->orderBy('class')->orderBy('roll')->orderBy('name')->paginate(10)->withQueryString();

        return view('public.students.index', compact(
            'students',
            'genderChart',
            'religionChart',
            'bloodGroupChart',
            'classChart'
        ));
    }
}
