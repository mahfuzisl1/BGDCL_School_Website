<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Gallery;

class PublicGalleryController extends Controller
{
    public function index()
    {
        $galleries = Gallery::latest()->paginate(12);
        return view('public.gallery.index', compact('galleries'));
    }

    public function show(Gallery $gallery)
    {
        return view('public.gallery.show', compact('gallery'));
    }
}
