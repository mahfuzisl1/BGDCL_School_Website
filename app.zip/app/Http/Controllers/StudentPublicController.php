<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class StudentPublicController extends Controller
{
    public function index(Request $request)
    {
        $query = Student::where('status', 'Active');

        // Filter Academic Year from admission_date year
        if ($request->filled('academic_year')) {
            $year = (int) $request->input('academic_year');
            $query->whereYear('admission_date', $year);
        }

        if ($request->filled('class')) {
            $query->where('class', $request->input('class'));
        }

        if ($request->filled('section')) {
            $query->where('section', $request->input('section'));
        }

        // Shift field not present, so ignoring

        if ($request->filled('group')) {
            $query->where('group', $request->input('group'));
        }

        if ($request->filled('roll')) {
            $query->where('roll', $request->input('roll'));
        }

        if ($request->filled('gender')) {
            $query->where('gender', $request->input('gender'));
        }

        if ($request->filled('religion')) {
            $query->where('religion', $request->input('religion'));
        }

        if ($request->filled('blood_group')) {
            $query->where('blood_group', $request->input('blood_group'));
        }

        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where('name', 'like', "%$search%");
        }

        // Sorting by class -> roll -> name
        $query->orderBy('class')->orderBy('roll')->orderBy('name');

        // Paginate with query string to maintain filters on page links
        $students = $query->paginate(15)->withQueryString();

        // Get filtered students for charts (no pagination)
        $filteredStudents = $query->get();

        // Group counts for charts
        $genderCounts = $filteredStudents->groupBy('gender')->map->count();
        $religionCounts = $filteredStudents->groupBy('religion')->map->count();
        $bloodGroupCounts = $filteredStudents->groupBy('blood_group')->map->count();
        $classCounts = $filteredStudents->groupBy('class')->map->count();

        // Dropdown options for filters
        $classes = range(1, 10);
        $sections = ['A', 'B', 'C', 'D'];
        $groups = ['Science', 'Commerce', 'Arts'];
        $genders = ['Male', 'Female', 'Other'];
        $religions = Student::select('religion')->distinct()->pluck('religion')->filter()->sort()->values();
        $bloodGroups = Student::select('blood_group')->distinct()->pluck('blood_group')->filter()->sort()->values();

        // Academic years (distinct years from admission_date)
        $academicYears = Student::selectRaw('YEAR(admission_date) as year')
            ->distinct()
            ->orderBy('year', 'desc')
            ->pluck('year')
            ->filter();

        return view('public.students.public_index', compact(
            'students',
            'genderCounts',
            'religionCounts',
            'bloodGroupCounts',
            'classCounts',
            'classes',
            'sections',
            'groups',
            'genders',
            'religions',
            'bloodGroups',
            'academicYears'
        ));
    }
}
