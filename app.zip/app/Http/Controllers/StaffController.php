<?php

namespace App\Http\Controllers;

use App\Models\Staff;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class StaffController extends Controller
{
    // List all staffs with search & pagination
    public function index(Request $request)
    {
        $query = Staff::query();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('designation', 'like', "%{$search}%")
                  ->orWhere('mobile_number', 'like', "%{$search}%")
                  ->orWhere('staff_id', 'like', "%{$search}%");
            });
        }

        $staffs = $query->latest()->paginate(10)->withQueryString();

        return view('admin.staffs.index', compact('staffs'));
    }

    // Show create form
    public function create()
    {
        return view('admin.staffs.create');
    }

    // Store new staff record
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'designation' => 'required|string|max:255',
            'gender' => 'required|string|max:20',
            'date_of_birth' => 'nullable|date',
            'blood_group' => 'nullable|string|max:10',
            'religion' => 'nullable|string|max:50',
            'nid_number' => 'nullable|string|max:100',
            'mobile_number' => 'required|string|max:20',
            'email' => 'nullable|email|max:255',
            'present_address' => 'nullable|string',
            'permanent_address' => 'nullable|string',
            'profile_photo' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'joining_date' => 'nullable|date',
            'employment_type' => 'nullable|string|max:50',
            'staff_id' => 'nullable|string|max:100',
            'experience' => 'nullable|string|max:255',
            'working_shift' => 'nullable|string|max:50',
            'job_description' => 'nullable|string',
            'status' => 'required|string|max:50',
            'nid_scan' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
            'joining_letter' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);

        // Handle uploads
        $profile_photo_path = null;
        if ($request->hasFile('profile_photo')) {
            $profile_photo_path = $request->file('profile_photo')->store('staffs/photos', 'public');
        }

        $nid_scan_path = null;
        if ($request->hasFile('nid_scan')) {
            $nid_scan_path = $request->file('nid_scan')->store('staffs/nid_scans', 'public');
        }

        $joining_letter_path = null;
        if ($request->hasFile('joining_letter')) {
            $joining_letter_path = $request->file('joining_letter')->store('staffs/joining_letters', 'public');
        }

        Staff::create([
            'name' => $validated['name'],
            'designation' => $validated['designation'],
            'gender' => $validated['gender'],
            'date_of_birth' => $validated['date_of_birth'],
            'blood_group' => $validated['blood_group'],
            'religion' => $validated['religion'],
            'nid_number' => $validated['nid_number'],
            'mobile_number' => $validated['mobile_number'],
            'email' => $validated['email'],
            'present_address' => $validated['present_address'],
            'permanent_address' => $validated['permanent_address'],
            'profile_photo' => $profile_photo_path,
            'joining_date' => $validated['joining_date'],
            'employment_type' => $validated['employment_type'],
            'staff_id' => $validated['staff_id'],
            'experience' => $validated['experience'],
            'working_shift' => $validated['working_shift'],
            'job_description' => $validated['job_description'],
            'status' => $validated['status'],
            'nid_scan' => $nid_scan_path,
            'joining_letter' => $joining_letter_path,
        ]);

        return redirect()->route('admin.staffs.index')->with('success', 'Staff added successfully.');
    }

    // Show edit form
    public function edit(Staff $staff)
    {
        return view('admin.staffs.edit', compact('staff'));
    }

    // Update staff record
    public function update(Request $request, Staff $staff)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'designation' => 'required|string|max:255',
            'gender' => 'required|string|max:20',
            'date_of_birth' => 'nullable|date',
            'blood_group' => 'nullable|string|max:10',
            'religion' => 'nullable|string|max:50',
            'nid_number' => 'nullable|string|max:100',
            'mobile_number' => 'required|string|max:20',
            'email' => 'nullable|email|max:255',
            'present_address' => 'nullable|string',
            'permanent_address' => 'nullable|string',
            'profile_photo' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'joining_date' => 'nullable|date',
            'employment_type' => 'nullable|string|max:50',
            'staff_id' => 'nullable|string|max:100',
            'experience' => 'nullable|string|max:255',
            'working_shift' => 'nullable|string|max:50',
            'job_description' => 'nullable|string',
            'status' => 'required|string|max:50',
            'nid_scan' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
            'joining_letter' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);

        // Handle file replacement and delete old files if new ones uploaded
        if ($request->hasFile('profile_photo')) {
            if ($staff->profile_photo) {
                Storage::disk('public')->delete($staff->profile_photo);
            }
            $profile_photo_path = $request->file('profile_photo')->store('staffs/photos', 'public');
        } else {
            $profile_photo_path = $staff->profile_photo;
        }

        if ($request->hasFile('nid_scan')) {
            if ($staff->nid_scan) {
                Storage::disk('public')->delete($staff->nid_scan);
            }
            $nid_scan_path = $request->file('nid_scan')->store('staffs/nid_scans', 'public');
        } else {
            $nid_scan_path = $staff->nid_scan;
        }

        if ($request->hasFile('joining_letter')) {
            if ($staff->joining_letter) {
                Storage::disk('public')->delete($staff->joining_letter);
            }
            $joining_letter_path = $request->file('joining_letter')->store('staffs/joining_letters', 'public');
        } else {
            $joining_letter_path = $staff->joining_letter;
        }

        $staff->update([
            'name' => $validated['name'],
            'designation' => $validated['designation'],
            'gender' => $validated['gender'],
            'date_of_birth' => $validated['date_of_birth'],
            'blood_group' => $validated['blood_group'],
            'religion' => $validated['religion'],
            'nid_number' => $validated['nid_number'],
            'mobile_number' => $validated['mobile_number'],
            'email' => $validated['email'],
            'present_address' => $validated['present_address'],
            'permanent_address' => $validated['permanent_address'],
            'profile_photo' => $profile_photo_path,
            'joining_date' => $validated['joining_date'],
            'employment_type' => $validated['employment_type'],
            'staff_id' => $validated['staff_id'],
            'experience' => $validated['experience'],
            'working_shift' => $validated['working_shift'],
            'job_description' => $validated['job_description'],
            'status' => $validated['status'],
            'nid_scan' => $nid_scan_path,
            'joining_letter' => $joining_letter_path,
        ]);

        return redirect()->route('admin.staffs.index')->with('success', 'Staff updated successfully.');
    }

    // Delete staff and related files
    public function destroy(Staff $staff)
    {
        if ($staff->profile_photo) {
            Storage::disk('public')->delete($staff->profile_photo);
        }
        if ($staff->nid_scan) {
            Storage::disk('public')->delete($staff->nid_scan);
        }
        if ($staff->joining_letter) {
            Storage::disk('public')->delete($staff->joining_letter);
        }

        $staff->delete();

        return redirect()->route('admin.staffs.index')->with('success', 'Staff deleted successfully.');
    }
}
