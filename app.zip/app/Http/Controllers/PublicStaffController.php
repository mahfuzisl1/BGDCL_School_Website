<?php

namespace App\Http\Controllers;

use App\Models\Staff;
use Illuminate\Http\Request;

class PublicStaffController extends Controller
{
    // Show paginated list of active staff members
    public function index(Request $request)
    {
        $query = Staff::query()->where('status', 'Active');

        // Optional search by name or designation
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('designation', 'like', "%{$search}%");
            });
        }

        $staffs = $query->orderBy('name')->paginate(12);

        return view('public.staffs.index', compact('staffs'));
    }

    // Show single staff profile
    public function show(Staff $staff)
    {
        if ($staff->status !== 'Active') {
            abort(404); // Only show active staff publicly
        }

        return view('public.staffs.show', compact('staff'));
    }
}
