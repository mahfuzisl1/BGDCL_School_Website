<?php

namespace App\Http\Controllers;

use App\Models\Result;
use Illuminate\Http\Request;

class PublicResultController extends Controller
{
    public function index(Request $request)
    {
        $query = Result::query();

        if ($request->filled('search')) {
            $query->where('class', 'like', "%{$request->search}%");
        }

        $results = $query->latest()->paginate(10)->withQueryString();

        // Add emoji for each result
        $results->getCollection()->transform(function ($item) {
            $emojiMap = [
                'Class 1' => '🐣',
                'Class 2' => '📘',
                'Class 3' => '📝',
                'Class 4' => '✏️',
                'Class 5' => '📚',
                'Class 6' => '📖',
                'Class 7' => '🧠',
                'Class 8' => '🧪',
                'Class 9' => '📐',
                'Class 10' => '🎓',
            ];

            $item->class_emoji = $emojiMap[$item->class] ?? '🏫';
            return $item;
        });

        return view('public.results.index', compact('results'));
    }
}
