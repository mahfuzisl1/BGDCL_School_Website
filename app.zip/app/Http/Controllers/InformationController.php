<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class InformationController extends Controller
{
    protected $storagePath = 'informations';

    protected $sections = ['introduction', 'history', 'letter', 'calendar', 'rules', 'committee'];

    protected $sectionTitles = [
        'introduction' => '🔰 পরিচিতি',
        'history'      => '📜 ঐতিহাসিক প্রেক্ষাপট',
        'letter'       => '✉️ অনুমোদন ও স্বীকৃতি পত্র',
        'rules'        => '📘 নিয়মাবলী ও বিধি-বিধান',
        'calendar'     => '🗓️ Academic Calendar',
        'committee'    => '👥 Managing Committee',
    ];

    // Admin index
    public function index()
    {
        $data = [];
        foreach ($this->sections as $section) {
            $fileName = $this->getFile($section);
            $data[$section] = [
                'content' => $this->getContent($section),
                'file' => $fileName,
                'file_url' => $fileName ? asset($this->storagePath . '/' . $fileName) : null,
            ];
        }

        return view('admin.informations.index', compact('data'));
    }

    // Admin edit
    public function edit($section)
    {
        if (!in_array($section, $this->sections)) {
            abort(404);
        }

        $content = $this->getContent($section);
        $fileName = $this->getFile($section);
        $fileUrl = $fileName ? asset($this->storagePath . '/' . $fileName) : null;

        return view('admin.informations.edit', compact('section', 'content', 'fileName', 'fileUrl'));
    }

    // Admin update
    public function update(Request $request, $section)
    {
        if (!in_array($section, $this->sections)) {
            abort(404);
        }

        $request->validate([
            'content' => 'nullable|string',
            'file' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120',
        ]);

        $this->saveContent($section, $request->content);

        if ($request->hasFile('file')) {
            $oldFile = $this->getFile($section);

            if ($oldFile && File::exists(public_path($this->storagePath . '/' . $oldFile))) {
                File::delete(public_path($this->storagePath . '/' . $oldFile));
            }

            $file = $request->file('file');
            $filename = $section . '_' . time() . '.' . $file->getClientOriginalExtension();

            if (!File::exists(public_path($this->storagePath))) {
                File::makeDirectory(public_path($this->storagePath), 0755, true);
            }

            $file->move(public_path($this->storagePath), $filename);

            $this->saveFileName($section, $filename);
        }

        return redirect()->route('admin.informations.index')->with('success', ucfirst($section) . ' updated successfully.');
    }

    // Admin file download
    public function downloadFile($section)
    {
        if (!in_array($section, $this->sections)) {
            abort(404);
        }

        $file = $this->getFile($section);

        if (!$file) {
            return back()->with('error', 'File not found.');
        }

        $path = public_path($this->storagePath . '/' . $file);

        if (!File::exists($path)) {
            return back()->with('error', 'File not found.');
        }

        return response()->download($path);
    }

    // Public index
    public function indexPublic()
    {
        $sections = $this->sections;
        $titles = $this->sectionTitles;

        return view('public.informations.index', compact('sections', 'titles'));
    }

    // Public show one section
    public function showPublic($section)
    {
        if (!in_array($section, $this->sections)) {
            abort(404);
        }

        $content = $this->getContent($section);
        $file = $this->getFile($section);
        $file_url = $file ? asset($this->storagePath . '/' . $file) : null;
        $titles = $this->sectionTitles;

        return view('public.informations.show', compact('section', 'content', 'file', 'file_url', 'titles'));
    }

    // Public file download
    public function publicDownload($section)
    {
        if (!in_array($section, $this->sections)) {
            abort(404);
        }

        $file = $this->getFile($section);

        if (!$file) {
            return redirect()->back()->with('error', 'File not found.');
        }

        $path = public_path($this->storagePath . '/' . $file);

        if (!File::exists($path)) {
            return redirect()->back()->with('error', 'File not found.');
        }

        return response()->download($path);
    }

    // Helpers
    protected function getContent($section)
    {
        $path = storage_path("app/informations/{$section}_content.txt");
        return File::exists($path) ? File::get($path) : null;
    }

    protected function saveContent($section, $content)
    {
        $path = storage_path("app/informations/{$section}_content.txt");
        File::put($path, $content ?? '');
    }

    protected function getFile($section)
    {
        $path = storage_path("app/informations/{$section}_file.txt");
        return File::exists($path) ? trim(File::get($path)) : null;
    }

    protected function saveFileName($section, $filename)
    {
        $path = storage_path("app/informations/{$section}_file.txt");
        File::put($path, $filename);
    }
}
