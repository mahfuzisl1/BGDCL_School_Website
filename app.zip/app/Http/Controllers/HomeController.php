<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Notice;
use App\Models\ContactInfo;
use App\Models\Gallery;
use Illuminate\Support\Carbon;



class HomeController extends Controller
{
    public function index()
    {
        $notices = Notice::where('status', 'Published')
            ->whereDate('publish_date', '<=', Carbon::now())
            ->orderBy('publish_date', 'desc')
            ->take(5)
            ->get();
       $galleryImages = Gallery::latest()->take(5)->get();
       $contact = ContactInfo::first();
       return view('home', compact('notices', 'galleryImages', 'contact'));
    }
}
