<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Illuminate\Http\Request;

class PublicExamFileController extends Controller
{
    protected $storagePath = 'exam_schedules';

    public function index(Request $request)
    {
        $directory = public_path($this->storagePath);

        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0755, true);
        }

        $files = collect(File::files($directory))->map(function ($file) {
            $filename = $file->getFilename();
            $parts = explode('_', $filename);
            return [
                'filename' => $filename,
                'class' => $parts[0] ?? 'Unknown',
                'uploaded_at' => date('Y-m-d H:i:s', $file->getMTime()),
                'extension' => $file->getExtension(),
                'url' => asset($this->storagePath . '/' . $filename),
            ];
        });

        if ($request->filled('search')) {
            $search = strtolower($request->search);
            $files = $files->filter(function ($file) use ($search) {
                return Str::contains(strtolower($file['filename']), $search);
            });
        }

        return view('public.examfiles.index', compact('files'));
    }
}
