<?php

namespace App\Http\Controllers;

use App\Models\Teacher;
use Illuminate\Http\Request;

class PublicTeacherController extends Controller
{
    // Show paginated list of teachers for public view
    public function index(Request $request)
    {
        $query = Teacher::query()->where('employment_status', 'Active');

        // Optional search by name or designation
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('full_name', 'like', "%{$search}%")
                  ->orWhere('designation', 'like', "%{$search}%");
            });
        }

        $teachers = $query->orderBy('full_name')->paginate(12);

        return view('public.teachers.index', compact('teachers'));
    }

    // Show single teacher detailed profile
    public function show(Teacher $teacher)
    {
        if ($teacher->employment_status !== 'Active') {
            abort(404); // Only show active teachers publicly
        }

        return view('public.teachers.show', compact('teacher'));
    }
}
