<?php

namespace App\Http\Controllers;

use App\Models\Result;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ResultController extends Controller
{
    public function index(Request $request)
    {
        $query = Result::query();

        if ($request->filled('search')) {
            $query->where('class', 'like', "%{$request->search}%")
                  ->orWhere('exam_type', 'like', "%{$request->search}%")
                  ->orWhere('year', 'like', "%{$request->search}%");
        }

        $results = $query->latest()->paginate(10)->withQueryString();

        return view('admin.results.index', compact('results'));
    }

    public function create()
    {
        return view('admin.results.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'class' => 'required|string|max:100',
            'exam_type' => 'nullable|string|max:100',
            'year' => 'required|digits:4',
            'file' => 'required|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);

        $file = $request->file('file');
        $fileType = $file->getClientOriginalExtension() === 'pdf' ? 'pdf' : 'image';
        $path = $file->store('results/files', 'public');

        Result::create([
            'class' => $validated['class'],
            'exam_type' => $validated['exam_type'],
            'year' => $validated['year'],
            'file_type' => $fileType,
            'file_path' => $path,
            'published_date' => now(),
        ]);

        return redirect()->route('admin.results.index')->with('success', 'Result uploaded successfully.');
    }

    public function edit(Result $result)
    {
        return view('admin.results.edit', compact('result'));
    }

    public function update(Request $request, Result $result)
    {
        $validated = $request->validate([
            'class' => 'required|string|max:100',
            'exam_type' => 'nullable|string|max:100',
            'year' => 'required|digits:4',
            'file' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);

        if ($request->hasFile('file')) {
            if ($result->file_path) {
                Storage::disk('public')->delete($result->file_path);
            }

            $file = $request->file('file');
            $fileType = $file->getClientOriginalExtension() === 'pdf' ? 'pdf' : 'image';
            $path = $file->store('results/files', 'public');

            $result->file_type = $fileType;
            $result->file_path = $path;
        }

        $result->update([
            'class' => $validated['class'],
            'exam_type' => $validated['exam_type'],
            'year' => $validated['year'],
        ]);

        return redirect()->route('admin.results.index')->with('success', 'Result updated successfully.');
    }

    public function destroy(Result $result)
    {
        if ($result->file_path) {
            Storage::disk('public')->delete($result->file_path);
        }

        $result->delete();

        return redirect()->route('admin.results.index')->with('success', 'Result deleted successfully.');
    }
}

