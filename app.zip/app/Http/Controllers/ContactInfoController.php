<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ContactInfo;

class ContactInfoController extends Controller
{
    public function index()
    {
        $contact = ContactInfo::first();
        return view('contactinfo.index', compact('contact'));
    }

    public function edit($id)
    {
        $contact = ContactInfo::findOrFail($id);
        return view('contactinfo.edit', compact('contact'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'primary_hotline' => 'nullable|string|max:255',
            'emergency_contact' => 'nullable|string|max:255',
            'office_number' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
            'office_hours' => 'nullable|string|max:255',
            'google_map_embed' => 'nullable|string',
        ]);

        $contact = ContactInfo::findOrFail($id);
        $contact->update($request->all());

        return redirect()->route('contactinfo.index')->with('success', 'Contact info updated successfully!');
    }
}

