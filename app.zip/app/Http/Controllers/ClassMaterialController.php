<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class ClassMaterialController extends Controller
{
    protected $storagePath = 'classmaterials'; // Will be under /public/classmaterials

    // === Admin panel list view ===
    public function index(Request $request)
    {
        $directory = public_path($this->storagePath);

        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0755, true);
        }

        $files = collect(File::files($directory))
            ->map(fn($file) => $file->getFilename())
            ->groupBy(fn($filename) => explode('_', $filename)[0] ?? 'Unknown');

        $materials = $files->map(function ($group, $class) use ($directory) {
            $routine = collect($group)->first(fn($f) => Str::contains(strtolower($f), 'routine'));
            $syllabus = collect($group)->first(fn($f) => Str::contains(strtolower($f), 'syllabus'));

            return [
                'class' => $class,
                'routine' => $routine,
                'routine_url' => $routine ? asset($this->storagePath . '/' . $routine) : null,
                'routine_uploaded_at' => $routine ? date('Y-m-d H:i:s', File::lastModified($directory . '/' . $routine)) : null,
                'syllabus' => $syllabus,
                'syllabus_url' => $syllabus ? asset($this->storagePath . '/' . $syllabus) : null,
                'syllabus_uploaded_at' => $syllabus ? date('Y-m-d H:i:s', File::lastModified($directory . '/' . $syllabus)) : null,
            ];
        })->values();

        if ($request->filled('search')) {
            $search = strtolower($request->search);
            $materials = $materials->filter(fn($item) => Str::contains(strtolower($item['class']), $search))->values();
        }

        return view('admin.classmaterials.index', compact('materials'));
    }

    public function create()
    {
        return view('admin.classmaterials.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'class' => 'required|string|max:50',
            'routine_file' => 'required|file|mimes:pdf,jpg,jpeg,png|max:2048',
            'syllabus_file' => 'required|file|mimes:pdf,jpg,jpeg,png|max:2048',
        ]);

        $class = $request->class;
        $directory = public_path($this->storagePath); // ✅ Save directly under /public/classmaterials/

        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0755, true);
        }

        if ($request->hasFile('routine_file')) {
            $routineFile = $request->file('routine_file');
            $routineFilename = $class . '_routine_' . time() . '.' . $routineFile->getClientOriginalExtension();
            $routineFile->move($directory, $routineFilename);
        }

        if ($request->hasFile('syllabus_file')) {
            $syllabusFile = $request->file('syllabus_file');
            $syllabusFilename = $class . '_syllabus_' . time() . '.' . $syllabusFile->getClientOriginalExtension();
            $syllabusFile->move($directory, $syllabusFilename);
        }

        return redirect()->route('admin.classmaterials.index')->with('success', 'Class materials uploaded successfully.');
    }

    public function edit($class)
    {
        $directory = public_path($this->storagePath);
        $routineFile = null;
        $syllabusFile = null;

        if (File::exists($directory)) {
            foreach (File::files($directory) as $file) {
                $filename = $file->getFilename();
                if (Str::startsWith($filename, $class . '_routine')) $routineFile = $filename;
                if (Str::startsWith($filename, $class . '_syllabus')) $syllabusFile = $filename;
            }
        }

        if (!$routineFile && !$syllabusFile) {
            return redirect()->route('admin.classmaterials.index')->with('error', 'Class materials not found.');
        }

        return view('admin.classmaterials.edit', compact('class', 'routineFile', 'syllabusFile'));
    }

    public function update(Request $request, $class)
    {
        $request->validate([
            'class' => 'required|string|max:50',
            'routine_file' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:2048',
            'syllabus_file' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:2048',
        ]);

        $directory = public_path($this->storagePath);

        $oldRoutineFile = null;
        $oldSyllabusFile = null;

        if (File::exists($directory)) {
            foreach (File::files($directory) as $file) {
                $filename = $file->getFilename();
                if (Str::startsWith($filename, $class . '_routine')) $oldRoutineFile = $filename;
                if (Str::startsWith($filename, $class . '_syllabus')) $oldSyllabusFile = $filename;
            }
        }

        $newClass = $request->class;

        if ($request->hasFile('routine_file')) {
            if ($oldRoutineFile) File::delete($directory . '/' . $oldRoutineFile);
            $routine = $request->file('routine_file');
            $routineFilename = $newClass . '_routine_' . time() . '.' . $routine->getClientOriginalExtension();
            $routine->move($directory, $routineFilename);
        } elseif ($class !== $newClass && $oldRoutineFile) {
            $ext = pathinfo($oldRoutineFile, PATHINFO_EXTENSION);
            $newName = $newClass . '_routine_' . time() . '.' . $ext;
            rename($directory . '/' . $oldRoutineFile, $directory . '/' . $newName);
        }

        if ($request->hasFile('syllabus_file')) {
            if ($oldSyllabusFile) File::delete($directory . '/' . $oldSyllabusFile);
            $syllabus = $request->file('syllabus_file');
            $syllabusFilename = $newClass . '_syllabus_' . time() . '.' . $syllabus->getClientOriginalExtension();
            $syllabus->move($directory, $syllabusFilename);
        } elseif ($class !== $newClass && $oldSyllabusFile) {
            $ext = pathinfo($oldSyllabusFile, PATHINFO_EXTENSION);
            $newName = $newClass . '_syllabus_' . time() . '.' . $ext;
            rename($directory . '/' . $oldSyllabusFile, $directory . '/' . $newName);
        }

        return redirect()->route('admin.classmaterials.index')->with('success', 'Class materials updated successfully.');
    }

    public function destroy($class)
    {
        $directory = public_path($this->storagePath);
        $deleted = false;

        if (File::exists($directory)) {
            foreach (File::files($directory) as $file) {
                $filename = $file->getFilename();
                if (Str::startsWith($filename, $class . '_routine') || Str::startsWith($filename, $class . '_syllabus')) {
                    File::delete($directory . '/' . $filename);
                    $deleted = true;
                }
            }
        }

        return back()->with($deleted ? 'success' : 'error', $deleted ? 'Deleted successfully.' : 'Class materials not found.');
    }

    public function download($filename)
    {
        $path = public_path($this->storagePath . '/' . $filename);
        return File::exists($path)
            ? response()->download($path)
            : back()->with('error', 'File not found.');
    }

    // === Public View ===
    public function publicIndex(Request $request)
    {
        $directory = public_path($this->storagePath);

        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0755, true);
        }

        $files = collect(File::files($directory))
            ->map(fn($file) => $file->getFilename())
            ->groupBy(fn($filename) => explode('_', $filename)[0] ?? 'Unknown');

        $materials = $files->map(function ($group, $class) use ($directory) {
            $routine = collect($group)->first(fn($f) => Str::contains(strtolower($f), 'routine'));
            $syllabus = collect($group)->first(fn($f) => Str::contains(strtolower($f), 'syllabus'));

            return [
                'class' => $class,
                'routine' => $routine,
                'routine_url' => $routine ? asset($this->storagePath . '/' . $routine) : null,
                'syllabus' => $syllabus,
                'syllabus_url' => $syllabus ? asset($this->storagePath . '/' . $syllabus) : null,
            ];
        })->values();

        if ($request->filled('search')) {
            $search = strtolower($request->search);
            $materials = $materials->filter(fn($item) => Str::contains(strtolower($item['class']), $search))->values();
        }

        return view('public.classmaterials.index', compact('materials'));
    }
}
