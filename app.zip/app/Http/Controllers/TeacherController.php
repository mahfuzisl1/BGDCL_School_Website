<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Teacher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TeacherController extends Controller
{
    public function index(Request $request)
    {
        $query = Teacher::query();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('full_name', 'like', "%{$search}%")
                  ->orWhere('teacher_id', 'like', "%{$search}%");
            });
        }

        $teachers = $query->latest()->paginate(10)->withQueryString();

        return view('admin.teachers.index', compact('teachers'));
    }

    public function create()
    {
        return view('admin.teachers.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'full_name' => 'required|string|max:255',
            'designation' => 'required|string|max:255',
            'department' => 'nullable|string|max:255',
            'subjects' => 'required|array|min:1',
            'subjects.*' => 'string|max:100',
            'gender' => 'required|string|max:10',
            'dob' => 'required|date',
            'religion' => 'required|string|max:50',
            'blood_group' => 'nullable|string|max:10',
            'joining_date' => 'required|date',
            'national_id' => 'required|string|max:50',
            'mobile' => 'required|string|max:20',
            'email' => 'nullable|email|max:255',
            'emergency_contact' => 'nullable|string|max:20',
            'present_address' => 'required|string',
            'permanent_address' => 'required|string',
            'highest_qualification' => 'required|string|max:255',
            'professional_degrees' => 'nullable|array',
            'professional_degrees.*' => 'string|max:100',
            'experience_years' => 'required|integer|min:0',
            'previous_institutions' => 'nullable|string',
            'special_skills' => 'nullable|string',
            'employment_status' => 'required|string|max:50',
            'remarks' => 'nullable|string',
            'is_class_teacher' => 'nullable|boolean',
            'class_teacher_of' => 'nullable|string|max:20',
            'profile_photo' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'cv_attachment' => 'nullable|file|mimes:pdf,doc,docx|max:5120',
            'certificates_attachment.*' => 'nullable|file|mimes:pdf,doc,docx|max:5120',
            'nid_attachment' => 'nullable|file|mimes:pdf|max:5120',
            'joining_letter' => 'nullable|file|mimes:pdf|max:5120',
            'other_documents' => 'nullable|file|mimes:pdf,zip|max:10240',
        ]);

        // Generate teacher_id: e.g. TCH2025001
        $latestId = Teacher::max('id') + 1;
        $year = now()->format('Y');
        $teacher_id = 'TCH' . $year . str_pad($latestId, 3, '0', STR_PAD_LEFT);

        // Handle uploads
        $profile_photo_path = null;
        if ($request->hasFile('profile_photo')) {
            $profile_photo_path = $request->file('profile_photo')->store('teachers/photos', 'public');
        }

        $cv_attachment_path = null;
        if ($request->hasFile('cv_attachment')) {
            $cv_attachment_path = $request->file('cv_attachment')->store('teachers/cv', 'public');
        }

        $certificates_paths = [];
        if ($request->hasFile('certificates_attachment')) {
            foreach ($request->file('certificates_attachment') as $file) {
                $certificates_paths[] = $file->store('teachers/certificates', 'public');
            }
        }

        $nid_attachment_path = null;
        if ($request->hasFile('nid_attachment')) {
            $nid_attachment_path = $request->file('nid_attachment')->store('teachers/nid', 'public');
        }

        $joining_letter_path = null;
        if ($request->hasFile('joining_letter')) {
            $joining_letter_path = $request->file('joining_letter')->store('teachers/joining_letters', 'public');
        }

        $other_documents_path = null;
        if ($request->hasFile('other_documents')) {
            $other_documents_path = $request->file('other_documents')->store('teachers/others', 'public');
        }

        Teacher::create([
            'teacher_id' => $teacher_id,
            'full_name' => $validated['full_name'],
            'designation' => $validated['designation'],
            'department' => $validated['department'],
            'subjects' => $validated['subjects'],
            'gender' => $validated['gender'],
            'dob' => $validated['dob'],
            'religion' => $validated['religion'],
            'blood_group' => $validated['blood_group'],
            'joining_date' => $validated['joining_date'],
            'national_id' => $validated['national_id'],
            'mobile' => $validated['mobile'],
            'email' => $validated['email'],
            'emergency_contact' => $validated['emergency_contact'],
            'present_address' => $validated['present_address'],
            'permanent_address' => $validated['permanent_address'],
            'highest_qualification' => $validated['highest_qualification'],
            'professional_degrees' => $validated['professional_degrees'] ?? null,
            'experience_years' => $validated['experience_years'],
            'previous_institutions' => $validated['previous_institutions'],
            'special_skills' => $validated['special_skills'],
            'employment_status' => $validated['employment_status'],
            'remarks' => $validated['remarks'],
            'is_class_teacher' => $validated['is_class_teacher'] ?? false,
            'class_teacher_of' => $validated['class_teacher_of'],
            'profile_photo' => $profile_photo_path,
            'cv_attachment' => $cv_attachment_path,
            'certificates_attachment' => $certificates_paths ? json_encode($certificates_paths) : null,
            'nid_attachment' => $nid_attachment_path,
            'joining_letter' => $joining_letter_path,
            'other_documents' => $other_documents_path,
        ]);

        return redirect()->route('admin.teachers.index')->with('success', 'Teacher added successfully.');
    }

    public function edit(Teacher $teacher)
    {
        return view('admin.teachers.edit', compact('teacher'));
    }

    public function update(Request $request, Teacher $teacher)
    {
        $validated = $request->validate([
            'full_name' => 'required|string|max:255',
            'designation' => 'required|string|max:255',
            'department' => 'nullable|string|max:255',
            'subjects' => 'required|array|min:1',
            'subjects.*' => 'string|max:100',
            'gender' => 'required|string|max:10',
            'dob' => 'required|date',
            'religion' => 'required|string|max:50',
            'blood_group' => 'nullable|string|max:10',
            'joining_date' => 'required|date',
            'national_id' => 'required|string|max:50',
            'mobile' => 'required|string|max:20',
            'email' => 'nullable|email|max:255',
            'emergency_contact' => 'nullable|string|max:20',
            'present_address' => 'required|string',
            'permanent_address' => 'required|string',
            'highest_qualification' => 'required|string|max:255',
            'professional_degrees' => 'nullable|array',
            'professional_degrees.*' => 'string|max:100',
            'experience_years' => 'required|integer|min:0',
            'previous_institutions' => 'nullable|string',
            'special_skills' => 'nullable|string',
            'employment_status' => 'required|string|max:50',
            'remarks' => 'nullable|string',
            'is_class_teacher' => 'nullable|boolean',
            'class_teacher_of' => 'nullable|string|max:20',
            'profile_photo' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'cv_attachment' => 'nullable|file|mimes:pdf,doc,docx|max:5120',
            'certificates_attachment.*' => 'nullable|file|mimes:pdf,doc,docx|max:5120',
            'nid_attachment' => 'nullable|file|mimes:pdf|max:5120',
            'joining_letter' => 'nullable|file|mimes:pdf|max:5120',
            'other_documents' => 'nullable|file|mimes:pdf,zip|max:10240',
        ]);

        // Handle uploads & delete old files if replaced

        // profile_photo
        if ($request->hasFile('profile_photo')) {
            if ($teacher->profile_photo) {
                Storage::disk('public')->delete($teacher->profile_photo);
            }
            $profile_photo_path = $request->file('profile_photo')->store('teachers/photos', 'public');
        } else {
            $profile_photo_path = $teacher->profile_photo;
        }

        // cv_attachment
        if ($request->hasFile('cv_attachment')) {
            if ($teacher->cv_attachment) {
                Storage::disk('public')->delete($teacher->cv_attachment);
            }
            $cv_attachment_path = $request->file('cv_attachment')->store('teachers/cv', 'public');
        } else {
            $cv_attachment_path = $teacher->cv_attachment;
        }

        // certificates_attachment (multiple)
        $certificates_paths = json_decode($teacher->certificates_attachment, true) ?? [];
        if ($request->hasFile('certificates_attachment')) {
            // Delete old files
            foreach ($certificates_paths as $oldFile) {
                Storage::disk('public')->delete($oldFile);
            }
            // Save new files
            $certificates_paths = [];
            foreach ($request->file('certificates_attachment') as $file) {
                $certificates_paths[] = $file->store('teachers/certificates', 'public');
            }
        }

        // nid_attachment
        if ($request->hasFile('nid_attachment')) {
            if ($teacher->nid_attachment) {
                Storage::disk('public')->delete($teacher->nid_attachment);
            }
            $nid_attachment_path = $request->file('nid_attachment')->store('teachers/nid', 'public');
        } else {
            $nid_attachment_path = $teacher->nid_attachment;
        }

        // joining_letter
        if ($request->hasFile('joining_letter')) {
            if ($teacher->joining_letter) {
                Storage::disk('public')->delete($teacher->joining_letter);
            }
            $joining_letter_path = $request->file('joining_letter')->store('teachers/joining_letters', 'public');
        } else {
            $joining_letter_path = $teacher->joining_letter;
        }

        // other_documents
        if ($request->hasFile('other_documents')) {
            if ($teacher->other_documents) {
                Storage::disk('public')->delete($teacher->other_documents);
            }
            $other_documents_path = $request->file('other_documents')->store('teachers/others', 'public');
        } else {
            $other_documents_path = $teacher->other_documents;
        }

        $teacher->update([
            'full_name' => $validated['full_name'],
            'designation' => $validated['designation'],
            'department' => $validated['department'],
            'subjects' => $validated['subjects'],
            'gender' => $validated['gender'],
            'dob' => $validated['dob'],
            'religion' => $validated['religion'],
            'blood_group' => $validated['blood_group'],
            'joining_date' => $validated['joining_date'],
            'national_id' => $validated['national_id'],
            'mobile' => $validated['mobile'],
            'email' => $validated['email'],
            'emergency_contact' => $validated['emergency_contact'],
            'present_address' => $validated['present_address'],
            'permanent_address' => $validated['permanent_address'],
            'highest_qualification' => $validated['highest_qualification'],
            'professional_degrees' => $validated['professional_degrees'] ?? null,
            'experience_years' => $validated['experience_years'],
            'previous_institutions' => $validated['previous_institutions'],
            'special_skills' => $validated['special_skills'],
            'employment_status' => $validated['employment_status'],
            'remarks' => $validated['remarks'],
            'is_class_teacher' => $validated['is_class_teacher'] ?? false,
            'class_teacher_of' => $validated['class_teacher_of'],
            'profile_photo' => $profile_photo_path,
            'cv_attachment' => $cv_attachment_path,
            'certificates_attachment' => $certificates_paths ? json_encode($certificates_paths) : null,
            'nid_attachment' => $nid_attachment_path,
            'joining_letter' => $joining_letter_path,
            'other_documents' => $other_documents_path,
        ]);

        return redirect()->route('admin.teachers.index')->with('success', 'Teacher updated successfully.');
    }

    public function destroy(Teacher $teacher)
    {
        // Delete all uploaded files
        if ($teacher->profile_photo) {
            Storage::disk('public')->delete($teacher->profile_photo);
        }
        if ($teacher->cv_attachment) {
            Storage::disk('public')->delete($teacher->cv_attachment);
        }
        if ($teacher->certificates_attachment) {
            foreach (json_decode($teacher->certificates_attachment, true) as $file) {
                Storage::disk('public')->delete($file);
            }
        }
        if ($teacher->nid_attachment) {
            Storage::disk('public')->delete($teacher->nid_attachment);
        }
        if ($teacher->joining_letter) {
            Storage::disk('public')->delete($teacher->joining_letter);
        }
        if ($teacher->other_documents) {
            Storage::disk('public')->delete($teacher->other_documents);
        }

        $teacher->delete();

        return redirect()->route('admin.teachers.index')->with('success', 'Teacher deleted successfully.');
    }
}
