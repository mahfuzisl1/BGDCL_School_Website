<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class ExamFileController extends Controller
{
    protected $storagePath = 'exam_schedules';

    public function index(Request $request)
    {
        $directory = public_path($this->storagePath);

        // ডিরেক্টরি না থাকলে তৈরি করবে
        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0755, true);
        }

        // ফাইলগুলো সংগ্রহ করে মাপ করবে
        $files = collect(File::files($directory))->map(function ($file) {
            $filename = $file->getFilename();
            $parts = explode('_', $filename);
            return [
                'filename' => $filename,
                'class' => $parts[0] ?? 'Unknown',
                'uploaded_at' => date('Y-m-d H:i:s', $file->getMTime()),
                'extension' => $file->getExtension(),
                'url' => asset($this->storagePath . '/' . $filename), // ফাইলের পূর্ণ URL
            ];
        });

        // সার্চ থাকলে ফিল্টার করবে
        if ($request->filled('search')) {
            $search = strtolower($request->search);
            $files = $files->filter(function ($file) use ($search) {
                return Str::contains(strtolower($file['filename']), $search);
            });
        }

        return view('admin.examfiles.index', compact('files'));
    }

    public function create()
    {
        return view('admin.examfiles.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'class' => 'required|string|max:50',
            'schedule_file' => 'required|file|mimes:pdf,jpg,jpeg,png|max:2048',
        ]);

        $file = $request->file('schedule_file');
        $filename = $request->class . '_' . time() . '.' . $file->getClientOriginalExtension();

        // ডিরেক্টরি না থাকলে তৈরি করবে
        if (!File::exists(public_path($this->storagePath))) {
            File::makeDirectory(public_path($this->storagePath), 0755, true);
        }

        $file->move(public_path($this->storagePath), $filename);

        return redirect()->route('admin.examfiles.index')->with('success', 'Exam schedule uploaded successfully.');
    }

    public function edit($filename)
    {
        return view('admin.examfiles.edit', compact('filename'));
    }

    public function update(Request $request, $filename)
    {
        $request->validate([
            'class' => 'required|string|max:50',
            'schedule_file' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:2048',
        ]);

        $oldPath = public_path($this->storagePath . '/' . $filename);

        if (!file_exists($oldPath)) {
            return redirect()->route('admin.examfiles.index')->with('error', 'Original file not found.');
        }

        $extension = pathinfo($filename, PATHINFO_EXTENSION);
        $newFilename = $request->class . '_' . time() . '.' . $extension;

        if ($request->hasFile('schedule_file')) {
            File::delete($oldPath);
            $request->file('schedule_file')->move(public_path($this->storagePath), $newFilename);
        } else {
            rename($oldPath, public_path($this->storagePath . '/' . $newFilename));
        }

        return redirect()->route('admin.examfiles.index')->with('success', 'Exam schedule updated.');
    }

    public function destroy($filename)
    {
        $path = public_path($this->storagePath . '/' . $filename);
        if (file_exists($path)) {
            unlink($path);
            return back()->with('success', 'File deleted successfully.');
        }

        return back()->with('error', 'File not found.');
    }
}   