<?php

namespace App\Http\Controllers;

use App\Models\Notice;
use Illuminate\Http\Request;

class PublicNoticeController extends Controller
{
    public function index(Request $request)
    {
        $query = Notice::query()
            ->whereRaw('LOWER(status) = ?', ['published'])  // case-insensitive status filter
            ->whereDate('publish_date', '<=', now());

        if ($request->has('search') && $request->search !== null) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%$search%")
                  ->orWhere('content', 'like', "%$search%");
            });
        }

        $notices = $query->orderByDesc('is_pinned')
                         ->orderByDesc('publish_date')
                         ->paginate(10);

        return view('public.notice.index', compact('notices'));
    }

    public function show(Notice $notice)
    {
        if (strtolower($notice->status) !== 'published' || $notice->publish_date > now()) {
            abort(404);
        }

        return view('public.notice.show', compact('notice'));
    }
}
