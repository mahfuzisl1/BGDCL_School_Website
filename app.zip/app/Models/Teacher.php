<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    use HasFactory;

    protected $fillable = [
        'teacher_id',
        'full_name',
        'designation',
        'department',
        'subjects',
        'gender',
        'dob',
        'religion',
        'blood_group',
        'joining_date',
        'national_id',
        'mobile',
        'email',
        'emergency_contact',
        'present_address',
        'permanent_address',
        'highest_qualification',
        'professional_degrees',
        'experience_years',
        'previous_institutions',
        'special_skills',
        'employment_status',
        'remarks',
        'is_class_teacher',
        'class_teacher_of',
        'profile_photo',
        'cv_attachment',
        'certificates_attachment',
        'nid_attachment',
        'joining_letter',
        'other_documents',
    ];

    protected $casts = [
        'subjects' => 'array',
        'professional_degrees' => 'array',
        'certificates_attachment' => 'array',
        'is_class_teacher' => 'boolean',
        'dob' => 'date',
        'joining_date' => 'date',
    ];
}
