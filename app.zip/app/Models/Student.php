<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    protected $fillable = [
        'student_id',
        'name',
        'class',
        'section',
        'roll',
        'admission_date',
        'dob',
        'gender',
        'blood_group',
        'religion',
        'nid_or_birth_cert',
        'guardian_name',
        'father_name',
        'mother_name',
        'mobile',
        'email',
        'present_address',
        'permanent_address',
        'previous_school',
        'transfer_certificate',
        'group',
        'exam_records',
        'photo',
        'birth_certificate',
        'admission_form',
        'additional_documents',
        'status',
        'remarks',
        'special_note',
    ];
}
