<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContactInfo extends Model
{
    protected $fillable = [
        'primary_hotline',
        'emergency_contact',
        'office_number',
        'email',
        'office_hours',
        'google_map_embed',
    ];
}
