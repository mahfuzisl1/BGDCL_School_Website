<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Result extends Model
{
    protected $fillable = [
        'class',
        'exam_type',
        'year',
        'file_type',
        'file_path',
        'published_date',
    ];

    protected $casts = [
        'published_date' => 'datetime',
    ];
}
