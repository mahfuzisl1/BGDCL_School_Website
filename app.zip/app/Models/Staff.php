<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use HasFactory;
    protected $table = 'staffs';
    protected $fillable = [
        'name',
        'designation',
        'gender',
        'date_of_birth',
        'blood_group',
        'religion',
        'nid_number',
        'mobile_number',
        'email',
        'present_address',
        'permanent_address',
        'profile_photo',
        'joining_date',
        'employment_type',
        'staff_id',
        'experience',
        'working_shift',
        'job_description',
        'status',
        'nid_scan',
        'joining_letter',
    ];

    protected $casts = [
        'date_of_birth' => 'date',
        'joining_date' => 'date',
        // যদি তোমার কোন ফিল্ড অ্যারে হয় তাহলে এখানে উল্লেখ করবে
        // যেমন: 'some_array_field' => 'array',
    ];
}
