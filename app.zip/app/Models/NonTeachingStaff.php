<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NonTeachingStaff extends Model
{
    use HasFactory;

    protected $table = 'non_teaching_staffs';

    protected $fillable = [
        // Personal Info
        'name',
        'designation',
        'gender',
        'date_of_birth',
        'blood_group',
        'religion',
        'nid_number',
        'mobile_number',
        'email',
        'present_address',
        'permanent_address',
        'profile_photo',

        // Official Info
        'joining_date',
        'employment_type',
        'staff_id',
        'experience',
        'working_shift',
        'job_description',
        'status',

        // Documents
        'nid_scan',
        'joining_letter',
    ];
}
