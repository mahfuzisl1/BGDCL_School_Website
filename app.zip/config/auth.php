<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Defaults
    |--------------------------------------------------------------------------
    |
    | এখানে ডিফল্ট guard এবং password reset broker সেট করা হয়। সাধারণত
    | এটা 'web' এবং 'users' হয়। তুমি চাইলে .env ফাইলে ওভাররাইড করতে পারো।
    |
    */

    'defaults' => [
        'guard' => env('AUTH_GUARD', 'web'),          // ডিফল্ট guard
        'passwords' => env('AUTH_PASSWORD_BROKER', 'users'),  // ডিফল্ট password broker
    ],

    /*
    |--------------------------------------------------------------------------
    | Authentication Guards
    |--------------------------------------------------------------------------
    |
    | Guard হল ইউজারের authentication মেকানিজম। যেমন session বা token ভিত্তিক।
    | এখানে 'web' এবং 'admin' guard ব্যবহার করা হয়েছে।
    |
    */

    'guards' => [
        'web' => [                   // সাধারন ইউজারের guard
            'driver' => 'session',
            'provider' => 'users',
        ],

        'admin' => [                 // Admin guard, আলাদা provider এর জন্য
            'driver' => 'session',
            'provider' => 'admins',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | User Providers
    |--------------------------------------------------------------------------
    |
    | Providers দিয়ে Laravel জানে ইউজারের ডাটা কিভাবে নিতে হবে। এখানে eloquent
    | ব্যবহার করা হয়েছে User এবং Admin মডেলের জন্য আলাদা আলাদা।
    |
    */

    'providers' => [
        'users' => [                 // সাধারন ইউজার
            'driver' => 'eloquent',
            'model' => App\Models\User::class,
        ],

        'admins' => [                // Admin ইউজার
            'driver' => 'eloquent',
            'model' => App\Models\Admin::class,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Resetting Passwords
    |--------------------------------------------------------------------------
    |
    | এখানে password reset টেবিল এবং অন্যান্য সেটিংস দেয়া হয় ইউজার ও অ্যাডমিনের জন্য।
    | যদি অ্যাডমিনদের জন্য আলাদা password reset দরকার হয়, তবে আলাদা টেবিল বানাতে হবে।
    |
    */

    'passwords' => [
        'users' => [
            'provider' => 'users',
            'table' => env('AUTH_PASSWORD_RESET_TOKEN_TABLE', 'password_reset_tokens'),  // ইউজার পাসওয়ার্ড রিসেট টোকেন টেবিল
            'expire' => 60,       // টোকেনের মেয়াদ (মিনিট)
            'throttle' => 60,
        ],

        'admins' => [
            'provider' => 'admins',
            'table' => 'admin_password_resets',   // অ্যাডমিনদের জন্য আলাদা টেবিল বানালে এই নাম ব্যবহার করো
            'expire' => 60,
            'throttle' => 60,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Password Confirmation Timeout
    |--------------------------------------------------------------------------
    |
    | পাসওয়ার্ড কনফার্মেশনের টাইমআউট, অর্থাৎ কত সেকেন্ড পর ইউজারকে আবার পাসওয়ার্ড দিতে হবে
    | নিশ্চিত করার জন্য।
    |
    */

    'password_timeout' => env('AUTH_PASSWORD_TIMEOUT', 10800),

];
