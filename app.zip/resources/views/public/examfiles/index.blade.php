je code dila emoji defualt gese ga r class 10 thik position eo ashe nai @extends('layouts.app') {{-- or layouts.public if separate --}}

@section('title', 'Exam Schedule')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Page Title -->
    <div class="text-center mb-10">
        <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">
            🗓️ Exam Schedule
        </h1>
        <p class="mt-2 text-lg text-gray-500 italic">
            Stay prepared with the latest exam dates and timings.
        </p>
    </div>

  

    @if($files->count())
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            @foreach ($files as $file)
                <div class="border rounded p-4 shadow hover:shadow-md">
                    <h2 class="text-xl font-semibold mb-2">
                        {{ $file['class_emoji'] ?? '🏫' }} Class: {{ $file['class'] }}
                    </h2>
                    <p class="text-sm mb-1">Uploaded: {{ \Carbon\Carbon::parse($file['uploaded_at'])->diffForHumans() }}</p>
                    <p class="text-sm mb-2">File Type: {{ strtoupper($file['extension']) }}</p>
                    <a href="{{ $file['url'] }}" target="_blank" class="text-blue-600 hover:underline">Download / View</a>
                </div>
            @endforeach
        </div>
    @else
        <p class="text-center text-gray-600">No files found.</p>
    @endif
</div>
@endsection  