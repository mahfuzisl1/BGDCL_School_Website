@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8">
    <!-- Page Title -->
<div class="text-center mb-10">
    <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">
        📞 Contact Information
    </h1>
    <p class="mt-2 text-lg text-gray-500 italic">
        Get in touch with us for any queries or support.
    </p>
</div>


    @if($contact)
        <div class="bg-white shadow rounded-lg p-6 space-y-4 text-gray-700">
            @if($contact->primary_hotline)
            <p><strong>Primary Hotline (24/7):</strong> {{ $contact->primary_hotline }}</p>
            @endif

            @if($contact->emergency_contact)
            <p><strong>Emergency Contact:</strong> {{ $contact->emergency_contact }}</p>
            @endif

            @if($contact->office_number)
            <p><strong>Office Number (Working Hours):</strong> {{ $contact->office_number }}</p>
            @endif

            @if($contact->email)
            <p><strong>Email:</strong> <a href="mailto:{{ $contact->email }}" class="text-purple-600 hover:underline">{{ $contact->email }}</a></p>
            @endif

            @if($contact->office_hours)
            <p><strong>Office Hours:</strong> {{ $contact->office_hours }}</p>
            @endif

            @if($contact->google_map_embed)
            <div class="mt-6">
                <h3 class="font-semibold mb-2">Location Map:</h3>
                <div class="aspect-w-16 aspect-h-9">
                    {!! $contact->google_map_embed !!}
                </div>
            </div>
            @endif
        </div>
    @else
        <p class="text-gray-600">No contact information available.</p>
    @endif
</div>
@endsection
