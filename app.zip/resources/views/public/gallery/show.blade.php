@extends('layouts.app')

@section('content')
<section class="bg-gradient-to-r from-sky-100 via-purple-100 to-yellow-100 py-12">
    <div class="container mx-auto px-4 max-w-4xl">
        <div class="bg-white rounded-2xl shadow-md overflow-hidden">
            <img src="{{ asset('storage/gallery/' . $gallery->image) }}" alt="{{ $gallery->title }}"
                 class="w-full object-cover h-[500px]">
            <div class="p-6">
                <h2 class="text-3xl font-bold text-purple-800">{{ $gallery->title }}</h2>
                <p class="text-gray-600 mt-2">{{ $gallery->description }}</p>
                <p class="text-sm text-gray-400 mt-4">Uploaded on {{ $gallery->created_at->format('F d, Y') }}</p>

                <a href="{{ route('public.gallery.index') }}"
                   class="inline-block mt-6 text-sm px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition">
                    ← Back to Gallery
                </a>
            </div>
        </div>
    </div>
</section>
@endsection
