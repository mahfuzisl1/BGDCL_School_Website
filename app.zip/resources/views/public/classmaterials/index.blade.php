@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6 max-w-4xl">
    <!-- Page Title -->
<div class="text-center mb-10">
    <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">
        📚 Class Materials
    </h1>
    <p class="mt-2 text-lg text-gray-500 italic">
        Resources to enhance your learning experience.
    </p>
</div>




    @if($materials->isEmpty())
        <p class="text-center text-gray-500">No class materials found.</p>
    @else
        <div class="space-y-6">
            @foreach($materials as $material)
                <div class="p-4 border rounded shadow">
                    <h2 class="text-xl font-semibold mb-2">Class {{ $material['class'] }}</h2>
                    <ul class="list-disc list-inside space-y-1">
                        <li>
                            Routine: 
                            @if($material['routine_url'])
                                <a href="{{ $material['routine_url'] }}" target="_blank" class="text-blue-600 hover:underline">View</a>
                            @else
                                <span class="text-gray-400 italic">Not available</span>
                            @endif
                        </li>
                        <li>
                            Syllabus: 
                            @if($material['syllabus_url'])
                                <a href="{{ $material['syllabus_url'] }}" target="_blank" class="text-blue-600 hover:underline">View</a>
                            @else
                                <span class="text-gray-400 italic">Not available</span>
                            @endif
                        </li>
                    </ul>
                </div>
            @endforeach
        </div>
    @endif
</div>
@endsection
