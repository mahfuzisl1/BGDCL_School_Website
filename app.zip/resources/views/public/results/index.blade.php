@extends('layouts.app')

@section('title', 'Results List')

@section('content')
<div class="container mx-auto px-4 py-6">
    <!-- Page Title -->

<!-- Page Title -->
<div class="text-center mb-10">
    <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">
        🏅 Exam Results
    </h1>
    <p class="mt-2 text-lg text-gray-500 italic">
        Check our academic performance and achievements.
    </p>
</div>



    <!-- Search Form -->
    <form method="GET" action="{{ route('public.results.index') }}" class="mb-6 flex justify-center gap-2">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Search by class..." class="border p-2 rounded-md w-64">
        <button type="submit" class="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700">Search</button>
    </form>

    @if ($results->count())
        <div class="grid md:grid-cols-2 gap-6">
            @foreach ($results as $result)
                <div class="border p-4 rounded-md shadow bg-white">
                    <p><strong>Class:</strong> {{ $result->class }}</p>
                    <p><strong>Exam Type:</strong> {{ $result->exam_type ?? 'N/A' }}</p>
                    <p><strong>Year:</strong> {{ $result->year }}</p>
                    <p><strong>Published Date:</strong> {{ $result->published_date->format('d M, Y') }}</p>

                    @if ($result->file_type === 'image')
                        <img src="{{ asset('storage/' . $result->file_path) }}" alt="Result Image" class="mt-2 max-w-full rounded">
                    @else
                        <iframe src="{{ asset('storage/' . $result->file_path) }}" class="w-full h-64 mt-2" frameborder="0"></iframe>
                    @endif

                    <a href="{{ asset('storage/' . $result->file_path) }}" download class="block mt-4 text-center bg-green-600 text-white py-2 rounded hover:bg-green-700">
                        Download
                    </a>
                </div>
            @endforeach
        </div>

        <div class="mt-6">
            {{ $results->links() }}
        </div>
    @else
        <p class="text-center text-red-600">No results found.</p>
    @endif
</div>
@endsection
