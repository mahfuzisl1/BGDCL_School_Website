@extends('layouts.app')

@section('title', 'স্টাফ তালিকা')

@section('content')
<div x-data="{ modalOpen: false, modalData: null }" class="container mx-auto px-4 py-8">

   <!-- Page Title -->
<div class="text-center mb-10">
    <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">
        👥 Our Dedicated Staff
    </h1>
    <p class="mt-2 text-lg text-gray-500 italic">
        Committed professionals supporting your learning journey.
    </p>
</div>


    <!-- Search Form -->
    <form method="GET" action="{{ route('public.staffs.index') }}" class="mb-6 max-w-md mx-auto">
        <input type="text" name="search" value="{{ request('search') }}"
            class="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
            placeholder="নাম বা পদবি দিয়ে খুঁজুন...">
    </form>

    <!-- Staff Cards (loop) -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @forelse($staffs as $staff)
        <div class="bg-white p-6 rounded-xl shadow hover:shadow-md transition duration-300 flex flex-col">

            <div class="flex items-center space-x-4">

                <!-- Profile Photo -->
                @if($staff->profile_photo)
                    <img src="{{ asset('storage/'.$staff->profile_photo) }}" alt="{{ $staff->name }}"
                        class="w-20 h-20 object-cover rounded-full border-2 border-purple-300 shadow">
                @else
                    <div
                        class="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center text-3xl text-gray-400 font-bold">
                        {{ strtoupper(substr($staff->name, 0, 1)) }}
                    </div>
                @endif

                <!-- Basic Info -->
                <div class="flex-1">
                    <h2 class="text-xl font-semibold text-purple-700">{{ $staff->name }}</h2>
                    <p class="text-gray-600">{{ $staff->designation }}</p>
                </div>

                <!-- Details Button -->
                <button
                    @click="
                        modalData = {
                            photo: '{{ $staff->profile_photo ? asset('storage/'.$staff->profile_photo) : '' }}',
                            name: '{{ addslashes($staff->name) }}',
                            designation: '{{ addslashes($staff->designation) }}',
                            gender: '{{ addslashes($staff->gender ?? 'N/A') }}',
                            dob: '{{ $staff->date_of_birth ? \Carbon\Carbon::parse($staff->date_of_birth)->format('d M, Y') : 'N/A' }}',
                            blood_group: '{{ addslashes($staff->blood_group ?? 'N/A') }}',
                            religion: '{{ addslashes($staff->religion ?? 'N/A') }}',
                            mobile: '{{ addslashes($staff->mobile_number ?? 'N/A') }}',
                            email: '{{ addslashes($staff->email ?? 'N/A') }}',
                            employment_type: '{{ addslashes($staff->employment_type ?? 'N/A') }}',
                            shift: '{{ addslashes($staff->working_shift ?? 'N/A') }}',
                            status: '{{ addslashes($staff->status ?? 'N/A') }}'
                        };
                        modalOpen = true
                    "
                    class="text-purple-600 hover:underline text-sm font-medium focus:outline-none"
                    type="button"
                >
                    বিস্তারিত
                </button>
            </div>
        </div>
        @empty
        <div class="col-span-full text-center text-gray-500">
            কোনো স্টাফ পাওয়া যায়নি।
        </div>
        @endforelse
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        {{ $staffs->withQueryString()->links() }}
    </div>

    <!-- Modal -->
    <div
        x-show="modalOpen"
        x-transition
        class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
        style="display: none;"
    >
        <div 
            @click.away="modalOpen = false" 
            class="bg-white rounded-lg max-w-md w-full p-6 relative shadow-lg text-center"
        >

            <button 
                @click="modalOpen = false" 
                class="absolute top-2 right-2 text-gray-500 hover:text-gray-700 text-xl font-bold"
                aria-label="Close modal"
            >&times;</button>

            <!-- Profile Photo -->
            <template x-if="modalData && modalData.photo">
                <img 
                    :src="modalData.photo" 
                    alt="" 
                    class="w-32 h-32 rounded-full mx-auto mb-4 object-cover border-4 border-purple-400 shadow-md"
                />
            </template>

            <h2 class="text-2xl font-bold text-purple-700 mb-4" x-text="modalData.name"></h2>

            <p><strong>পদবি:</strong> <span x-text="modalData.designation"></span></p>
            <p><strong>লিঙ্গ:</strong> <span x-text="modalData.gender"></span></p>
            <p><strong>জন্ম তারিখ:</strong> <span x-text="modalData.dob"></span></p>
            <p><strong>রক্তের গ্রুপ:</strong> <span x-text="modalData.blood_group"></span></p>
            <p><strong>ধর্ম:</strong> <span x-text="modalData.religion"></span></p>
            <p><strong>মোবাইল নম্বর:</strong> <span x-text="modalData.mobile"></span></p>
            <p><strong>ইমেইল:</strong> <span x-text="modalData.email"></span></p>
            <p><strong>চাকরির ধরণ:</strong> <span x-text="modalData.employment_type"></span></p>
            <p><strong>কর্মঘণ্টা/শিফট:</strong> <span x-text="modalData.shift"></span></p>
            <p><strong>স্ট্যাটাস:</strong>
                <span :class="modalData.status === 'Active' ? 'text-green-600' : 'text-red-600'" x-text="modalData.status"></span>
            </p>
        </div>
    </div>

</div>

<!-- Alpine.js CDN -->
<script src="//unpkg.com/alpinejs" defer></script>
@endsection
