@extends('layouts.app')

@section('title', $staff->full_name)

@section('content')
<div class="container mx-auto px-4 py-8 max-w-4xl">

    <a href="{{ route('staffs.index') }}" class="text-purple-600 hover:underline mb-6 inline-block">&larr; সব স্টাফে ফিরে যান</a>

    <div class="bg-white rounded-xl shadow-lg p-8 flex flex-col md:flex-row items-center md:items-start gap-8">

        <!-- Photo -->
        @if($staff->profile_photo)
            <img
                src="{{ asset('storage/'.$staff->profile_photo) }}"
                alt="{{ $staff->full_name }}"
                class="w-40 h-40 rounded-full object-cover border-4 border-purple-400 shadow-lg"
            />
        @else
            <div class="w-40 h-40 rounded-full bg-gray-200 flex items-center justify-center text-gray-400 text-6xl font-bold">
                {{ strtoupper(substr($staff->full_name, 0, 1)) }}
            </div>
        @endif

        <!-- Info -->
        <div class="flex-1 space-y-4">

            <h1 class="text-3xl font-bold text-purple-700">{{ $staff->full_name }}</h1>

            <div><strong>পদবি:</strong> {{ $staff->designation }}</div>
            <div><strong>লিঙ্গ:</strong> {{ $staff->gender }}</div>
            <div><strong>জন্ম তারিখ:</strong> {{ $staff->date_of_birth }}</div>
            <div><strong>রক্তের গ্রুপ:</strong> {{ $staff->blood_group }}</div>
            <div><strong>ধর্ম:</strong> {{ $staff->religion }}</div>

            <div><strong>মোবাইল নম্বর:</strong> {{ $staff->mobile_number }}</div>
            <div><strong>ইমেইল:</strong> {{ $staff->email }}</div>

            <div><strong>চাকরির ধরণ:</strong> {{ $staff->employment_type }}</div>
            <div><strong>কর্মঘণ্টা/শিফট:</strong> {{ $staff->working_shift }}</div>

            <div><strong>স্ট্যাটাস:</strong>
                <span class="{{ $staff->status === 'Active' ? 'text-green-600' : 'text-red-600' }}">
                    {{ $staff->status }}
                </span>
            </div>

        </div>
    </div>
</div>
@endsection
