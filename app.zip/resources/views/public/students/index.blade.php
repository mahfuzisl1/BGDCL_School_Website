@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8 font-sans">

    <!-- Title -->
   <div class="text-center mb-10">
    <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">
        🎓 Student Directory
    </h1>
    <p class="mt-2 text-lg text-gray-500 italic">
        Our students are our pride and future.
    </p>
</div>


    <!-- Filter Form -->
    <form method="GET" action="{{ route('public.students.index') }}" class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
        <input type="text" name="search" placeholder="Search by name" value="{{ request('search') }}"
            class="col-span-2 md:col-span-1 border border-purple-300 rounded-md p-3 focus:ring-2 focus:ring-purple-500" />

        <select name="class" class="border border-purple-300 rounded-md p-3 focus:ring-2 focus:ring-purple-500">
            <option value="">All Classes</option>
            @for ($i = 1; $i <= 10; $i++)
                <option value="{{ $i }}" {{ request('class') == $i ? 'selected' : '' }}>Class {{ $i }}</option>
            @endfor
        </select>

        <select name="section" class="border border-purple-300 rounded-md p-3 focus:ring-2 focus:ring-purple-500">
            <option value="">All Sections</option>
            @foreach(['A', 'B', 'C', 'D'] as $section)
                <option value="{{ $section }}" {{ request('section') == $section ? 'selected' : '' }}>{{ $section }}</option>
            @endforeach
        </select>

        <select name="shift" class="border border-purple-300 rounded-md p-3 focus:ring-2 focus:ring-purple-500">
            <option value="">All Shifts</option>
            @foreach(['Morning', 'Day', 'Evening'] as $shift)
                <option value="{{ $shift }}" {{ request('shift') == $shift ? 'selected' : '' }}>{{ $shift }}</option>
            @endforeach
        </select>

        <select name="group" class="border border-purple-300 rounded-md p-3 focus:ring-2 focus:ring-purple-500">
            <option value="">All Groups</option>
            @foreach(['Science', 'Commerce', 'Arts'] as $group)
                <option value="{{ $group }}" {{ request('group') == $group ? 'selected' : '' }}>{{ $group }}</option>
            @endforeach
        </select>

        <select name="gender" class="border border-purple-300 rounded-md p-3 focus:ring-2 focus:ring-purple-500">
            <option value="">All Genders</option>
            @foreach(['Male', 'Female', 'Other'] as $gender)
                <option value="{{ $gender }}" {{ request('gender') == $gender ? 'selected' : '' }}>{{ $gender }}</option>
            @endforeach
        </select>

        <select name="religion" class="border border-purple-300 rounded-md p-3 focus:ring-2 focus:ring-purple-500">
            <option value="">All Religions</option>
            @foreach(['Muslim', 'Hinduism', 'Christianity', 'Buddhism', 'Others'] as $religion)
                <option value="{{ $religion }}" {{ request('religion') == $religion ? 'selected' : '' }}>{{ $religion }}</option>
            @endforeach
        </select>

        <select name="blood_group" class="border border-purple-300 rounded-md p-3 focus:ring-2 focus:ring-purple-500">
            <option value="">All Blood Groups</option>
            @foreach(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as $bg)
                <option value="{{ $bg }}" {{ request('blood_group') == $bg ? 'selected' : '' }}>{{ $bg }}</option>
            @endforeach
        </select>

        <input type="text" name="roll" placeholder="Roll" value="{{ request('roll') }}"
            class="border border-purple-300 rounded-md p-3 focus:ring-2 focus:ring-purple-500" />

        <button type="submit"
            class="col-span-2 md:col-span-5 bg-purple-700 hover:bg-purple-800 text-white font-semibold rounded-md px-6 py-3 transition flex items-center justify-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L15 13.414V19a1 1 0 01-1.447.894l-4-2A1 1 0 019 17v-3.586L3.293 6.707A1 1 0 013 6V4z" />
            </svg>
            Filter
        </button>
    </form>

    <!-- Table -->
    <div class="overflow-x-auto shadow-lg rounded-xl border border-purple-200 mb-10 bg-white">
        <table class="min-w-full divide-y divide-purple-200 text-gray-800 text-sm">
            <thead class="bg-purple-100 text-purple-900 text-left uppercase tracking-wider">
                <tr>
                    <th class="px-6 py-3">Photo</th>
                    <th class="px-6 py-3">Name</th>
                    <th class="px-6 py-3">Class</th>
                    <th class="px-6 py-3">Roll</th>
                    <th class="px-6 py-3">Section</th>
                    <th class="px-6 py-3">Gender</th>
                    <th class="px-6 py-3">Group</th>
                    <th class="px-6 py-3">Religion</th>
                    <th class="px-6 py-3">Blood</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-purple-100">
                @forelse($students as $student)
                    <tr class="hover:bg-purple-50 transition duration-150">
                        <td class="px-6 py-3">
                            @if ($student->photo)
                                <img src="{{ asset('storage/' . $student->photo) }}" alt="{{ $student->name }}"
                                    class="w-16 h-16 object-cover rounded-full shadow-sm" />
                            @else
                                <div class="w-16 h-16 flex items-center justify-center bg-gray-100 rounded-full">
                                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M5.121 17.804A4 4 0 017 15h10a4 4 0 011.879.804M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                </div>
                            @endif
                        </td>
                        <td class="px-6 py-3 font-medium">{{ $student->name }}</td>
                        <td class="px-6 py-3">Class {{ $student->class }}</td>
                        <td class="px-6 py-3">{{ $student->roll }}</td>
                        <td class="px-6 py-3">{{ $student->section }}</td>
                        <td class="px-6 py-3">{{ $student->gender }}</td>
                        <td class="px-6 py-3">{{ $student->group }}</td>
                        <td class="px-6 py-3">{{ $student->religion }}</td>
                        <td class="px-6 py-3">{{ $student->blood_group }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="9" class="text-center py-8 text-purple-400 font-semibold">No students found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="flex justify-center mb-12">
        {{ $students->links('pagination::tailwind') }}
    </div>

    <!-- Charts -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-white p-6 rounded-lg shadow">
            <canvas id="genderChart"></canvas>
        </div>
        <div class="bg-white p-6 rounded-lg shadow">
            <canvas id="religionChart"></canvas>
        </div>
        <div class="bg-white p-6 rounded-lg shadow">
            <canvas id="bloodGroupChart"></canvas>
        </div>
        <div class="bg-white p-6 rounded-lg shadow">
            <canvas id="classChart"></canvas>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const genderData = @json($genderChart);
    const religionData = @json($religionChart);
    const bloodData = @json($bloodGroupChart);
    const classData = @json($classChart);

    function renderPieChart(ctxId, data, title) {
        const ctx = document.getElementById(ctxId).getContext('2d');
        return new Chart(ctx, {
            type: 'pie',
            data: {
                labels: Object.keys(data),
                datasets: [{
                    label: title,
                    data: Object.values(data),
                    backgroundColor: ['#a78bfa', '#f87171', '#60a5fa', '#facc15', '#34d399', '#fb923c']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: title,
                        font: { size: 18, weight: 'bold' }
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    function renderBarChart(ctxId, data, title) {
        const ctx = document.getElementById(ctxId).getContext('2d');
        return new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(data),
                datasets: [{
                    label: title,
                    data: Object.values(data),
                    backgroundColor: '#6b21a8'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: title,
                        font: { size: 18, weight: 'bold' }
                    },
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    renderPieChart('genderChart', genderData, 'Gender Distribution');
    renderPieChart('religionChart', religionData, 'Religion Distribution');
    renderPieChart('bloodGroupChart', bloodData, 'Blood Group Distribution');
    renderBarChart('classChart', classData, 'Class-wise Student Count');
</script>
@endsection
