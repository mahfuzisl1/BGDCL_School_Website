@extends('layouts.app')

@section('title', $teacher->full_name)

@section('content')
<div class="container mx-auto px-4 py-8 max-w-4xl">

    <a href="{{ route('public.teachers.index') }}" class="text-purple-600 hover:underline mb-6 inline-block">&larr; Back to Teachers</a>

    <div class="bg-white rounded-xl shadow-lg p-8 flex flex-col md:flex-row items-center md:items-start gap-8">

        <!-- Photo -->
        @if($teacher->profile_photo)
            <img
                src="{{ asset('storage/'.$teacher->profile_photo) }}"
                alt="{{ $teacher->full_name }}"
                class="w-40 h-40 rounded-full object-cover border-4 border-purple-400 shadow-lg"
            />
        @else
            <div class="w-40 h-40 rounded-full bg-gray-200 flex items-center justify-center text-gray-400 text-6xl font-bold">
                {{ strtoupper(substr($teacher->full_name, 0, 1)) }}
            </div>
        @endif

        <!-- Info -->
        <div class="flex-1 space-y-4">

            <h1 class="text-3xl font-bold text-purple-700">{{ $teacher->full_name }}</h1>
            <p class="text-lg italic text-gray-700">{{ $teacher->designation }}</p>

            @if($teacher->department)
                <p class="text-sm font-semibold text-purple-600">Department: {{ $teacher->department }}</p>
            @endif

            <p><strong>Mobile:</strong> {{ $teacher->mobile }}</p>
            @if($teacher->email)
                <p><strong>Email:</strong> <a href="mailto:{{ $teacher->email }}" class="text-purple-600 hover:underline">{{ $teacher->email }}</a></p>
            @endif
            @if($teacher->emergency_contact)
                <p><strong>Emergency Contact:</strong> {{ $teacher->emergency_contact }}</p>
            @endif

            @if($teacher->is_class_teacher && $teacher->class_teacher_of)
                <p><strong>Class Teacher of:</strong> {{ $teacher->class_teacher_of }}</p>
            @endif

            <p><strong>Gender:</strong> {{ $teacher->gender }}</p>
            <p><strong>Date of Birth:</strong> {{ $teacher->dob->format('d M, Y') }}</p>
            <p><strong>Religion:</strong> {{ $teacher->religion }}</p>
            <p><strong>Blood Group:</strong> {{ $teacher->blood_group ?? 'N/A' }}</p>

            <p><strong>Highest Qualification:</strong> {{ $teacher->highest_qualification }}</p>
            <p><strong>Professional Degrees:</strong> {{ $teacher->professional_degrees ? implode(', ', $teacher->professional_degrees) : 'N/A' }}</p>
            <p><strong>Experience Years:</strong> {{ $teacher->experience_years }}</p>
            <p><strong>Previous Institutions:</strong> {{ $teacher->previous_institutions ?? 'N/A' }}</p>
            <p><strong>Special Skills:</strong> {{ $teacher->special_skills ?? 'N/A' }}</p>

            <p><strong>Subjects:</strong> {{ $teacher->subjects ? implode(', ', $teacher->subjects) : 'N/A' }}</p>

            <p><strong>Employment Status:</strong>
                <span class="{{ $teacher->employment_status === 'Active' ? 'text-green-600' : 'text-red-600' }}">
                    {{ $teacher->employment_status }}
                </span>
            </p>
        </div>
    </div>
</div>
@endsection
