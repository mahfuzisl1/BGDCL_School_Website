@extends('layouts.app')

@section('title', 'Our Teachers')

@section('content')
<div class="container mx-auto px-4 py-12">

    <!-- Page Title -->
<div class="text-center mb-10">
    <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">
        🏫 Meet Our Teachers
    </h1>
    <p class="mt-2 text-lg text-gray-500 italic">
        Inspiring minds, shaping the future.
    </p>
</div>



    <!-- Search Form -->
    <form method="GET" action="{{ route('public.teachers.index') }}" class="max-w-md mx-auto mb-10">
        <input
            type="text"
            name="search"
            value="{{ request('search') }}"
            placeholder="🔍 Search by name or designation..."
            class="w-full border border-gray-300 rounded-lg px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400 shadow-sm"
        />
    </form>

    <!-- No Results -->
    @if($teachers->count() == 0)
        <p class="text-center text-gray-500 text-lg">🙁 No teachers found.</p>
    @else

        <!-- Teachers Grid -->
        <div class="grid gap-10 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">

            @foreach($teachers as $teacher)
                <a href="{{ route('public.teachers.show', $teacher->id) }}"
                   class="group bg-[#fefefe] rounded-xl shadow-md p-6 border border-gray-300 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">

                    <div class="flex flex-col items-center space-y-4">

                        <!-- Profile Photo -->
                        @if($teacher->profile_photo)
                            <img
                                src="{{ asset('storage/'.$teacher->profile_photo) }}"
                                alt="{{ $teacher->full_name }}"
                                class="w-32 h-32 rounded-full object-cover border-4 border-purple-300 shadow-sm"
                            />
                        @else
                            <div class="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-gray-400 text-2xl font-bold shadow-inner">
                                {{ strtoupper(substr($teacher->full_name,0,1)) }}
                            </div>
                        @endif

                        <!-- Name -->
                        <h2 class="text-lg font-semibold text-gray-900 group-hover:text-purple-700 transition-all duration-300">
                            {{ $teacher->full_name }}
                        </h2>

                        <!-- Designation -->
                        <p class="text-sm text-gray-600 italic">{{ $teacher->designation }}</p>

                        <!-- Department -->
                        @if($teacher->department)
                            <span class="text-xs text-purple-600 bg-purple-100 px-3 py-1 rounded-full font-medium">
                                {{ $teacher->department }}
                            </span>
                        @endif

                        <!-- Mobile -->
                        <p class="text-xs text-gray-700 flex items-center gap-1">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h2l3 7 7-14 3 7h2" />
                            </svg>
                            {{ $teacher->mobile }}
                        </p>

                        <!-- Class Teacher Badge -->
                        @if($teacher->is_class_teacher && $teacher->class_teacher_of)
                            <span class="inline-block mt-2 bg-purple-600 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-md animate-pulse">
                                Class Teacher: {{ $teacher->class_teacher_of }}
                            </span>
                        @endif
                    </div>
                </a>
            @endforeach
        </div>

        <!-- Pagination -->
        <div class="mt-12 text-center">
            {{ $teachers->withQueryString()->links() }}
        </div>
    @endif
</div>
@endsection
