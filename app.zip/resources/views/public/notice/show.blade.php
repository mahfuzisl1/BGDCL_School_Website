@extends('layouts.app')

@section('title', $notice->title . ' - Bakhrabad Gas Adarsha Bidyaloy')

@section('content')
<div class="container mx-auto px-4 py-8 max-w-3xl font-solaiman"> {{-- Add font-solaiman here --}}
    
    <a href="{{ route('public.notices.index') }}" class="text-purple-600 hover:underline mb-4 inline-block font-solaiman">&larr; Back to Notices</a>

    <h1 class="text-3xl font-bold text-purple-800 mb-4 font-solaiman">{{ $notice->title }}</h1>

    <p class="text-gray-600 mb-2 font-solaiman">Published on: {{ \Carbon\Carbon::parse($notice->publish_date)->format('d M, Y') }}</p>

    @if ($notice->is_pinned)
        <span class="inline-block bg-yellow-300 text-yellow-800 px-3 py-1 rounded text-sm font-semibold mb-6 font-solaiman">Pinned Notice</span>
    @endif

    <div class="prose max-w-none text-gray-800 mb-6 font-solaiman">
        {!! $notice->content !!}
    </div>

    @if ($notice->attachment)
        <div class="mt-6 font-solaiman">
            <h3 class="font-semibold text-purple-700 mb-2">Attachment:</h3>
            <a href="{{ asset('storage/' . $notice->attachment) }}" target="_blank" class="text-blue-600 hover:underline">
                Download Attachment
            </a>
        </div>
    @endif

</div>
@endsection
