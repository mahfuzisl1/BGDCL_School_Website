@extends('layouts.app')

@section('title', 'Notices - Bakhrabad Gas Adarsha Bidyaloy')

@section('content')
<div class="container mx-auto px-4 py-8 font-solaiman">  {{-- Add font-solaiman here --}}

    <!-- Page Title -->
<div class="text-center mb-10">
    <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">
        📰 Notice Board
    </h1>
    <p class="mt-2 text-lg text-gray-500 italic">
        Stay updated with the latest announcements and news.
    </p>
</div>


    {{-- Search Form --}}
    <form action="{{ route('public.notices.index') }}" method="GET" class="mb-6 font-solaiman">
        <input 
            type="text" 
            name="search" 
            value="{{ request('search') }}" 
            placeholder="Search notices..." 
            class="w-full md:w-1/2 p-2 border border-gray-300 rounded shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
        />
    </form>

    @if($notices->count() > 0)
        <ul class="space-y-6 font-solaiman">
            @foreach ($notices as $notice)
                <li class="p-4 bg-purple-50 rounded-lg shadow hover:shadow-md transition">
                    <a href="{{ route('public.notices.show', $notice) }}" class="block font-solaiman">
                        <h2 class="text-xl font-semibold text-purple-800 font-solaiman">{{ $notice->title }}</h2>
                        <p class="text-gray-700 mt-1 line-clamp-3 font-solaiman">{{ Str::limit(strip_tags($notice->content), 150) }}</p>
                        <div class="text-sm text-gray-500 mt-2 flex justify-between items-center font-solaiman">
                            <span>Published: {{ $notice->publish_date->format('d M, Y') }}</span>
                            @if ($notice->is_pinned)
                                <span class="inline-block bg-yellow-300 text-yellow-800 px-2 py-1 rounded text-xs font-semibold font-solaiman">Pinned</span>
                            @endif
                        </div>
                    </a>
                </li>
            @endforeach
        </ul>

        <div class="mt-8 font-solaiman">
            {{ $notices->withQueryString()->links() }}
        </div>
    @else
        <p class="text-gray-600 font-solaiman">No notices found.</p>
    @endif
</div>
@endsection
