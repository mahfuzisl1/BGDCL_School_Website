@extends('layouts.app')

@section('title', $titles[$section] ?? ucfirst($section))

@section('content')
<div class="container mx-auto p-6 max-w-4xl font-solaiman">

    <h1 class="text-4xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] text-center mb-6">
        {!! $titles[$section] ?? ucfirst($section) !!}
    </h1>

    @if ($content)
        <div class="prose max-w-none mb-6 font-solaiman">
            {!! nl2br(e($content)) !!}
        </div>
    @else
        <p class="text-center text-gray-500 font-solaiman">এই বিভাগের জন্য কোনো তথ্য পাওয়া যায়নি।</p>
    @endif

    @if ($file_url)
        <div class="text-center mt-8 font-solaiman">
            @php $ext = pathinfo($file_url, PATHINFO_EXTENSION); @endphp

            @if (in_array(strtolower($ext), ['pdf']))
                <iframe src="{{ $file_url }}" width="100%" height="600px" class="border rounded mb-4"></iframe>
            @elseif (in_array(strtolower($ext), ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp']))
                <img src="{{ $file_url }}" alt="{{ $section }} file preview" class="mx-auto rounded shadow mb-4" style="max-height:600px; max-width:100%;" >
            @elseif (in_array(strtolower($ext), ['txt', 'csv', 'log', 'md']))
                @php $textContent = file_get_contents(public_path($file_url)); @endphp
                <pre class="bg-gray-100 p-4 rounded mb-4 text-left whitespace-pre-wrap max-h-96 overflow-auto font-solaiman">{{ $textContent }}</pre>
            @else
                <p class="text-gray-600 italic mb-4 font-solaiman">এই ফাইল টাইপের জন্য প্রিভিউ সম্ভব নয়।</p>
            @endif

            <a href="{{ route('public.informations.publicDownload', $section) }}" 
               class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded font-semibold transition">
                সংযুক্ত ফাইল ডাউনলোড করুন
            </a>
        </div>
    @endif
</div>
@endsection
