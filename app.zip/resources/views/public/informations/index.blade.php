@extends('layouts.app')

@section('title', 'তথ্য বিভাগসমূহ')

@section('content')
<div class="container mx-auto p-6 max-w-4xl">

    <h1 class="text-5xl font-extrabold text-gray-800 drop-shadow-[2px_3px_1px_rgba(168,85,247,0.4)] font-[Poppins]">তথ্য বিভাগসমূহ</h1>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-6">
        @foreach ($titles as $section => $title)
            <a href="{{ route('public.informations.showPublic', $section) }}" 
               class="block bg-blue-600 hover:bg-blue-700 text-white rounded-lg p-6 text-center font-semibold transition">
                {!! $title !!}
            </a>
        @endforeach
    </div>

</div>
@endsection
