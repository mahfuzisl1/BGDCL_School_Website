<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Smart Topbar</title>

  <!-- ✅ Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- ✅ Font Awesome CDN (icons) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

  <!-- ✅ Smart Top Bar -->
  <div class="bg-black text-white text-sm">
    <div class="max-w-screen-xl mx-auto flex justify-between items-center px-4 py-2">
      
      <!-- Left Contact Info -->
      <div class="flex items-center space-x-6">
        <span class="flex items-center gap-2">
          <i class="fas fa-phone-alt text-white"></i>
          <span>01915929906</span>
        </span>
        <span class="flex items-center gap-2">
          <i class="fas fa-envelope text-white"></i>
          <span>bgab1995@gmail.com</span>
        </span>
      </div>

      <!-- Right ESTD Info -->
      <div class="flex items-center gap-2">
        <i class="fas fa-university text-white"></i>
        <span>ESTD: 1995</span>
      </div>

    </div>
  </div>

</body>
</html>






<nav
  class="bg-purple-950 text-white shadow-lg font-[SolaimanLipi] py-0"
  x-data="{ aboutOpen: false, instituteOpen: false, academicOpen: false, mobileOpen: false }"
  style="text-shadow: 0 1px 2px rgba(0,0,0,0.6);"
>
  <div class="container mx-auto px-4 flex justify-between items-center h-16">
    <!-- Logo + School Name -->
    <a href="{{ route('home') }}" class="flex items-center space-x-12 select-none">
      <img src="{{ asset('images/logo.png') }}" alt="Logo" class="h-12 w-12 object-contain" />
      <span class="text-lg font-semibold tracking-wide leading-tight">বাখরাবাদ গ্যাস আদর্শ বিদ্যালয়</span>
    </a>

    <!-- Desktop Menu -->
    <div class="hidden md:flex items-center space-x-5 text-sm font-medium">
      <!-- About Us Dropdown -->
      <div class="relative" @click.outside="aboutOpen = false">
        <button
          @click="aboutOpen = !aboutOpen"
          class="hover:text-yellow-400 transition flex items-center space-x-1 px-2 py-1 rounded-md shadow-sm shadow-black/50"
        >
          <span>About Us</span>
          <svg class="w-4 h-4 mt-1" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div
          x-show="aboutOpen"
          x-transition
          x-cloak
          class="absolute bg-gray-900 text-yellow-300 shadow-2xl rounded-md mt-2 w-44 z-50 ring-2 ring-yellow-400 ring-opacity-60"
        >
          <a href="{{ route('public.informations.showPublic', 'introduction') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Introduction</a>
          <a href="{{ route('public.informations.showPublic', 'history') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">History</a>
          <a href="{{ route('public.informations.showPublic', 'letter') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Acceptance & Acknowledgement</a>
        </div>
      </div>

      <!-- Institute Info Dropdown -->
      <div class="relative" @click.outside="instituteOpen = false">
        <button
          @click="instituteOpen = !instituteOpen"
          class="hover:text-yellow-400 transition flex items-center space-x-1 px-2 py-1 rounded-md shadow-sm shadow-black/50"
        >
          <span>Institute Info</span>
          <svg class="w-4 h-4 mt-1" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div
          x-show="instituteOpen"
          x-transition
          x-cloak
          class="absolute bg-gray-900 text-yellow-300 shadow-2xl rounded-md mt-2 w-56 z-50 ring-2 ring-yellow-400 ring-opacity-60"
        >
          <a href="{{ route('public.teachers.index') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Teachers</a>
          <a href="{{ route('public.students.index') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Students</a>
          <a href="{{ route('public.informations.showPublic', 'committee') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Managing Committee</a>
          <a href="{{ route('public.staffs.index') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Staffs</a>
          <a href="{{ route('public.gallery.index') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Gallery</a>
          <a href="{{ route('public.informations.showPublic', 'rules') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Rules & Regulation</a>
          <a href="#" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Admission Info</a>
        </div>
      </div>

      <!-- Academic Info Dropdown -->
      <div class="relative" @click.outside="academicOpen = false">
        <button
          @click="academicOpen = !academicOpen"
          class="hover:text-yellow-400 transition flex items-center space-x-1 px-2 py-1 rounded-md shadow-sm shadow-black/50"
        >
          <span>Academic Info</span>
          <svg class="w-4 h-4 mt-1" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div
          x-show="academicOpen"
          x-transition
          x-cloak
          class="absolute bg-gray-900 text-yellow-300 shadow-2xl rounded-md mt-2 w-52 z-50 ring-2 ring-yellow-400 ring-opacity-60"
        >
          <a href="{{ route('public.classmaterials.index') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Class Routine & Syllabus </a>
          <a href="{{ route('public.examfiles.index') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Exam Schedule" </a>
          <a href="{{ route('public.results.index') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Exam Results</a>
          <a href="{{ route('public.informations.showPublic', 'calendar') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Academic Calendar</a>
        </div>
      </div>

      <!-- Static Links -->
      <a href="{{ route('public.notices.index') }}" class="hover:text-yellow-400 transition px-2 py-1 rounded-md shadow-sm shadow-black/50">Notices</a>
      <a href="{{ route('public.gallery.index') }}" class="hover:text-yellow-400 transition px-2 py-1 rounded-md shadow-sm shadow-black/50">Gallery</a>
      <a href="{{ route('public.contactinfo.index') }}" class="hover:text-yellow-400 transition px-2 py-1 rounded-md shadow-sm shadow-black/50">Contact</a>

      <!-- Admin Login -->
      <a
        href="{{ route('admin.login') }}"
        class="bg-yellow-400 text-purple-900 font-semibold px-4 py-1 rounded-lg hover:bg-yellow-300 shadow-md shadow-yellow-500/50 transition"
      >
        Admin Login
      </a>
    </div>

    <!-- Mobile Hamburger -->
    <div class="md:hidden">
      <button @click="mobileOpen = !mobileOpen" aria-label="Toggle menu" type="button" class="focus:outline-none">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-white drop-shadow-lg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d="M4 8h16M4 16h16" />
        </svg>
      </button>
    </div>
  </div>

  <!-- Mobile Menu -->
  <div
    x-show="mobileOpen"
    x-transition
    x-cloak
    class="md:hidden bg-gray-900 text-yellow-300 px-4 py-3 space-y-2 rounded-b-lg shadow-inner shadow-black/70"
  >
    <div>
      <span class="block font-semibold border-b border-yellow-400 pb-1 mb-2">About Us</span>
      <a href="{{ route('public.informations.showPublic', 'introduction') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Introduction</a>
      <a href="{{ route('public.informations.showPublic', 'history') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">History</a>
      <a href="{{ route('public.informations.showPublic', 'letter') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Recognition Letter</a>
    </div>
    <div>
      <span class="block font-semibold border-b border-yellow-400 pb-1 mb-2">Institute Info</span>
      <a href="{{ route('public.teachers.index') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Teachers</a>
      <a href="{{ route('public.students.index') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Students</a>
      <a href="{{ route('public.informations.showPublic', 'committee') }}" class="block px-4 py-2 hover:bg-gray-800 hover:text-yellow-400 transition">Managing Committee</a>
      <a href="{{ route('public.staffs.index') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Staffs</a>
      <a href="{{ route('public.gallery.index') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Gallery</a>
      <a href="{{ route('public.informations.showPublic', 'rules') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Rules & Regulation</a>
      <a href="#" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Admission Info</a>
    </div>
    <div>
      <span class="block font-semibold border-b border-yellow-400 pb-1 mb-2">Academic Info</span>
      <a href="{{ route('public.classmaterials.index') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Class Routine & Syllabus</a>
      <a href="{{ route('public.results.index') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Exam Results</a>
      <a href="{{ route('public.informations.showPublic', 'calendar') }}" class="block pl-4 py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Academic Calendar</a>
    </div>
    <a href="{{ route('public.notices.index') }}" class="block py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Notices</a>
    <a href="{{ route('public.gallery.index') }}" class="block py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Gallery</a>
    <a href="{{ route('public.contactinfo.index') }}" class="block py-1 hover:bg-gray-800 hover:text-yellow-400 transition rounded">Contact</a>
    <a
      href="{{ route('admin.login') }}"
      class="block bg-yellow-400 text-purple-900 font-semibold px-4 py-2 rounded-lg hover:bg-yellow-300 shadow-md shadow-yellow-500/50 transition mt-2"
    >
      Admin Login
    </a>
  </div>
</nav>
