{{-- resources/views/partials/noticeboard.blade.php --}}

<div class="bg-white shadow-md rounded p-4">
    <h2 class="text-xl font-bold mb-4">📌 Notice Board</h2>

    @if(isset($notices) && $notices->count())
        <ul class="list-disc pl-6 space-y-2">
            @foreach($notices as $notice)
                <li>
                    <strong>{{ $notice->title }}</strong>
                    <br>
                    <small class="text-gray-500">{{ \Carbon\Carbon::parse($notice->publish_date)->format('d M Y') }}</small>
                </li>
            @endforeach
        </ul>
    @else
        <p class="text-gray-500">No notices available.</p>
    @endif
</div>
