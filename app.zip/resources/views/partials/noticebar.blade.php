@if(isset($notices) && $notices->count())
<div class="notice-bar bg-gradient-to-r from-yellow-100 via-yellow-200 to-teal-100 text-black py-2 overflow-hidden flex items-center px-6 font-solaiman" style="box-shadow: inset 0 -3px 5px rgba(0,0,0,0.1); height: 45px;">
    <!-- Label -->
    <div class="notice-label mr-4 font-bold whitespace-nowrap select-none cursor-default" style="flex-shrink: 0;">
        📢 Notice
    </div>

    <!-- Scrolling area -->
    <div class="flex-1 overflow-hidden relative">
        <div class="scrolling-text whitespace-nowrap inline-block animate-scroll-left">
            @foreach($notices as $notice)
                <a href="{{ route('public.notices.show', $notice->id) }}" class="inline-block mx-4 hover:underline font-solaiman">
                    {{ $notice->title }}
                </a>
                <span class="red-dot">•</span>
            @endforeach

            {{-- Clone once more for seamless infinite loop --}}
            @foreach($notices as $notice)
                <a href="{{ route('public.notices.show', $notice->id) }}" class="inline-block mx-4 hover:underline font-solaiman">
                    {{ $notice->title }}
                </a>
                <span class="red-dot">•</span>
            @endforeach
        </div>
    </div>
</div>
@endif

<style>
.notice-bar {
    font-weight: 600;
    user-select: none;
    white-space: nowrap;
}

/* Add font family fallback here as well for safety */
.notice-bar, .notice-bar a {
    font-family: 'SolaimanLipi', 'Noto Sans Bengali', sans-serif;
}

.scrolling-text {
    animation: scroll-left 30s linear infinite;
    will-change: transform;
}

.scrolling-text:hover {
    animation-play-state: paused;
}

.red-dot {
    display: inline-block;
    margin: 0 8px;
    color: #e02424;
    font-weight: bold;
    user-select: none;
}

@keyframes scroll-left {
    0% {
        transform: translateX(0%);
    }
    100% {
        transform: translateX(-50%);
    }
}
</style>
