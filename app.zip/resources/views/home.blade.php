@extends('layouts.app')

@section('fullscreen')
<section class="relative w-[99vw] h-[60vh] overflow-hidden" x-data="slider()" x-init="init()">
    <!-- Single Slide (no overlapping) -->
    <div
        x-transition:enter="transition-opacity duration-[1500ms] ease-in-out"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition-opacity duration-[1500ms] ease-in-out"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        class="absolute inset-0 w-full h-full"
        key="current-slide"
    >
        <img :src="images[currentIndex]" alt="Slide Image" class="w-full h-full object-cover object-center" />
    </div>

    <!-- Overlay -->
    <div class="absolute inset-0 bg-black bg-opacity-40 z-10 flex flex-col items-center justify-center text-center px-4">
        <img src="{{ asset('images/logo.png') }}" alt="Logo" class="h-20 mb-4 animate-bounce" />
        <h1 class="text-3xl md:text-5xl text-white font-bold animate-fadeIn leading-snug font-solaiman">
            Welcome to<br>বাখরাবাদ গ্যাস আদর্শ বিদ্যালয়
        </h1>
        <p class="text-lg text-white mt-2 animate-fadeIn delay-200 font-solaiman">
            Smart School System for Future Education
        </p>
    </div>

    <!-- Dots -->
    <div class="absolute bottom-5 left-1/2 transform -translate-x-1/2 z-20 flex space-x-2">
        <template x-for="(image, index) in images" :key="index">
            <button
                class="w-3 h-3 rounded-full focus:outline-none transition-all duration-300"
                :class="currentIndex === index ? 'bg-white scale-125' : 'bg-gray-400 opacity-70'"
                @click="goToSlide(index)"
            ></button>
        </template>
    </div>
</section>

<!-- Improved Alpine.js Logic -->
<script>
    function slider() {
        return {
            currentIndex: 0,
            images: [
                "{{ asset('images/slide1.jpg') }}",
                "{{ asset('images/slide2.jpg') }}",
                "{{ asset('images/slide3.jpg') }}"
            ],
            interval: null,
            init() {
                this.startAutoSlide();
            },
            startAutoSlide() {
                this.interval = setInterval(() => {
                    this.nextSlide();
                }, 8000);
            },
            nextSlide() {
                this.currentIndex = (this.currentIndex + 1) % this.images.length;
            },
            goToSlide(index) {
                this.currentIndex = index;
                clearInterval(this.interval); // optional: stop autoplay when user clicks
                this.startAutoSlide(); // restart autoplay
            }
        }
    }
</script>
<script src="//unpkg.com/alpinejs" defer></script>
@endsection



@section('content')
<!-- Notice Bar Section -->
<section class="relative">
    @include('partials.noticebar')
</section>

<section
  x-data="{ visible: false }"
  x-init="visible = true"
  x-intersect.once="visible = true"
  class="bg-gradient-to-br from-purple-100 via-yellow-50 to-white py-16 px-6 md:px-20 relative overflow-hidden"
>
  <div
    :class="visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'"
    class="container mx-auto rounded-xl bg-white bg-opacity-70 backdrop-blur-md p-8 md:p-12 transition-all duration-700 ease-out transform shadow-md hover:scale-[1.01] hover:shadow-xl"
  >
    <div class="flex flex-col md:flex-row md:space-x-10 gap-10">
      <!-- প্রধান শিক্ষকের কার্ড -->
      <div
        class="flex-1 bg-white rounded-lg shadow-lg border border-purple-300 p-6 flex flex-col items-center"
        x-data="{ expanded: false }"
      >
        <!-- ছবি, নাম ও পদবী -->
        <div
          class="w-36 h-36 rounded-full overflow-hidden border-4 border-purple-400 shadow-md mb-4 transition-transform duration-300 hover:scale-105"
        >
          <img
            src="{{ asset('images/head_teacher.png') }}"
            alt="প্রধান শিক্ষক"
            class="w-full h-full object-cover object-center"
          />
        </div>
        <h4 class="text-xl font-bold text-purple-700 mb-1 font-solaiman">জেবুন্নেছা খানম</h4>
        <p class="text-purple-600 text-sm font-semibold mb-4 font-solaiman">প্রধান শিক্ষক</p>

        <!-- বার্তার শিরোনাম -->
        <h3
          class="text-2xl font-semibold text-purple-700 mb-4 border-b border-purple-300 pb-2 w-full text-center font-solaiman"
        >
          প্রধান শিক্ষকের বার্তা
        </h3>

        <!-- বার্তা -->
        <div
          class="text-gray-800 leading-7 md:leading-8 text-justify text-sm md:text-base space-y-4 transition-all duration-500 ease-in-out w-full font-solaiman"
          :class="expanded ? '' : 'line-clamp-5 md:line-clamp-6'"
        >
          <p>
            অবাধ তথ্য প্রবাহ ও বিজ্ঞান প্রযুক্তির এই যুগে যে জাতি যত বেশি প্রযুক্তির সুবিধা ব্যবহার করছে সেই জাতি তত বেশি উন্নতির শিখরে বিচরণ করছে। জ্ঞান চর্চায় নিয়োজিত শিক্ষক-শিক্ষার্থী ও সংশ্লিষ্ট স্টেক হোল্ডারগণ এই পথযাত্রায় নিশ্চিতভাবে প্রযুক্তি ও তথ্য ব্যবহারে জ্ঞানকে আরো শানিত করতে সক্ষম হবে। তথ্য প্রযুক্তির দ্বার উন্মোচনের লক্ষ্যে ইতোমধ্যে বাখরাবাদ গ্যাস আদর্শ বিদ্যালয়ে নিজস্ব ওয়েবসাইট তৈরি হয়েছে (<a href="https://www.bgab.edu.bd" target="_blank" class="text-blue-600 underline">www.bgab.edu.bd</a>)। ওয়েবসাইটাকে হালনাগাদ করণের উদ্যোগ প্রশংসনীয়। সরকারি নির্দেশনায় হালনাগাদ করণের এই প্রক্রিয়ায় সংশ্লিষ্ট বিজিডিসিএল এর সকল স্তরের কর্মকর্তা-কর্মচারি ও বিদ্যালয়ের শিক্ষক-কর্মচারি সকলের শ্রম, মেধা, ও আন্তরিক প্রচেষ্টাকে মোবারকবাদ জানাই। আশা করি, সকলেই প্রযুক্তির এই সংযোজনে উপকৃত হবে।
          </p>
        </div>

        <!-- বিস্তারিত/সংক্ষিপ্ত বোতাম -->
        <button
          @click="expanded = !expanded"
          class="mt-3 text-purple-700 font-semibold hover:underline transition"
          x-text="expanded ? 'সংক্ষিপ্ত করুন' : 'বিস্তারিত দেখুন'"
        ></button>
      </div>

      <!-- চেয়ারম্যানের কার্ড -->
      <div
        class="flex-1 bg-white rounded-lg shadow-lg border border-purple-300 p-6 flex flex-col items-center"
        x-data="{ expanded: false }"
      >
        <!-- ছবি, নাম ও পদবী -->
        <div
          class="w-36 h-36 rounded-full overflow-hidden border-4 border-purple-400 shadow-md mb-4 transition-transform duration-300 hover:scale-105"
        >
          <img
            src="{{ asset('images/chairman.png') }}"
            alt="চেয়ারম্যান"
            class="w-full h-full object-cover object-center"
          />
        </div>
        <h4 class="text-xl font-bold text-purple-700 mb-1 font-solaiman">
          প্রকৌশলী মোস্তফা মাহিন সোহাগ
        </h4>
        <p class="text-purple-600 text-sm font-semibold mb-4 font-solaiman">চেয়ারম্যান</p>

        <!-- বার্তার শিরোনাম -->
        <h3
          class="text-2xl font-semibold text-purple-700 mb-4 border-b border-purple-300 pb-2 w-full text-center font-solaiman"
        >
          চেয়ারম্যানের বার্তা
        </h3>

        <!-- বার্তা -->
        <div
          class="text-gray-800 leading-7 md:leading-8 text-justify text-sm md:text-base space-y-4 transition-all duration-500 ease-in-out w-full font-solaiman"
          :class="expanded ? '' : 'line-clamp-5 md:line-clamp-6'"
        >
          <p>
            বিদ্যালয়ের চেয়ারম্যান হিসেবে আমি আনন্দিত যে, বাখরাবাদ গ্যাস আদর্শ বিদ্যালয় তার গুণগত শিক্ষার মাধ্যমে সমাজে ইতিবাচক প্রভাব ফেলছে। আমরা শিক্ষা ক্ষেত্রে আধুনিক প্রযুক্তি এবং নৈতিক শিক্ষার গুরুত্ব বুঝি এবং বিদ্যালয়কে এগিয়ে নিতে প্রতিশ্রুতিবদ্ধ।
          </p>
          <p x-show="expanded" x-transition>
            শিক্ষার্থীদের সুশিক্ষা এবং চরিত্র গঠনে আমরা সকল ধরনের সহযোগিতা প্রদান করে যাচ্ছি। বিদ্যালয় আমাদের ভবিষ্যৎ প্রজন্মের জন্য একটি আলোকবর্তিকা হিসেবে কাজ করবে – এই বিশ্বাসে আমি উজ্জীবিত।
          </p>
        </div>

        <!-- বিস্তারিত/সংক্ষিপ্ত বোতাম -->
        <button
          @click="expanded = !expanded"
          class="mt-3 text-purple-700 font-semibold hover:underline transition"
          x-text="expanded ? 'সংক্ষিপ্ত করুন' : 'বিস্তারিত দেখুন'"
        ></button>
      </div>
    </div>
  </div>
</section>


<!-- Tailwind line-clamp plugin (CSS) -->
<style>
  .line-clamp-5 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 5;
    -webkit-box-orient: vertical;
  }
  @media (min-width: 768px) {
    .md\:line-clamp-6 {
      overflow: hidden;
      display: -webkit-box;
      -webkit-line-clamp: 6;
      -webkit-box-orient: vertical;
    }
  }
</style>







<section
  x-data="{ expanded: false, visible: false }"
  x-init="visible = true"
  x-intersect.once="visible = true"
  class="bg-gradient-to-br from-purple-100 via-yellow-50 to-white py-16 px-6 md:px-20 relative overflow-hidden"
>
  <div
    :class="visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'"
    class="container mx-auto rounded-xl bg-white bg-opacity-70 backdrop-blur-md p-8 md:p-12 transition-all duration-700 ease-out transform shadow-md hover:scale-[1.01] hover:shadow-xl"
  >
    <!-- Heading -->
    <h2
      class="text-3xl md:text-4xl font-extrabold text-purple-800 mb-8 text-center border-b-4 border-purple-400 inline-block drop-shadow-md font-solaiman"
      :class="visible ? 'animate-fade-in-down' : ''"
    >
      ঐতিহাসিক প্রেক্ষাপট
    </h2>

    <!-- Text Content -->
    <div
      class="text-gray-800 leading-7 md:leading-8 text-justify text-sm md:text-base space-y-5 transition-all duration-500 ease-in-out font-solaiman"
    >
      <!-- Always Visible Text -->
      <p>
        বাখরাবাদ গ্যাস ডিস্ট্রিবিউশন কোম্পানী লিমিটেড, জ্বালানি ও খনিজ সম্পদ মন্ত্রণালয়ের অধীন একটি সরকারি মালিকানাধীন কোম্পানী। কোম্পানীর প্রধান কার্যালয় কুমিল্লা শহরের প্রাণ কেন্দ্র হতে কিছুটা দূরবর্তী শহরতলী চাপাপুর গ্রামে অবস্থিত। কোম্পানীর উর্ধ্বতন কর্মকর্তা ও কর্মচারীগণ তাঁদের সন্তান-সন্ততিদের মান সম্পন্ন শিক্ষাদান ও কমিউনিটি ডেভেলাপমেন্টের লক্ষ্যে কোম্পানীর প্রধান কার্যালয়স্থ আবাসিক এলাকায় একটি মান সম্পন্ন বিদ্যালয় প্রতিষ্ঠার প্রয়োজনীয়তা অনুভব করেন।
      </p>
      <p>
        ২৭ অক্টোবর, ১৯৯৪ বিদ্যালয় প্রতিষ্ঠার অনুমোদন লাভ করার পর কোম্পানীর নিজস্ব অর্থায়নে ১.৪২৫ একর ভূমির উপর বাখরাবাদ গ্যাস আদর্শ বিদ্যালয় প্রতিষ্ঠিত হয়। ১ জানুয়ারি ১৯৯৫ হতে অত্যাধুনিক সুযোগ সুবিধা সম্বলিত একটি দ্বিতল ভবনে বিদ্যালয়ের আনুষ্ঠানিক কার্যক্রম শুরু হয়।
      </p>
      <p>
        প্রথম পর্যায়ে শিশু হতে চতুর্থ শ্রেণি পর্যন্ত শিক্ষা কার্যক্রম শুরু হয় এবং ২৪ ডিসেম্বর ১৯৯৬ প্রাথমিক শিক্ষা অধিদপ্তর থেকে বিদ্যালয়টি স্বীকৃত লাভ করে। পরবর্তীতে ধাপে ধাপে বিদ্যালয়টি অষ্টম শ্রেণিতে উন্নীত হয় এবং ২৫ সেপ্টেম্বর, ২০০১ মাধ্যমিক ও উচ্চ শিক্ষা অধিদপ্তর, কুমিল্লা এর অনুমোদন লাভ করে নিম্ন মাধ্যমিক বিদ্যালয়ে উন্নীত হয়। ১৯৯৭ সন হতে প্রতি বছরই বিদ্যালয়ের শিক্ষার্থী প্রাথমিক/জুনিয়র বৃত্তি পেয়ে আসছে।
      </p>

      <!-- Expandable Content -->
      <div
        x-show="expanded"
        x-transition:enter="transition ease-out duration-500"
        x-transition:enter-start="opacity-0 max-h-0"
        x-transition:enter-end="opacity-100 max-h-screen"
        x-transition:leave="transition ease-in duration-300"
        x-transition:leave-start="opacity-100 max-h-screen"
        x-transition:leave-end="opacity-0 max-h-0"
        class="overflow-hidden"
      >
        <p>
          ২ জানুয়ারি ২০০২ অনুষ্ঠিত বিজিডিসিএল বোর্ডের ৩০২ তম সভায় বিদ্যালয়টিকে (হিউম্যানেটিজ গ্রুপ ব্যতীত) মাধ্যমিক বিদ্যালয়ে উন্নীত প্রক্রিয়া চালু করার অনুমতি প্রদান করা হয়। ৯ অক্টোবর ২০০৩ অনুষ্ঠিত বিজিডিসিএল বোর্ডের ৩২৬ তম সভায় পূর্বানুমতি প্রাপ্ত বাণিজ্য ও বিজ্ঞান গ্রুপের পাশাপাশি ৯ম শ্রেণিতে হিউম্যানেটিজ গ্রুপ ও খোলার অনুমতি প্রদান করা হয়। ২০০৪ সনে বিদ্যালয়ে ৯ম শ্রেণি খোলা হয়। ২০০৬ সালে প্রথমবারের মত এসএসসি পরীক্ষায় অংশগ্রহণ করে শতভাগ পাস সহ কুমিল্লা শিক্ষা বোর্ডে চতুর্থ স্থান অধিকার করে।
          <br><br>
          প্রথম পর্যায়ে শুধু কোম্পানীর কর্মকর্তা কর্মচারীদের সন্তান-সন্ততিদের জন্য বিনা বেতনে অধ্যয়নের সুযোগ ছিল। পরবর্তীতে ২০০০ সনে এলাকায় গণ্য মান্য ব্যাক্তিবর্গের দাবীর প্রক্ষিতে কোম্পানীর কর্মকর্তা-কর্মচারীদের সন্তান সন্ততি ভর্তির পর শূণ্য আসন সমূহে ভর্তি নির্বাচনী পরীক্ষার মাধ্যামে সীমিত সংখ্যক বহিরাগত শিক্ষার্থী ভর্তির সুযোগ দেয়া হয়ে থাকে। বর্তমানে বিদ্যালয়টিতে ৭৭০ (সাতশত সত্তর) জন শিক্ষার্থী অধ্যয়ন করছে।
        </p>
      </div>

      <!-- Toggle Buttons -->
      <div class="mt-6 text-center">
        <button
          x-show="!expanded"
          @click="expanded = true"
          class="text-purple-700 font-semibold hover:underline transition"
        >
          বিস্তারিত দেখুন
        </button>
        <button
          x-show="expanded"
          @click="expanded = false"
          class="text-purple-700 font-semibold hover:underline transition"
        >
          সংক্ষিপ্ত করুন
        </button>
      </div>
    </div>
  </div>
</section>



<style>
  @keyframes fade-in-up {
    0% {
      opacity: 0;
      transform: translateY(20px);
    }
    100% {
      opacity: 1;
      transform: translateY(0);
    }
  }
  @keyframes fade-in-down {
    0% {
      opacity: 0;
      transform: translateY(-20px);
    }
    100% {
      opacity: 1;
      transform: translateY(0);
    }
  }
  .animate-fade-in-up {
    animation: fade-in-up 0.8s ease-out forwards;
  }
  .animate-fade-in-down {
    animation: fade-in-down 0.8s ease-out forwards;
  }
</style>






<!-- Feature Cards -->
<section class="py-12 bg-white">
  <div class="container mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 px-6">


    <!-- Our Teachers Card -->
    <div class="bg-sky-100 p-6 rounded-2xl shadow-md text-center border border-sky-300 transform hover:-translate-y-1 hover:shadow-lg transition duration-300">
      <div class="text-purple-700 mb-4">
        <i class="fas fa-chalkboard-teacher fa-5x"></i>
      </div>
      <h3 class="text-xl font-semibold mb-3 text-sky-800">Our Teachers</h3>
      <p class="text-gray-700 mb-4">Meet the dedicated teachers guiding our students.</p>
      <a href="{{ route('public.teachers.index') }}" class="inline-block bg-sky-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-sky-600 transition duration-300">
        View Teachers
      </a>
    </div>

  
 <!-- Student List Card -->
<div class="bg-yellow-50 p-6 rounded-2xl shadow-md text-center border border-yellow-300 transform hover:-translate-y-1 hover:shadow-lg transition duration-300">
  <div class="text-purple-700 mb-4">
    <i class="fas fa-user-graduate fa-5x"></i>
  </div>
  <h3 class="text-xl font-semibold mb-3 text-purple-800">Student List</h3>
  <p class="text-gray-700 mb-4">View all enrolled students across all classes.</p>
  <a href="{{ route('public.students.index') }}" 
     class="inline-block bg-purple-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-purple-600 transition duration-300">
    View Students
  </a>
</div>

       <!-- Staffs Card -->
<div class="bg-purple-100 p-6 rounded-2xl shadow-md text-center border border-purple-300 transform hover:-translate-y-1 hover:shadow-lg transition duration-300">
  <div class="text-purple-700 mb-4">
    <i class="fas fa-users fa-5x"></i>
  </div>
  <h3 class="text-xl font-semibold mb-3 text-purple-800">Staffs</h3>
  <p class="text-gray-700 mb-4">View the team managing and supporting our school.</p>
  <a href="{{ route('public.staffs.index') }}" class="inline-block bg-purple-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-purple-600 transition duration-300">
    View Staffs
  </a>
</div> 

 <!-- Exam Schedule Card -->
<div class="bg-green-100 p-6 rounded-2xl shadow-md text-center border border-green-300 transform hover:-translate-y-1 hover:shadow-lg transition duration-300">
  <div class="text-green-700 mb-4">
    <i class="fas fa-calendar-check fa-5x"></i> {{-- New icon for exam schedule --}}
  </div>
  <h3 class="text-xl font-semibold mb-3 text-green-800">Exam Schedule</h3>
  <p class="text-gray-700 mb-4">Access the latest exam routines and important exam dates here.</p>
  <a href="{{ route('public.examfiles.index') }}" class="inline-block bg-green-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-green-600 transition duration-300">
    View Schedule
  </a>
</div>


    <!-- Result Card -->
    <div class="bg-pink-100 p-6 rounded-2xl shadow-md text-center border border-pink-300 transform hover:-translate-y-1 hover:shadow-lg transition duration-300">
      <div class="text-purple-700 mb-4">
        <i class="fas fa-trophy fa-5x"></i>
      </div>
      <h3 class="text-xl font-semibold mb-3 text-pink-800">Result</h3>
      <p class="text-gray-700 mb-4">Check academic results and performance updates.</p>
      <a href="{{ route('public.results.index') }}" class="inline-block bg-pink-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-pink-600 transition duration-300">
        View Results
      </a>
    </div>

 





    <!--Class syllabus and Routine Card -->
    <div class="bg-orange-100 p-6 rounded-2xl shadow-md text-center border border-orange-300 transform hover:-translate-y-1 hover:shadow-lg transition duration-300">
      <div class="text-orange-700 mb-4">
         <i class="fas fa-clock fa-5x"></i>
      </div>
      <h3 class="text-xl font-semibold mb-3 text-orange-800">Class Materials</h3>
      <p class="text-gray-700 mb-4">View daily class schedules and syllabus across all classes.</p>
      <a href="{{ route('public.classmaterials.index') }}" class="inline-block bg-orange-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-orange-600 transition duration-300">
        View Routine
      </a>
    </div>

    <!-- Academic Calendar Card -->
    <div class="bg-indigo-100 p-6 rounded-2xl shadow-md text-center border border-indigo-300 transform hover:-translate-y-1 hover:shadow-lg transition duration-300">
      <div class="text-indigo-700 mb-4">
        <i class="fas fa-calendar-alt fa-5x"></i>
      </div>
      <h3 class="text-xl font-semibold mb-3 text-indigo-800">Academic Calendar</h3>
      <p class="text-gray-700 mb-4">Important dates and academic events throughout the year.</p>
      <a href="{{ route('public.informations.showPublic', 'calendar') }}" class="inline-block bg-indigo-500 text-white px-5 py-2 rounded-full shadow-md hover:bg-indigo-600 transition duration-300">
        View Calendar
      </a>
    </div>

<!-- Rules & Regulation Card - Light Yellow with Deep Orange Icon & Button -->
<div class="bg-yellow-50 p-6 rounded-2xl shadow-md text-center border border-yellow-200 transform hover:-translate-y-1 hover:shadow-lg transition duration-300">
  <div class="text-orange-600 mb-4">
    <i class="fas fa-gavel fa-5x"></i>
  </div>
  <h3 class="text-xl font-semibold mb-3 text-yellow-700">Rules & Regulation</h3>
  <p class="text-gray-700 mb-4">Read our school rules and regulations to stay informed.</p>
  <a href="{{ route('public.informations.showPublic', 'rules') }}" class="inline-block bg-orange-600 text-white px-5 py-2 rounded-full shadow-md hover:bg-orange-700 transition duration-300">
    View Rules
  </a>
</div>






  </div>
</section>








    
   <!-- Gallery and Notice Board Side by Side -->
<section class="py-12 bg-white">
    <div class="container mx-auto px-6 flex gap-6 justify-center items-start font-solaiman">  {{-- Add font-solaiman here --}}
        <!-- Gallery - fixed width -->
        <div style="width: 850px;">
            <div class="notice-board-container h-[550px] flex flex-col border border-purple-400 rounded-lg shadow-lg p-2 bg-white overflow-hidden">
                <div class="notice-board-header flex items-center text-purple-700 font-semibold mb-2 font-solaiman">
                    <svg fill="currentColor" viewBox="0 0 20 20" aria-hidden="true" class="w-5 h-5 mr-2">
                        <path d="M4 3a1 1 0 000 2h12a1 1 0 100-2H4zm0 4a1 1 0 000 2h12a1 1 0 100-2H4zm0 4a1 1 0 000 2h8a1 1 0 100-2H4z" />
                    </svg>
                    Gallery Preview
                </div>

                @php
                    $galleryItems = \App\Models\Gallery::latest()->take(5)->get();
                @endphp

                @if($galleryItems->count())
                    <div 
                        x-data="gallerySlider()" 
                        x-init="init()" 
                        class="relative flex-grow overflow-hidden rounded-md"
                        style="width: 100%; height: 100%;"
                    >
                        <template x-for="(image, index) in images" :key="index">
                            <img 
                                :src="image.src" 
                                alt="Gallery Image" 
                                class="absolute top-0 left-0 w-full h-full object-cover rounded-md"
                                :class="{
                                    'opacity-100 translate-x-0': currentIndex === index,
                                    'opacity-0 translate-x-full': currentIndex !== index && index > currentIndex,
                                    'opacity-0 -translate-x-full': currentIndex !== index && index < currentIndex,
                                }"
                                style="transition: all 1.5s ease-in-out;"
                            />
                        </template>
                    </div>

                    <div class="flex justify-end mt-2 font-solaiman">
                        <a href="{{ route('public.gallery.index') }}" 
                            class="text-xs text-purple-600 hover:text-purple-800 font-semibold underline"
                        >
                            See More
                        </a>
                    </div>

                    @push('scripts')
                    <script src="//unpkg.com/alpinejs" defer></script>
                    <script>
                        function gallerySlider() {
                            return {
                                currentIndex: 0,
                                images: [
                                    @foreach($galleryItems as $item)
                                    {
                                        src: '{{ asset("storage/" . $item->image_path) }}',
                                    },
                                    @endforeach
                                ],
                                next() {
                                    this.currentIndex = (this.currentIndex === this.images.length - 1) ? 0 : this.currentIndex + 1;
                                },
                                init() {
                                    setInterval(() => {
                                        this.next();
                                    }, 5000);
                                }
                            }
                        }
                    </script>
                    @endpush

                @else
                    <p class="text-center text-gray-600 mt-6 font-solaiman">No images found.</p>
                @endif
            </div>
        </div>

       <!-- Notice Board - fixed width -->
<div style="width: 450px;">
    <div class="notice-board-container h-[450px] flex flex-col overflow-hidden font-solaiman">
        <!-- Header -->
        <div class="notice-board-header flex items-center text-xl font-bold bg-purple-100 px-4 py-2 text-purple-700 shadow font-solaiman">
            <svg fill="currentColor" viewBox="0 0 20 20" aria-hidden="true" class="mr-2 w-5 h-5">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.018 3.142a1 1 0 00.95.69h3.3c.969 0 1.371 1.24.588 1.81l-2.672 1.94a1 1 0 00-.364 1.118l1.019 3.141c.3.922-.755 1.688-1.538 1.118l-2.672-1.94a1 1 0 00-1.175 0l-2.672 1.94c-.783.57-1.838-.196-1.538-1.118l1.019-3.141a1 1 0 00-.364-1.118L2.49 8.57c-.783-.57-.38-1.81.588-1.81h3.3a1 1 0 00.95-.69l1.02-3.143z"/>
            </svg>
            📢 Notice Board
        </div>

        @if(isset($notices) && $notices->count())
        <!-- Scrolling List -->
        <div class="notice-board-list flex-1 relative overflow-hidden">
            <div class="absolute top-0 left-0 right-0 animate-scrollUp space-y-2 px-4 py-2">
                @foreach($notices as $notice)
                    <a href="{{ route('public.notices.show', $notice->id) }}" class="notice-item flex justify-between items-center bg-white px-4 py-2 rounded shadow hover:bg-purple-50 transition duration-300 font-solaiman" title="{{ $notice->title }}">
                        <span class="notice-title truncate text-purple-800 font-semibold" style="max-width: 200px;">{{ $notice->title }}</span>
                        <span class="notice-date text-gray-500 text-sm">{{ \Carbon\Carbon::parse($notice->publish_date)->format('d M Y') }}</span>
                        <span class="notice-icon text-purple-600 text-xl">📌</span>
                    </a>
                @endforeach

                <!-- Duplicate for seamless infinite loop -->
                @foreach($notices as $notice)
                    <a href="{{ route('public.notices.show', $notice->id) }}" class="notice-item flex justify-between items-center bg-white px-4 py-2 rounded shadow hover:bg-purple-50 transition duration-300 font-solaiman" title="{{ $notice->title }}">
                        <span class="notice-title truncate text-purple-800 font-semibold" style="max-width: 200px;">{{ $notice->title }}</span>
                        <span class="notice-date text-gray-500 text-sm">{{ \Carbon\Carbon::parse($notice->publish_date)->format('d M Y') }}</span>
                        <span class="notice-icon text-purple-600 text-xl">📌</span>
                    </a>
                @endforeach
            </div>
        </div>

        <!-- See All Button -->
        <a href="{{ route('public.notices.index') }}" class="see-all-btn mt-3 text-center bg-purple-600 text-white font-bold py-2 px-4 rounded hover:bg-purple-700 transition mx-auto font-solaiman">📄 See All</a>

        @else
        <p class="text-center text-gray-600 mt-6 font-solaiman">📭 No published notices available at the moment.</p>
        @endif
    </div>
</div>

<!-- Tailwind CSS Animation -->
<style>
@keyframes scrollUp {
  0% { transform: translateY(0%); }
  100% { transform: translateY(-50%); } /* Half because we duplicate list */
}
.animate-scrollUp {
  animation: scrollUp linear infinite;
  animation-duration: {{ max(12, count($notices) * 3) }}s; /* slower, minimum 12s */
}
</style>



</section>


 <section class="py-12 bg-white">
</section>

<section class="bg-purple-100 py-15">
  <div class="container mx-auto px-6">
    <div class="flex justify-between items-center">

      <!-- Column 1: Teacher -->
      <div class="flex flex-col items-center max-w-[150px]">
        <div class="bg-purple-200 rounded-3xl p-6 shadow-neumorph hover:shadow-neumorph-hover transition-shadow duration-300 transform hover:-translate-y-1 hover:scale-105">
          <img src="{{ asset('images/icons/teacher.png') }}" alt="Teacher Icon" class="h-20 w-20 object-contain">
        </div>
        <h3 class="text-xl font-semibold text-purple-900 mt-5">Teacher</h3>
        <p class="text-3xl font-bold text-purple-900 mt-1">20</p>
      </div>

      <!-- Column 2: Students -->
      <div class="flex flex-col items-center max-w-[150px]">
        <div class="bg-purple-200 rounded-3xl p-6 shadow-neumorph hover:shadow-neumorph-hover transition-shadow duration-300 transform hover:-translate-y-1 hover:scale-105">
          <img src="{{ asset('images/icons/student.png') }}" alt="Student Icon" class="h-20 w-20 object-contain">
        </div>
        <h3 class="text-xl font-semibold text-purple-900 mt-5">Students</h3>
        <p class="text-3xl font-bold text-purple-900 mt-1">709</p>
      </div>

      <!-- Column 3: Staffs -->
      <div class="flex flex-col items-center max-w-[150px]">
        <div class="bg-purple-200 rounded-3xl p-6 shadow-neumorph hover:shadow-neumorph-hover transition-shadow duration-300 transform hover:-translate-y-1 hover:scale-105">
          <img src="{{ asset('images/icons/staff.png') }}" alt="Staff Icon" class="h-20 w-20 object-contain">
        </div>
        <h3 class="text-xl font-semibold text-purple-900 mt-5">Staffs</h3>
        <p class="text-3xl font-bold text-purple-900 mt-1">8</p>
      </div>

      <!-- Column 4: Classes -->
      <div class="flex flex-col items-center max-w-[150px]">
        <div class="bg-purple-200 rounded-3xl p-6 shadow-neumorph hover:shadow-neumorph-hover transition-shadow duration-300 transform hover:-translate-y-1 hover:scale-105">
          <img src="{{ asset('images/icons/class.png') }}" alt="Class Icon" class="h-20 w-20 object-contain">
        </div>
        <h3 class="text-xl font-semibold text-purple-900 mt-5">Classes</h3>
        <p class="text-3xl font-bold text-purple-900 mt-1">10</p>
      </div>

    </div>
  </div>
</section>

<style>
  .shadow-neumorph {
    box-shadow:
      8px 8px 15px #b6a6ca,
      -8px -8px 15px #ffffff;
  }
  .shadow-neumorph-hover {
    box-shadow:
      4px 4px 8px #b6a6ca,
      -4px -4px 8px #ffffff;
  }
</style>





<section class="py-12 bg-white">
</section>


<!-- Extra Section: Our Mission or Quick Fact -->
<section class="bg-white py-10">
  <div class="max-w-5xl mx-auto px-4 text-center">
    <h3 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">We Inspire. We Educate. We Build Tomorrow’s Leaders.</h3>
    <p class="text-gray-700 text-lg md:text-xl">Empowering young minds with knowledge, values, and skills to shape a better tomorrow.</p>
  </div>
</section>

<!-- Icon Strip Section (Side-by-side, No Card) -->
<section class="bg-white py-10">
  <div class="max-w-5xl mx-auto px-4 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
    
    <div class="flex flex-col items-center hover:scale-110 transition-transform duration-300">
      <div class="text-4xl mb-2">📚</div>
      <p class="font-semibold text-gray-800 text-sm">Smart Curriculum</p>
    </div>

    <div class="flex flex-col items-center hover:scale-110 transition-transform duration-300">
      <div class="text-4xl mb-2">💡</div>
      <p class="font-semibold text-gray-800 text-sm">Creative Learning</p>
    </div>

    <div class="flex flex-col items-center hover:scale-110 transition-transform duration-300">
      <div class="text-4xl mb-2">🌿</div>
      <p class="font-semibold text-gray-800 text-sm">Green Campus</p>
    </div>

    <div class="flex flex-col items-center hover:scale-110 transition-transform duration-300">
      <div class="text-4xl mb-2">🎓</div>
      <p class="font-semibold text-gray-800 text-sm">Inspiring Faculty</p>
    </div>

  </div>
</section>





<section class="py-12 bg-white">
</section> 


<!-- Footer Section -->
<footer class="bg-gradient-to-r from-purple-100 via-yellow-100 to-sky-100 border-t border-gray-300 mt-auto">
    <div class="max-w-8xl mx-auto px-5 py-8 grid grid-cols-1 md:grid-cols-3 gap-8 text-gray-800">
        
        <!-- Logo & About -->
        <div>
            <h2 class="text-3xl font-bold mb-4 flex items-center gap-2 text-purple-700">
                <i class="fas fa-school"></i> <!-- school icon -->
                Bakhrabad Gas Adarsha Bidyaloy
            </h2>
            <p class="text-sm">Committed to academic excellence and holistic development.</p>
        </div>

        <!-- Quick Links -->
        <div>
            <h3 class="text-xl font-semibold mb-3 underline underline-offset-4 flex items-center gap-2 text-purple-700">
                <i class="fas fa-link"></i> <!-- link icon -->
                Quick Links
            </h3>
            <ul class="space-y-2 text-sm">
                <li><a href="https://www.dshe.gov.bd/" target="_blank" class="hover:text-purple-600"><i class="fas fa-arrow-right mr-2"></i>DSHE</a></li>
                <li><a href="https://bangladesh.gov.bd/" target="_blank" class="hover:text-purple-600"><i class="fas fa-arrow-right mr-2"></i>BD National Portal</a></li>
                <li><a href="https://moedu.gov.bd/" target="_blank" class="hover:text-purple-600"><i class="fas fa-arrow-right mr-2"></i>Ministry of Education</a></li>
                <li>
  <a href="https://bgdcl.gov.bd/" target="_blank" class="hover:text-purple-600">
    <i class="fas fa-arrow-right mr-2"></i>BGDCL (Bakhrabad Gas Distribution Co. Ltd.)
  </a>
</li>

                <!-- Add more links as needed -->
            </ul>
        </div>

        <!-- Contact Info (Dynamic) -->
        <div>
            <h3 class="text-xl font-semibold mb-3 underline underline-offset-4 flex items-center gap-2 text-purple-700">
                <i class="fas fa-phone"></i> <!-- phone icon -->
                Contact Us
            </h3>
            @isset($contact)
                <p><i class="fas fa-phone-alt mr-2 text-purple-600"></i><strong>Phone: </strong> {{ $contact->primary_hotline }}</p>
                <p><i class="fas fa-envelope mr-2 text-purple-600"></i><strong>Email:</strong> {{ $contact->email }}</p>
                <p><i class="fas fa-map-marker-alt mr-2 text-purple-600"></i><strong>Address:</strong><br>
<span class="block pl-6">Bakhrabad Gas Adarsha Bidyaloy,</span>
<span class="block pl-6">Chapapur,</span>
<span class="block pl-6">Adarsha Sadar, Cumilla</span>
</p>
            @else
                <p>Contact information not available.</p>
            @endisset
        </div>
    </div>
</footer>









    <!-- Styles -->
    <style>
        .notice-board-container {
            border: 3px solid #c4b5fd;
            border-radius: 20px;
            background: linear-gradient(135deg, #fff9db, #f3e8ff);
            box-shadow: 0 4px 15px rgb(196 181 253 / 0.3), inset 0 0 10px rgb(255 255 255 / 0.6);
            padding: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            flex-direction: column;
            height: 550px; /* fixed height */
        }

        .notice-board-header {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 900;
            font-size: 1.75rem;
            color: #7c3aed;
            margin-bottom: 16px;
        }

        .notice-board-header svg {
            width: 28px;
            height: 28px;
            color: #fbbf24;
        }

        .notice-board-list {
            max-height: 350px;
            overflow-y: auto;
        }

        .notice-board-list::-webkit-scrollbar {
            width: 6px;
        }

        .notice-board-list::-webkit-scrollbar-thumb {
            background-color: #a78bfa;
            border-radius: 12px;
        }

        .notice-item {
            background: #fff;
            border-left: 5px solid #fde68a;
            padding: 12px 16px;
            margin-bottom: 12px;
            border-radius: 6px;
            box-shadow: 0 2px 5px rgb(0 0 0 / 0.05);
            transition: 0.3s;
            display: flex;
            justify-content: space-between;
            align-items: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .notice-item:hover {
            border-left-color: #7c3aed;
            background-color: #ede9fe;
            box-shadow: 0 4px 10px rgb(124 58 237 / 0.2);
            transform: translateY(-2px);
        }

        .notice-title {
            font-weight: 600;
            font-size: 1rem;
            color: #111827;
            flex: 1;
            margin-right: 10px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .notice-date {
            font-size: 0.875rem;
            color: #6b7280;
            white-space: nowrap;
            flex-shrink: 0;
            margin-left: 10px;
        }

        .notice-icon {
            font-size: 1.2rem;
            margin-left: 10px;
            color: #fbbf24;
            flex-shrink: 0;
        }

        .notice-item:hover .notice-icon {
            color: #7c3aed;
        }

        .see-all-btn {
            display: inline-block;
            margin-top: 16px;
            background-color: #c4b5fd;
            color: #4c1d95;
            font-weight: 700;
            padding: 8px 20px;
            border-radius: 9999px;
            transition: background-color 0.3s ease;
            text-decoration: none;
            font-size: 0.95rem;
            text-align: center;
        }

        .see-all-btn:hover {
            background-color: #7c3aed;
            color: white;
        }
    </style>
@endsection
