@extends('layouts.adminapp')

@section('content')
<div class="container mx-auto p-6 max-w-4xl bg-white rounded-lg shadow-md">
  <h2 class="text-3xl font-bold text-purple-700 mb-6">✏️ Edit Result</h2>

  @if ($errors->any())
    <div class="bg-red-100 border border-red-400 text-red-700 p-4 rounded mb-6">
      <ul class="list-disc pl-5">
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
  @endif

  <form action="{{ route('admin.results.update', $result->id) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
    @csrf
    @method('PUT')

    <!-- Class -->
    <div>
      <label for="class" class="block font-semibold mb-2">Class *</label>
      <select name="class" id="class" class="w-full border border-gray-300 rounded p-2" required>
        @for ($i = 1; $i <= 10; $i++)
          <option value="Class {{ $i }}" {{ (old('class', $result->class) == 'Class '.$i) ? 'selected' : '' }}>
            Class {{ $i }}
          </option>
        @endfor
      </select>
    </div>

    <!-- Exam Type -->
    <div>
      <label for="exam_type" class="block font-semibold mb-2">Exam Type (optional)</label>
      <input type="text" name="exam_type" id="exam_type" value="{{ old('exam_type', $result->exam_type) }}"
        class="w-full border border-gray-300 rounded p-2" placeholder="Enter exam type">
    </div>

    <!-- Year -->
    <div>
      <label for="year" class="block font-semibold mb-2">Year *</label>
      <input type="number" name="year" id="year" value="{{ old('year', $result->year) }}" min="1900" max="2100" step="1"
        class="w-full border border-gray-300 rounded p-2" placeholder="e.g., 2025" required>
    </div>

    <!-- Replace File -->
    <div>
      <label for="file" class="block font-semibold mb-2">Replace File (PDF or Image)</label>
      <input type="file" name="file" id="file" class="w-full border border-gray-300 rounded p-2" accept=".pdf,image/*">
      @if($result->file_path)
        <p class="mt-2">
          <a href="{{ asset('storage/' . $result->file_path) }}" target="_blank" class="text-blue-600 underline hover:text-blue-800">
            View Current File
          </a>
        </p>
      @endif
    </div>

    <!-- Buttons -->
    <div class="flex gap-4 mt-6">
      <button type="submit" class="bg-purple-600 text-black px-6 py-2 rounded hover:bg-purple-700 transition">
        Update
      </button>
      <a href="{{ route('admin.results.index') }}"
         class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition">
         Cancel
      </a>
    </div>
  </form>
</div>
@endsection
