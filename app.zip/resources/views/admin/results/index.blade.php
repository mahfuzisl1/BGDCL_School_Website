@extends('layouts.adminapp')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">
    <!-- Header -->
    <div class="bg-purple-100 p-6 rounded-lg shadow-md mb-6 border border-purple-300">
        <h1 class="text-3xl font-bold text-gray-900 mb-2 text-center">📝 Results List</h1>
        <p class="text-gray-800 text-center">Manage results here — search, add, edit, or delete.</p>
    </div>

    <!-- Success Message -->
    @if(session('success'))
        <div class="bg-green-100 border border-green-300 text-gray-900 px-4 py-3 rounded mb-4 shadow">
            {{ session('success') }}
        </div>
    @endif

    <!-- Search + Add New Button -->
    <div class="bg-white p-6 rounded-lg shadow mb-6 border border-gray-200">
        <form method="GET" action="{{ route('admin.results.index') }}" class="md:flex md:items-center md:gap-4 flex-wrap">
            <input
                type="text"
                name="search"
                placeholder="🔍 Search by Class or Title"
                value="{{ request('search') }}"
                class="flex-grow border border-gray-300 rounded-md px-4 py-2 mb-2 md:mb-0 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-300 text-gray-900"
            />
            <div class="flex items-center gap-3 flex-wrap mt-2 md:mt-0">
                <button type="submit"
                    class="bg-white border border-purple-600 text-purple-600 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-purple-600 hover:text-white transition">
                    🔍 Search
                </button>
                <a href="{{ route('admin.results.index') }}"
                   class="bg-white border border-yellow-400 text-yellow-500 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-yellow-400 hover:text-white transition">
                    🔁 Reset
                </a>
                <a href="{{ route('admin.results.create') }}"
                   class="bg-white border border-green-600 text-green-600 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-green-600 hover:text-white transition">
                    ➕ Add New Result
                </a>
            </div>
        </form>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
        <table class="min-w-full table-auto border border-gray-300 rounded-lg overflow-hidden shadow-md">
            <thead class="bg-purple-200 text-gray-900 text-sm uppercase">
                <tr>
                    <th class="px-4 py-2 border">Class</th>
                    <th class="px-4 py-2 border">Title</th>
                    <th class="px-4 py-2 border">Published Date</th>
                    <th class="px-4 py-2 border">File</th>
                    <th class="px-4 py-2 border text-center">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white text-gray-900">
                @forelse($results as $result)
                    <tr class="hover:bg-purple-50 transition">
                        <td class="px-4 py-2 border">{{ $result->class }}</td>
                        <td class="px-4 py-2 border">{{ $result->exam_type ?? 'N/A' }}</td>
                        <td class="px-4 py-2 border">{{ \Carbon\Carbon::parse($result->published_date)->format('d M, Y') }}</td>
                        <td class="px-4 py-2 border">
                            <a href="{{ asset('storage/' . $result->file_path) }}" target="_blank"
                               class="text-blue-600 hover:underline">View File</a>
                        </td>
                        <td class="px-4 py-2 border space-x-2 text-center">
                            <a href="{{ route('admin.results.edit', $result->id) }}"
                               class="bg-sky-100 border border-sky-500 text-sky-700 px-3 py-1 text-sm rounded hover:bg-sky-600 hover:text-white transition">
                                ✏️ Edit
                            </a>
                            <form action="{{ route('admin.results.destroy', $result->id) }}" method="POST" class="inline"
                                  onsubmit="return confirm('Are you sure you want to delete this result?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit"
                                        class="bg-rose-100 border border-rose-500 text-rose-700 px-3 py-1 text-sm rounded hover:bg-rose-600 hover:text-white transition">
                                    🗑️ Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center py-4 text-gray-600">No results found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        {{ $results->withQueryString()->links() }}
    </div>
</div>
@endsection
