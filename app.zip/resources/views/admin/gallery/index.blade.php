@extends('layouts.adminapp')

@section('content')
<div class="container py-4">
    <h2 class="text-2xl font-bold mb-4">📸 Gallery List</h2>

    <a href="{{ route('admin.gallery.create') }}" class="btn btn-primary mb-4">➕ Add New Image</a>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @foreach($galleries as $gallery)
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <img src="{{ asset('storage/' . $gallery->image_path) }}" alt="Gallery Image" class="w-full h-48 object-cover">
            <div class="p-4">
                <h4 class="font-bold text-lg">{{ $gallery->title ?? 'Untitled' }}</h4>
                <p class="text-sm text-gray-600">{{ $gallery->caption ?? '' }}</p>

                <div class="flex justify-between mt-3">
                    <a href="{{ route('admin.gallery.edit', $gallery->id) }}" class="text-blue-600 hover:underline">✏️ Edit</a>
                    <form action="{{ route('admin.gallery.destroy', $gallery->id) }}" method="POST" onsubmit="return confirm('Are you sure to delete this image?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="text-red-600 hover:underline">🗑️ Delete</button>
                    </form>
                </div>
            </div>
        </div>
        @endforeach
    </div>

    <div class="mt-6">
        {{ $galleries->links() }}
    </div>
</div>
@endsection
