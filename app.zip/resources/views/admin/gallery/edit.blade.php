@extends('layouts.adminapp')

@section('content')
<div class="container py-4">
    <h2 class="text-2xl font-bold mb-4">✏️ Edit Gallery Image</h2>

    @if ($errors->any())
        <div class="alert alert-danger mb-3">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.gallery.update', $gallery->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="mb-4">
            <label class="block font-semibold">Title</label>
            <input type="text" name="title" class="form-control" value="{{ old('title', $gallery->title) }}">
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Caption</label>
            <input type="text" name="caption" class="form-control" value="{{ old('caption', $gallery->caption) }}">
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Current Image</label><br>
            <img src="{{ asset('storage/' . $gallery->image_path) }}" class="h-32 mt-2">
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Replace Image</label>
            <input type="file" name="image" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">💾 Update</button>
    </form>
</div>
@endsection
