@extends('layouts.adminapp')

@section('content')
<div class="container py-4">
    <h2 class="text-2xl font-bold mb-4">➕ Add New Gallery Image</h2>

    @if ($errors->any())
        <div class="alert alert-danger mb-3">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.gallery.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="mb-4">
            <label class="block font-semibold">Title</label>
            <input type="text" name="title" class="form-control" value="{{ old('title') }}">
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Caption</label>
            <input type="text" name="caption" class="form-control" value="{{ old('caption') }}">
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Image <span class="text-red-500">*</span></label>
            <input type="file" name="image" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-success">💾 Upload</button>
    </form>
</div>
@endsection
