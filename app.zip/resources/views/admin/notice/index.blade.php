@extends('layouts.adminapp')

@section('content')
<div class="container mt-4">
    <h2>📋 Notice List</h2>

    <!-- Search -->
    <form action="{{ route('admin.notices.index') }}" method="GET" class="d-flex mb-3">
        <input type="text" name="search" placeholder="Search title/content" class="form-control me-2" value="{{ request('search') }}">
        <button type="submit" class="btn btn-outline-primary">🔍 Search</button>
    </form>

    <!-- Add Button -->
    <a href="{{ route('admin.notices.create') }}" class="btn btn-success mb-3">➕ Add New Notice</a>

    <!-- Notice Table -->
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="table-light">
                <tr>
                    <th>📌</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Class</th>
                    <th>Status</th>
                    <th>Publish Date</th>
                    <th>Attachment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            @forelse ($notices as $notice)
                <tr>
                    <td>{!! $notice->is_pinned ? '📌' : '' !!}</td>
                    <td>
                        {{ $notice->title }}
                        @if (\Carbon\Carbon::parse($notice->publish_date)->diffInDays(now()) <= 7)
                            <span class="badge bg-warning text-dark">🆕 New</span>
                        @endif
                    </td>
                    <td>{{ $notice->category ?? '—' }}</td>
                    <td>
                        {{ $notice->class ?? '—' }}
                        {{ $notice->section ? ' - ' . $notice->section : '' }}
                    </td>
                    <td><span class="badge bg-info text-dark">{{ ucfirst($notice->status) }}</span></td>
                    <td>{{ \Carbon\Carbon::parse($notice->publish_date)->format('Y-m-d') }}</td>
                    <td>
                        @if ($notice->attachment)
                            <a href="{{ asset('storage/' . $notice->attachment) }}" target="_blank">📂 View</a>
                        @else
                            —
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('admin.notices.edit', $notice->id) }}" class="btn btn-sm btn-warning">✏️ Edit</a>
                        <form action="{{ route('admin.notices.destroy', $notice->id) }}" method="POST" style="display:inline-block;">
                            @csrf
                            @method('DELETE')
                            <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">🗑️ Delete</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" class="text-center">No notices found.</td>
                </tr>
            @endforelse
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="d-flex justify-content-center">
            {!! $notices->appends(request()->input())->links() !!}
        </div>
    </div>
</div>
@endsection
