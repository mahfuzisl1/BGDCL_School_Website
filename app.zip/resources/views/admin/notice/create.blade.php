@extends('layouts.adminapp')

@section('content')
<div class="container mt-4">
    <h2>➕ Create New Notice</h2>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.notices.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Content</label>
            <textarea name="content" class="form-control" rows="4" required></textarea>
        </div>

        <div class="mb-3">
            <label>Publish Date</label>
            <input type="date" name="publish_date" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Category (optional)</label>
            <select name="category" class="form-select">
                <option value="">-- None --</option>
                <option value="Exam">Exam</option>
                <option value="Holiday">Holiday</option>
                <option value="Event">Event</option>
                <option value="Academic">Academic</option>
                <option value="Emergency">Emergency</option>
                <option value="General">General</option>
                <option value="Sports">Sports</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Class (optional)</label>
            <select name="class" class="form-select">
                <option value="">-- None --</option>
                @for ($i = 1; $i <= 10; $i++)
                    <option value="Class {{ $i }}">Class {{ $i }}</option>
                @endfor
            </select>
        </div>

        <div class="mb-3">
            <label>Section (optional)</label>
            <select name="section" class="form-select">
                <option value="">-- None --</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-select" required>
                <option value="draft">Draft</option>
                <option value="published">Published</option>
                <option value="archived">Archived</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Attachment (PDF/Image)</label>
            <input type="file" name="attachment" class="form-control">
        </div>

  

        <button type="submit" class="btn btn-primary">✅ Save</button>
    </form>
</div>
@endsection
