@extends('layouts.adminapp')

@section('content')
<div class="container mt-4">
    <h2>✏️ Edit Notice</h2>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Error!</strong> Please fix the following issues:<br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.notices.update', $notice->id) }}" method="POST" enctype="multipart/form-data">
        @csrf @method('PUT')

        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" value="{{ $notice->title }}" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Content</label>
            <textarea name="content" class="form-control" rows="4" required>{{ $notice->content }}</textarea>
        </div>

        <div class="mb-3">
            <label>Publish Date</label>
            <input type="date" name="publish_date" value="{{ $notice->publish_date }}" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Category (optional)</label>
            <select name="category" class="form-select">
                <option value="">-- None --</option>
                @foreach(['Exam','Holiday','Event','Academic','Emergency','General','Sports'] as $cat)
                    <option value="{{ $cat }}" @if($notice->category == $cat) selected @endif>{{ $cat }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label>Class (optional)</label>
            <select name="class" class="form-select">
                <option value="">-- None --</option>
                @for ($i = 1; $i <= 10; $i++)
                    <option value="Class {{ $i }}" @if($notice->class == "Class $i") selected @endif>Class {{ $i }}</option>
                @endfor
            </select>
        </div>

        <div class="mb-3">
            <label>Section (optional)</label>
            <select name="section" class="form-select">
                <option value="">-- None --</option>
                @foreach(['A','B','C','D'] as $sec)
                    <option value="{{ $sec }}" @if($notice->section == $sec) selected @endif>{{ $sec }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-select" required>
                <option value="draft" @if($notice->status == 'draft') selected @endif>Draft</option>
                <option value="published" @if($notice->status == 'published') selected @endif>Published</option>
                <option value="archived" @if($notice->status == 'archived') selected @endif>Archived</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Attachment</label>
            @if($notice->attachment)
                <div class="mb-2">
                    📂 <a href="{{ asset('storage/' . $notice->attachment) }}" target="_blank">View Current File</a>
                </div>
            @endif
            <input type="file" name="attachment" class="form-control">
        </div>

      

        <button type="submit" class="btn btn-primary">💾 Update</button>
    </form>
</div>
@endsection
