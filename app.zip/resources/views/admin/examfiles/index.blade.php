@extends('layouts.adminapp')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">
    <!-- Header -->
    <div class="bg-purple-100 p-6 rounded-lg shadow-md mb-6 border border-purple-300">
        <h1 class="text-3xl font-bold text-gray-900 mb-2 text-center">📄 Exam Schedules</h1>
        <p class="text-gray-800 text-center">Manage exam schedules — search, upload, edit, or delete.</p>
    </div>

    <!-- Success & Error Messages -->
    @if(session('success'))
        <div class="bg-green-100 border border-green-300 text-green-900 px-4 py-3 rounded mb-4 shadow">
            {{ session('success') }}
        </div>
    @endif
    @if(session('error'))
        <div class="bg-red-100 border border-red-300 text-red-900 px-4 py-3 rounded mb-4 shadow">
            {{ session('error') }}
        </div>
    @endif

    <!-- Search + Upload Button -->
    <div class="bg-white p-6 rounded-lg shadow mb-6 border border-gray-200 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <form method="GET" action="{{ route('admin.examfiles.index') }}" class="flex flex-wrap items-center gap-2">
            <input
                type="text"
                name="search"
                placeholder="🔍 Search by filename or class"
                value="{{ request('search') }}"
                class="border border-gray-300 rounded-md px-4 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-300 text-gray-900"
            />
            <button type="submit"
                    class="bg-purple-600 text-black font-semibold px-4 py-2 rounded-md shadow hover:bg-purple-700 transition">
                Search
            </button>
            <a href="{{ route('admin.examfiles.index') }}"
               class="bg-gray-300 text-gray-900 font-semibold px-4 py-2 rounded-md shadow hover:bg-gray-400 transition">
                Reset
            </a>
        </form>

        <a href="{{ route('admin.examfiles.create') }}"
           class="bg-green-600 text-black font-semibold px-4 py-2 rounded-md shadow hover:bg-green-700 transition text-center whitespace-nowrap">
            ➕ Upload New Schedule 
        </a>
    </div>
     {{-- Section Open --}}
<section class="bg-white py-8 px-6 rounded-lg shadow-md mb-8">
    
    <h2 class="text-2xl font-semibold mb-4"></h2>
    <p class="text-gray-700"></p>
    {{-- ... --}}
{{-- Section Close --}}
</section>

<div class="my-6"></div>
    <!-- Table -->
    @if($files->isEmpty())
        <p class="text-gray-500 text-center">No exam schedules found.</p>
    @else
        <div class="overflow-x-auto rounded-lg shadow-md border border-gray-300">
            <table class="min-w-full table-auto text-gray-900 text-sm">
                <thead class="bg-gray-100 uppercase font-semibold text-gray-700">
                    <tr>
                        <th class="border border-gray-300 px-4 py-3 text-left">Class</th>
                        <th class="border border-gray-300 px-4 py-3 text-left">Filename</th>
                        <th class="border border-gray-300 px-4 py-3 text-left">Uploaded At</th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($files as $file)
                        <tr class="hover:bg-purple-50 transition">
                            <td class="border border-gray-300 px-4 py-2">Class {{ $file['class'] }}</td>
                            <td class="border border-gray-300 px-4 py-2">
                                @if(isset($file['url']))
                                    <a href="{{ $file['url'] }}" target="_blank" class="text-blue-600 hover:underline">
                                        {{ $file['filename'] }}
                                    </a>
                                @else
                                    <span class="text-gray-400 italic">No file URL</span>
                                @endif
                            </td>
                            <td class="border border-gray-300 px-4 py-2">{{ $file['uploaded_at'] }}</td>
                            <td class="border border-gray-300 px-4 py-2 text-center space-x-2">
                                <a href="{{ route('admin.examfiles.edit', ['filename' => $file['filename']]) }}"
                                   class="bg-yellow-400 text-black px-3 py-1 rounded hover:bg-yellow-500 transition">
                                    ✏️ Edit
                                </a>

                                <form action="{{ route('admin.examfiles.destroy', ['filename' => $file['filename']]) }}"
                                      method="POST" class="inline"
                                      onsubmit="return confirm('Are you sure you want to delete this schedule?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"
                                            class="bg-red-500 text-black px-3 py-1 rounded hover:bg-red-600 transition">
                                        🗑️ Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
</div>
@endsection
