@extends('layouts.adminapp')

@section('content')
<div class="container mx-auto p-4 max-w-xl">
    <h2 class="text-xl font-bold mb-4">Edit Exam Schedule</h2>

    <form action="{{ route('admin.examfiles.update', $filename) }}" method="POST" enctype="multipart/form-data" class="space-y-4">
        @csrf
        @method('PUT')

        <div>
            <label for="class">Class</label>
            <select name="class" id="class" class="form-select w-full">
                @foreach(range(1,10) as $c)
                    <option value="{{ $c }}">{{ 'Class ' . $c }}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="schedule_file">Replace File (optional)</label>
            <input type="file" name="schedule_file" class="form-input w-full" accept=".pdf,.jpg,.jpeg,.png">
        </div>

        <button type="submit" class="bg-blue-500 text-black px-4 py-2 rounded">Update</button>
    </form>
</div>
@endsection
