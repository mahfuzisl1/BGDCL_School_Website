@extends('layouts.adminapp')

@section('content')
<div class="max-w-5xl mx-auto p-6">
    <h2 class="text-3xl font-bold text-purple-700 mb-6"><center>🎓 Register New Student</h2>

    @if ($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 p-4 rounded mb-6">
            <ul class="list-disc pl-5">
                @foreach ($errors->all() as $error)
                    <li>• {{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.students.store') }}" method="POST" enctype="multipart/form-data" class="space-y-8">
        @csrf

        {{-- Personal Details --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-4">👤 Personal Information</h3>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block mb-1 font-medium">Student ID*</label>
                    <input type="text" name="student_id" value="{{ old('student_id') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Full Name*</label>
                    <input type="text" name="name" value="{{ old('name') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Date of Birth*</label>
                    <input type="date" name="dob" value="{{ old('dob') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Gender*</label>
                    <select name="gender" class="w-full input" required>
                        <option value="">-- Select Gender --</option>
                        @foreach(['Male','Female','Other'] as $gender)
                            <option value="{{ $gender }}" @selected(old('gender') == $gender)>{{ $gender }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Blood Group</label>
                    <input type="text" name="blood_group" value="{{ old('blood_group') }}" class="w-full input">
                </div>
                <div>
                    <label class="block mb-1 font-medium">Religion ('Muslim', 'Hinduism', 'Christianity', 'Buddhism')</label>
                    <input type="text" name="religion" value="{{ old('religion') }}" class="w-full input">
                </div>
                <div class="md:col-span-2">
                    <label class="block mb-1 font-medium">NID / Birth Certificate No.</label>
                    <input type="text" name="nid_or_birth_cert" value="{{ old('nid_or_birth_cert') }}" class="w-full input">
                </div>
            </div>
        </div>

        {{-- Academic Details --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-4">🏫 Academic Information</h3>

            <div class="grid md:grid-cols-3 gap-4">
                <div>
                    <label class="block mb-1 font-medium">Class*</label>
                    <input type="number" name="class" value="{{ old('class') }}" class="w-full input" min="1" max="10" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Section</label>
                    <select name="section" class="w-full input">
                        <option value="">-- Select Section --</option>
                        @foreach(['A','B','C','D'] as $sec)
                            <option value="{{ $sec }}" @selected(old('section') == $sec)>{{ $sec }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Roll No</label>
                    <input type="number" name="roll" value="{{ old('roll') }}" class="w-full input">
                </div>
                <div>
                    <label class="block mb-1 font-medium">Admission Date</label>
                    <input type="date" name="admission_date" value="{{ old('admission_date') }}" class="w-full input">
                </div>
                <div>
                    <label class="block mb-1 font-medium">Group</label>
                    <select name="group" class="w-full input">
                        <option value="">-- Select Group --</option>
                        @foreach(['Science', 'Commerce', 'Arts'] as $grp)
                            <option value="{{ $grp }}" @selected(old('group') == $grp)>{{ $grp }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Previous School</label>
                    <input type="text" name="previous_school" value="{{ old('previous_school') }}" class="w-full input">
                </div>
            </div>
        </div>

        {{-- Guardian Info --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-4">👪 Guardian Information</h3>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block mb-1 font-medium">Father Name*</label>
                    <input type="text" name="father_name" value="{{ old('father_name') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Mother Name*</label>
                    <input type="text" name="mother_name" value="{{ old('mother_name') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Guardian Name</label>
                    <input type="text" name="guardian_name" value="{{ old('guardian_name') }}" class="w-full input">
                </div>
                <div>
                    <label class="block mb-1 font-medium">Mobile</label>
                    <input type="text" name="mobile" value="{{ old('mobile') }}" class="w-full input">
                </div>
                <div>
                    <label class="block mb-1 font-medium">Email</label>
                    <input type="email" name="email" value="{{ old('email') }}" class="w-full input">
                </div>
            </div>
        </div>

        {{-- Address --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-4">📍 Address</h3>
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block mb-1 font-medium">Present Address</label>
                    <textarea name="present_address" rows="2" class="w-full input">{{ old('present_address') }}</textarea>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Permanent Address</label>
                    <textarea name="permanent_address" rows="2" class="w-full input">{{ old('permanent_address') }}</textarea>
                </div>
            </div>
        </div>

        {{-- Extra Info --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-4">📝 Extra Information</h3>
            <div class="space-y-4">
                <div>
                    <label class="block mb-1 font-medium">Exam Records</label>
                    <textarea name="exam_records" rows="3" class="w-full input">{{ old('exam_records') }}</textarea>
                </div>
                <div class="grid md:grid-cols-2 gap-4">
                    <div>
                        <label class="block mb-1 font-medium">Status</label>
                        <select name="status" class="w-full input">
                            @foreach(['Active', 'Inactive', 'Transferred', 'Dropped Out'] as $status)
                                <option value="{{ $status }}" @selected(old('status') == $status)>{{ $status }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="block mb-1 font-medium">Remarks</label>
                        <input type="text" name="remarks" value="{{ old('remarks') }}" class="w-full input">
                    </div>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Special Note</label>
                    <textarea name="special_note" rows="2" class="w-full input">{{ old('special_note') }}</textarea>
                </div>
            </div>
        </div>

        {{-- Documents Upload --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-4">📂 Upload Documents</h3>
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block font-medium">Profile Photo</label>
                    <input type="file" name="photo" class="w-full input">
                </div>
                <div>
                    <label class="block font-medium">Transfer Certificate</label>
                    <input type="file" name="transfer_certificate" class="w-full input">
                </div>
                <div>
                    <label class="block font-medium">Birth Certificate</label>
                    <input type="file" name="birth_certificate" class="w-full input">
                </div>
                <div>
                    <label class="block font-medium">Admission Form</label>
                    <input type="file" name="admission_form" class="w-full input">
                </div>
                <div class="md:col-span-2">
                    <label class="block font-medium">Additional Documents</label>
                    <input type="file" name="additional_documents" class="w-full input">
                </div>
            </div>
        </div>

        {{-- Submit --}}
        <div class="flex justify-end gap-4">
            <a href="{{ route('admin.students.index') }}" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary bg-purple-600 hover:bg-purple-700 text-white">Save Student</button>
        </div>
    </form>
</div>
@endsection
