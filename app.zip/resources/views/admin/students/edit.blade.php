@extends('layouts.adminapp')

@section('content')
<div class="container mx-auto p-6 max-w-4xl bg-white rounded-lg shadow-md">
    <h1 class="text-3xl font-bold mb-6 text-gray-800">✏️ Edit Student: <span class="text-purple-700">{{ $student->name }}</span></h1>

    @if ($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul class="list-disc list-inside">
                @foreach ($errors->all() as $error)
                    <li>• {{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.students.update', $student) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf
        @method('PUT')

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Student ID <span class="text-red-600">*</span></label>
            <input type="text" name="student_id" value="{{ old('student_id', $student->student_id) }}" required
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Name <span class="text-red-600">*</span></label>
            <input type="text" name="name" value="{{ old('name', $student->name) }}" required
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
        </div>

        <div class="flex gap-6">
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Class <span class="text-red-600">*</span></label>
                <input type="number" name="class" min="1" max="10" value="{{ old('class', $student->class) }}" required
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Section</label>
                <select name="section"
                    class="w-full border border-gray-300 rounded-md px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-purple-400">
                    <option value="">-- Select Section --</option>
                    @foreach(['A','B','C','D'] as $sec)
                        <option value="{{ $sec }}" @selected(old('section', $student->section) == $sec)>{{ $sec }}</option>
                    @endforeach
                </select>
            </div>
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Roll</label>
                <input type="number" name="roll" value="{{ old('roll', $student->roll) }}"
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
        </div>

        <div class="flex gap-6">
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Admission Date</label>
                <input type="date" name="admission_date" value="{{ old('admission_date', $student->admission_date) }}"
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Date of Birth <span class="text-red-600">*</span></label>
                <input type="date" name="dob" value="{{ old('dob', $student->dob) }}" required
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Gender <span class="text-red-600">*</span></label>
                <select name="gender" required
                    class="w-full border border-gray-300 rounded-md px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-purple-400">
                    <option value="">-- Select Gender --</option>
                    @foreach(['Male','Female','Other'] as $gender)
                        <option value="{{ $gender }}" @selected(old('gender', $student->gender) == $gender)>{{ $gender }}</option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="flex gap-6">
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Blood Group</label>
                <input type="text" name="blood_group" value="{{ old('blood_group', $student->blood_group) }}"
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Religion</label>
                <input type="text" name="religion" value="{{ old('religion', $student->religion) }}"
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">NID / Birth Certificate No.</label>
                <input type="text" name="nid_or_birth_cert" value="{{ old('nid_or_birth_cert', $student->nid_or_birth_cert) }}"
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Guardian Name</label>
            <input type="text" name="guardian_name" value="{{ old('guardian_name', $student->guardian_name) }}"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
        </div>

        <div class="flex gap-6">
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Father Name <span class="text-red-600">*</span></label>
                <input type="text" name="father_name" value="{{ old('father_name', $student->father_name) }}" required
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Mother Name <span class="text-red-600">*</span></label>
                <input type="text" name="mother_name" value="{{ old('mother_name', $student->mother_name) }}" required
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
        </div>

        <div class="flex gap-6">
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Mobile</label>
                <input type="text" name="mobile" value="{{ old('mobile', $student->mobile) }}"
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
            <div class="flex-1">
                <label class="block font-semibold mb-1 text-gray-700">Email</label>
                <input type="email" name="email" value="{{ old('email', $student->email) }}"
                    class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
            </div>
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Present Address</label>
            <textarea name="present_address" rows="2"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400">{{ old('present_address', $student->present_address) }}</textarea>
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Permanent Address</label>
            <textarea name="permanent_address" rows="2"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400">{{ old('permanent_address', $student->permanent_address) }}</textarea>
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Previous School</label>
            <input type="text" name="previous_school" value="{{ old('previous_school', $student->previous_school) }}"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Group</label>
            <select name="group"
                class="w-full border border-gray-300 rounded-md px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-purple-400">
                <option value="">-- Select Group --</option>
                @foreach(['Science', 'Commerce', 'Arts'] as $grp)
                    <option value="{{ $grp }}" @selected(old('group', $student->group) == $grp)>{{ $grp }}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Exam Records</label>
            <textarea name="exam_records" rows="3"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400">{{ old('exam_records', $student->exam_records) }}</textarea>
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Status</label>
            <select name="status"
                class="w-full border border-gray-300 rounded-md px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-purple-400">
                @foreach(['Active', 'Inactive', 'Transferred', 'Dropped Out'] as $status)
                    <option value="{{ $status }}" @selected(old('status', $student->status) == $status)>{{ $status }}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Remarks</label>
            <textarea name="remarks" rows="2"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400">{{ old('remarks', $student->remarks) }}</textarea>
        </div>

        <div>
            <label class="block font-semibold mb-1 text-gray-700">Special Note</label>
            <textarea name="special_note" rows="2"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400">{{ old('special_note', $student->special_note) }}</textarea>
        </div>

        <hr class="my-6 border-gray-300">

        <div>
            <label class="block font-semibold mb-2 text-gray-700">Photo (JPEG/PNG)</label>
            @if($student->photo)
                <div class="mb-3">
                    <img src="{{ asset('storage/' . $student->photo) }}" alt="Photo" class="h-24 w-24 rounded object-cover border" />
                </div>
            @endif
            <input type="file" name="photo" accept="image/*"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
        </div>

        <div>
            <label class="block font-semibold mb-2 text-gray-700">Transfer Certificate (PDF/JPEG/PNG)</label>
            @if($student->transfer_certificate)
                <div class="mb-3">
                    <a href="{{ asset('storage/' . $student->transfer_certificate) }}" target="_blank"
                        class="text-blue-600 hover:underline">View Existing File</a>
                </div>
            @endif
            <input type="file" name="transfer_certificate" accept=".pdf,image/*"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
        </div>

        <div>
            <label class="block font-semibold mb-2 text-gray-700">Birth Certificate (PDF/JPEG/PNG)</label>
            @if($student->birth_certificate)
                <div class="mb-3">
                    <a href="{{ asset('storage/' . $student->birth_certificate) }}" target="_blank"
                        class="text-blue-600 hover:underline">View Existing File</a>
                </div>
            @endif
            <input type="file" name="birth_certificate" accept=".pdf,image/*"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
        </div>

        <div>
            <label class="block font-semibold mb-2 text-gray-700">Admission Form (PDF/JPEG/PNG)</label>
            @if($student->admission_form)
                <div class="mb-3">
                    <a href="{{ asset('storage/' . $student->admission_form) }}" target="_blank"
                        class="text-blue-600 hover:underline">View Existing File</a>
                </div>
            @endif
            <input type="file" name="admission_form" accept=".pdf,image/*"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
        </div>

        <div>
            <label class="block font-semibold mb-2 text-gray-700">Additional Documents (PDF/JPEG/PNG)</label>
            @if($student->additional_documents)
                <div class="mb-3">
                    <a href="{{ asset('storage/' . $student->additional_documents) }}" target="_blank"
                        class="text-blue-600 hover:underline">View Existing File</a>
                </div>
            @endif
            <input type="file" name="additional_documents" accept=".pdf,image/*"
                class="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-400" />
        </div>

        <div class="flex gap-4 mt-6">
            <button type="submit"
                class="bg-purple-600 hover:bg-purple-700 text-black font-semibold px-6 py-2 rounded-md shadow-md transition duration-200">
                Update Student
            </button>
            <a href="{{ route('admin.students.index') }}"
                class="inline-block px-6 py-2 border border-gray-400 rounded-md text-gray-700 hover:bg-gray-100 transition duration-200">
                Cancel
            </a>
        </div>
    </form>
</div>
@endsection
