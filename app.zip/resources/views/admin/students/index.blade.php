@extends('layouts.adminapp')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">
    <!-- Header -->
    <div class="bg-purple-100 p-6 rounded-lg shadow-md mb-6 border border-purple-300">
        <h1 class="text-3xl font-bold text-gray-900 mb-2"><center>🎓 Student List Panel</center></h1>
        <p class="text-gray-800"><center>Manage student data from here — search, add, edit or delete.</center></p>
    </div>

    <!-- Success Message -->
    @if(session('success'))
        <div class="bg-green-100 border border-green-300 text-gray-900 px-4 py-3 rounded mb-4 shadow">
            {{ session('success') }}
        </div>
    @endif

    <!-- Search and Actions -->
    <div class="bg-white p-6 rounded-lg shadow mb-6 border border-gray-200">
        <form method="GET" action="{{ route('admin.students.index') }}" class="md:flex md:items-center md:gap-4 flex-wrap">
            <input type="text" name="search" placeholder="🔍 Search by name, student ID, class, roll..." 
                   value="{{ request('search') }}"
                   class="flex-grow border border-gray-300 rounded-md px-4 py-2 mb-2 md:mb-0 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-300 text-gray-900" />
            <div class="flex items-center gap-3 flex-wrap mt-2 md:mt-0">
                <button type="submit"
                    class="bg-white border border-purple-600 text-purple-600 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-purple-600 hover:text-white transition duration-200">
                    🔍 Search
                </button>

                <a href="{{ route('admin.students.index') }}"
                    class="bg-white border border-yellow-400 text-yellow-500 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-yellow-400 hover:text-white transition duration-200">
                    🔁 Clear
                </a>

                <a href="{{ route('admin.students.create') }}"
                    class="bg-white border border-green-600 text-green-600 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-green-600 hover:text-white transition duration-200">
                    ➕ Add Student
                </a>
            </div>
        </form>
    </div>

    <!-- Student Table -->
    <div class="overflow-x-auto">
        <table class="min-w-full table-auto border border-gray-300 rounded-lg overflow-hidden shadow-md">
            <thead class="bg-purple-200 text-gray-900 text-sm uppercase">
                <tr>
                    <th class="px-4 py-2 border">Student ID</th>
                    <th class="px-4 py-2 border text-center">Photo</th> <!-- Photo Column -->
                    <th class="px-4 py-2 border">Name</th>
                    <th class="px-4 py-2 border">Class</th>
                    <th class="px-4 py-2 border">Section</th>
                    <th class="px-4 py-2 border">Roll</th>
                    <th class="px-4 py-2 border">Status</th>
                    <th class="px-4 py-2 border">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white text-gray-900">
                @forelse($students as $student)
                    <tr class="hover:bg-purple-50 transition">
                        <td class="px-4 py-2 border">{{ $student->student_id }}</td>

                        <!-- Profile Photo -->
                        <td class="px-4 py-2 border text-center align-middle" style="width: 60px; max-width: 60px;">
                            @if($student->photo)
                                <div style="width: 60px; height: 60px; margin: 0 auto; overflow: hidden; border-radius: 50%; border: 1px solid #d1d5db;">
                                    <img src="{{ asset('storage/' . $student->photo) }}" 
                                         alt="Photo of {{ $student->name }}" 
                                         style="width: 100%; height: 100%; object-fit: cover; display: block;">
                                </div>
                            @else
                                <span class="text-gray-400">N/A</span>
                            @endif
                        </td>

                        <td class="px-4 py-2 border">{{ $student->name }}</td>
                        <td class="px-4 py-2 border">{{ $student->class }}</td>
                        <td class="px-4 py-2 border">{{ $student->section ?? '-' }}</td>
                        <td class="px-4 py-2 border">{{ $student->roll ?? '-' }}</td>
                        <td class="px-4 py-2 border">
                            <span class="inline-block px-3 py-1 rounded-full text-white text-sm font-semibold {{ $student->status == 'Active' ? 'bg-green-600' : 'bg-red-600' }}">
                                {{ $student->status }}
                            </span>
                        </td>
                        <td class="px-4 py-2 border space-x-2 text-sm">
                            <a href="{{ route('admin.students.show', $student) }}"
                                class="inline-block bg-white border border-emerald-600 text-emerald-600 px-3 py-1 rounded-md shadow-sm hover:bg-emerald-600 hover:text-white transition duration-200">
                                🔍 View
                            </a>

                            <a href="{{ route('admin.students.edit', $student) }}"
                                class="inline-block bg-white border border-sky-600 text-sky-600 px-3 py-1 rounded-md shadow-sm hover:bg-sky-600 hover:text-white transition duration-200">
                                ✏️ Edit
                            </a>

                            <form action="{{ route('admin.students.destroy', $student) }}" method="POST" class="inline-block"
                                onsubmit="return confirm('Are you sure?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit"
                                    class="bg-white border border-rose-600 text-rose-600 px-3 py-1 rounded-md shadow-sm hover:bg-rose-600 hover:text-white transition duration-200">
                                    🗑️ Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" class="text-center py-4 text-gray-600">No students found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        {{ $students->withQueryString()->links() }}
    </div>
</div>
@endsection
