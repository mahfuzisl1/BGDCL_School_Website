@extends('layouts.adminapp')

@section('content')
<div class="container mx-auto p-6 max-w-4xl bg-white rounded-lg shadow-md">
  <h2 class="text-3xl font-bold text-purple-700 mb-6">✏️ Edit Teacher: {{ $teacher->full_name }}</h2>

  @if ($errors->any())
    <div class="bg-red-100 border border-red-400 text-red-700 p-4 rounded mb-6">
      <ul class="list-disc pl-5">
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
  @endif

  <form action="{{ route('admin.teachers.update', $teacher->id) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
    @csrf
    @method('PUT')

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

      <!-- full_name -->
      <div>
        <label class="font-semibold" for="full_name">Full Name *</label>
        <input type="text" id="full_name" name="full_name"
          value="{{ old('full_name', $teacher->full_name) }}" class="w-full border rounded p-2" required>
      </div>

      <!-- designation -->
      <div>
        <label class="font-semibold" for="designation">Designation *</label>
        <input type="text" id="designation" name="designation"
          value="{{ old('designation', $teacher->designation) }}" class="w-full border rounded p-2" required>
      </div>

      <!-- department -->
      <div>
        <label class="font-semibold" for="department">Department</label>
        <input type="text" id="department" name="department"
          value="{{ old('department', $teacher->department) }}" class="w-full border rounded p-2">
      </div>

      <!-- subjects -->
      <div>
        <label class="font-semibold" for="subjects">Subjects Taught *</label>
        <select id="subjects" name="subjects[]" multiple required class="w-full border rounded p-2">
          @php
            $oldSubjects = old('subjects', $teacher->subjects ?? []);
          @endphp
          @foreach(['Mathematics','English','Bangla','Science','History'] as $sub)
            <option value="{{ $sub }}" @if(in_array($sub, $oldSubjects)) selected @endif>{{ $sub }}</option>
          @endforeach
        </select>
      </div>

      <!-- gender -->
      <div>
        <label class="font-semibold" for="gender">Gender *</label>
        <select id="gender" name="gender" class="w-full border rounded p-2" required>
          <option value="">Select</option>
          <option value="Male" @selected(old('gender', $teacher->gender)=='Male')>Male</option>
          <option value="Female" @selected(old('gender', $teacher->gender)=='Female')>Female</option>
          <option value="Other" @selected(old('gender', $teacher->gender)=='Other')>Other</option>
        </select>
      </div>

      <!-- dob -->
      <div>
        <label class="font-semibold" for="dob">Date of Birth *</label>
        <input type="date" id="dob" name="dob"
          value="{{ old('dob', \Carbon\Carbon::parse($teacher->dob)->format('Y-m-d')) }}" class="w-full border rounded p-2" required>
      </div>

      <!-- religion -->
      <div>
        <label class="font-semibold" for="religion">Religion *</label>
        <input type="text" id="religion" name="religion"
          value="{{ old('religion', $teacher->religion) }}" class="w-full border rounded p-2" required>
      </div>

      <!-- blood_group -->
      <div>
        <label class="font-semibold" for="blood_group">Blood Group</label>
        <input type="text" id="blood_group" name="blood_group"
          value="{{ old('blood_group', $teacher->blood_group) }}" class="w-full border rounded p-2">
      </div>

      <!-- joining_date -->
      <div>
        <label class="font-semibold" for="joining_date">Joining Date *</label>
        <input type="date" id="joining_date" name="joining_date"
          value="{{ old('joining_date', \Carbon\Carbon::parse($teacher->joining_date)->format('Y-m-d')) }}" class="w-full border rounded p-2" required>
      </div>

      <!-- national_id -->
      <div>
        <label class="font-semibold" for="national_id">National ID *</label>
        <input type="text" id="national_id" name="national_id"
          value="{{ old('national_id', $teacher->national_id) }}" class="w-full border rounded p-2" required>
      </div>

      <!-- mobile -->
      <div>
        <label class="font-semibold" for="mobile">Mobile Number *</label>
        <input type="text" id="mobile" name="mobile"
          value="{{ old('mobile', $teacher->mobile) }}" class="w-full border rounded p-2" required>
      </div>

      <!-- email -->
      <div>
        <label class="font-semibold" for="email">Email</label>
        <input type="email" id="email" name="email"
          value="{{ old('email', $teacher->email) }}" class="w-full border rounded p-2">
      </div>

      <!-- emergency_contact -->
      <div>
        <label class="font-semibold" for="emergency_contact">Emergency Contact</label>
        <input type="text" id="emergency_contact" name="emergency_contact"
          value="{{ old('emergency_contact', $teacher->emergency_contact) }}" class="w-full border rounded p-2">
      </div>

      <!-- present_address -->
      <div class="md:col-span-2">
        <label class="font-semibold" for="present_address">Present Address *</label>
        <textarea id="present_address" name="present_address" rows="2" class="w-full border rounded p-2" required>{{ old('present_address', $teacher->present_address) }}</textarea>
      </div>

      <!-- permanent_address -->
      <div class="md:col-span-2">
        <label class="font-semibold" for="permanent_address">Permanent Address *</label>
        <textarea id="permanent_address" name="permanent_address" rows="2" class="w-full border rounded p-2" required>{{ old('permanent_address', $teacher->permanent_address) }}</textarea>
      </div>

      <!-- highest_qualification -->
      <div>
        <label class="font-semibold" for="highest_qualification">Highest Qualification *</label>
        <input type="text" id="highest_qualification" name="highest_qualification"
          value="{{ old('highest_qualification', $teacher->highest_qualification) }}" class="w-full border rounded p-2" required>
      </div>

      <!-- professional_degrees -->
      <div>
        <label class="font-semibold" for="professional_degrees">Professional Degrees</label>
        <select id="professional_degrees" name="professional_degrees[]" multiple class="w-full border rounded p-2">
          @php
            $oldDegrees = old('professional_degrees',
              is_string($teacher->professional_degrees)
                ? json_decode($teacher->professional_degrees)
                : ($teacher->professional_degrees ?? [])
            );
          @endphp
          @foreach(['B.Ed','M.Ed','PhD','MSc','MA'] as $deg)
            <option value="{{ $deg }}" @if(in_array($deg, $oldDegrees)) selected @endif>{{ $deg }}</option>
          @endforeach
        </select>
      </div>

      <!-- experience_years -->
      <div>
        <label class="font-semibold" for="experience_years">Experience (years) *</label>
        <input type="number" id="experience_years" name="experience_years" min="0"
          value="{{ old('experience_years', $teacher->experience_years) }}" class="w-full border rounded p-2" required>
      </div>

      <!-- previous_institutions -->
      <div class="md:col-span-2">
        <label class="font-semibold" for="previous_institutions">Previous Institutions</label>
        <textarea id="previous_institutions" name="previous_institutions" rows="2" class="w-full border rounded p-2">{{ old('previous_institutions', $teacher->previous_institutions) }}</textarea>
      </div>

      <!-- special_skills -->
      <div class="md:col-span-2">
        <label class="font-semibold" for="special_skills">Special Skills / Trainings</label>
        <textarea id="special_skills" name="special_skills" rows="2" class="w-full border rounded p-2">{{ old('special_skills', $teacher->special_skills) }}</textarea>
      </div>

      <!-- employment_status -->
      <div>
        <label class="font-semibold" for="employment_status">Employment Status *</label>
        <select id="employment_status" name="employment_status" class="w-full border rounded p-2" required>
          <option value="">Select</option>
          <option value="Active" @selected(old('employment_status', $teacher->employment_status)=='Active')>Active</option>
          <option value="On Leave" @selected(old('employment_status', $teacher->employment_status)=='On Leave')>On Leave</option>
          <option value="Retired" @selected(old('employment_status', $teacher->employment_status)=='Retired')>Retired</option>
          <option value="Terminated" @selected(old('employment_status', $teacher->employment_status)=='Terminated')>Terminated</option>
        </select>
      </div>

      <!-- remarks -->
      <div class="md:col-span-2">
        <label class="font-semibold" for="remarks">Remarks</label>
        <textarea id="remarks" name="remarks" rows="2" class="w-full border rounded p-2">{{ old('remarks', $teacher->remarks) }}</textarea>
      </div>

      <!-- is_class_teacher -->
      <div class="flex items-center space-x-2">
        <input type="checkbox" id="is_class_teacher" name="is_class_teacher" value="1" @checked(old('is_class_teacher', $teacher->is_class_teacher))>
        <label class="font-semibold" for="is_class_teacher">Assign as Class Teacher?</label>
      </div>

      <!-- class_teacher_of -->
      <div id="class_teacher_div" class="{{ old('is_class_teacher', $teacher->is_class_teacher) ? '' : 'hidden' }}">
        <label class="font-semibold" for="class_teacher_of">Class Teacher of</label>
        <select id="class_teacher_of" name="class_teacher_of" class="w-full border rounded p-2">
          <option value="">None</option>
          @foreach(range(1,10) as $c)
            <option value="{{ $c }}" @selected(old('class_teacher_of', $teacher->class_teacher_of) == (string)$c)>{{ $c }}</option>
          @endforeach
        </select>
      </div>

      <!-- uploads -->
     <!-- Profile Photo -->
<div class="md:col-span-6">
    <label for="profile_photo" class="block text-sm font-medium text-gray-700">Profile Photo (jpg/png)</label>
    <input type="file" name="profile_photo" id="profile_photo" accept="image/*"
        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500">

    {{-- Small preview thumbnail --}}
    @if ($teacher->profile_photo)
        <div class="mt-3 flex items-center space-x-2">
            <span class="text-sm text-gray-500">Current:</span>
            <img src="{{ asset('storage/' . $teacher->profile_photo) }}" alt="Profile Photo"
                 class="w-12 h-12 rounded-full object-cover ring-1 ring-gray-300 shadow-sm">
        </div>
    @endif
</div>



      <div class="md:col-span-2">
        <label class="font-semibold" for="cv_attachment">CV (pdf/doc)</label>
        <input type="file" id="cv_attachment" name="cv_attachment" class="w-full">
        @if($teacher->cv_attachment)
          <p class="mt-1 text-sm text-gray-600">Current file: <a href="{{ asset('storage/'.$teacher->cv_attachment) }}" target="_blank" class="text-blue-600 hover:underline">View CV</a></p>
        @endif
      </div>

      <div class="md:col-span-2">
        <label class="font-semibold" for="certificates_attachment">Certificates (pdf/doc) – multiple</label>
        <input type="file" id="certificates_attachment" name="certificates_attachment[]" multiple class="w-full">
        @php
          $certs = is_string($teacher->certificates_attachment)
            ? json_decode($teacher->certificates_attachment)
            : ($teacher->certificates_attachment ?? []);
        @endphp
        @if(count($certs))
          <p class="mt-1 text-sm text-gray-600">Current files:
            @foreach($certs as $cert)
              <a href="{{ asset('storage/'.$cert) }}" target="_blank" class="text-blue-600 hover:underline mr-2">Cert</a>
            @endforeach
          </p>
        @endif
      </div>

      <div class="md:col-span-2">
        <label class="font-semibold" for="nid_attachment">NID Attachment (pdf)</label>
        <input type="file" id="nid_attachment" name="nid_attachment" class="w-full">
        @if($teacher->nid_attachment)
          <p class="mt-1 text-sm text-gray-600">Current file: <a href="{{ asset('storage/'.$teacher->nid_attachment) }}" target="_blank" class="text-blue-600 hover:underline">View NID</a></p>
        @endif
      </div>

      <div class="md:col-span-2">
        <label class="font-semibold" for="joining_letter">Joining Letter (pdf)</label>
        <input type="file" id="joining_letter" name="joining_letter" class="w-full">
        @if($teacher->joining_letter)
          <p class="mt-1 text-sm text-gray-600">Current file: <a href="{{ asset('storage/'.$teacher->joining_letter) }}" target="_blank" class="text-blue-600 hover:underline">View Letter</a></p>
        @endif
      </div>

      <div class="md:col-span-2">
        <label class="font-semibold" for="other_documents">Other Documents (pdf/zip)</label>
        <input type="file" id="other_documents" name="other_documents" class="w-full">
        @if($teacher->other_documents)
          <p class="mt-1 text-sm text-gray-600">Current file: <a href="{{ asset('storage/'.$teacher->other_documents) }}" target="_blank" class="text-blue-600 hover:underline">View Docs</a></p>
        @endif
      </div>

    </div>

    <button type="submit" class="w-full md:w-auto bg-purple-600 hover:bg-purple-700 text-black px-6 py-2 rounded">
      Update Teacher
    </button>

  </form>
</div>

<script>
  document.getElementById('is_class_teacher').addEventListener('change', function(){
    document.getElementById('class_teacher_div').classList.toggle('hidden', !this.checked);
  });
</script>
@endsection
