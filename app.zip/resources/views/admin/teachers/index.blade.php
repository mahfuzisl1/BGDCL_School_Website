@extends('layouts.adminapp')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">
    <!-- Header -->
    <div class="bg-purple-100 p-6 rounded-lg shadow-md mb-6 border border-purple-300">
        <h1 class="text-3xl font-bold text-gray-900 mb-2"><center>👩‍🏫 Teacher List Panel</h1>
        <p class="text-gray-800"><center>Manage teacher data from here — search, add, edit or delete.</p>
    </div>

    <!-- Success Message -->
    @if(session('success'))
        <div class="bg-green-100 border border-green-300 text-gray-900 px-4 py-3 rounded mb-6 shadow">
            {{ session('success') }}
        </div>
    @endif

    <!-- Search and Actions -->
    <div class="bg-white p-6 rounded-lg shadow mb-6 border border-gray-200">
        <form method="GET" action="{{ route('admin.teachers.index') }}" class="md:flex md:items-center md:gap-4 flex-wrap">
            <input
                type="text"
                name="search"
                placeholder="🔍 Search by Name, ID, Mobile"
                value="{{ request('search') }}"
                class="flex-grow border border-gray-300 rounded-md px-4 py-2 mb-2 md:mb-0 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-300 text-gray-900"
            />
            <div class="flex items-center gap-3 flex-wrap mt-2 md:mt-0">
                <button
                    type="submit"
                    class="bg-white border border-purple-600 text-purple-600 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-purple-600 hover:text-white transition duration-200"
                >
                    🔍 Search
                </button>

                <a
                    href="{{ route('admin.teachers.index') }}"
                    class="bg-white border border-yellow-400 text-yellow-500 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-yellow-400 hover:text-white transition duration-200"
                >
                    🔁 Clear
                </a>

                <a
                    href="{{ route('admin.teachers.create') }}"
                    class="bg-white border border-green-600 text-green-600 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-green-600 hover:text-white transition duration-200"
                >
                    ➕ Add Teacher
                </a>
            </div>
        </form>
    </div>

    <!-- Teacher Table -->
    <div class="overflow-x-auto">
        <table class="min-w-full table-auto border border-gray-300 rounded-lg overflow-hidden shadow-md text-gray-900 text-sm">
            <thead class="bg-purple-200 text-gray-900 uppercase">
                <tr>
                    <th class="px-4 py-2 border">ID</th>
                    <th class="px-4 py-2 border">Name</th>
                    <th class="px-4 py-2 border">Designation</th>
                    <th class="px-4 py-2 border">Department</th>
                    <th class="px-4 py-2 border">Mobile</th>
                    <th class="px-4 py-2 border">Email</th>
                    <th class="px-4 py-2 border">Gender</th>
                    <th class="px-4 py-2 border">Status</th>
                    <th class="px-4 py-2 border">Class Teacher</th>
                    <th class="px-4 py-2 border text-center">Photo</th>
                    <th class="px-4 py-2 border text-center">CV</th>
                    <th class="px-4 py-2 border text-center">NID</th>
                    <th class="px-4 py-2 border text-center">Joining Letter</th>
                    <th class="px-4 py-2 border text-center">Other Docs</th>
                    <th class="px-4 py-2 border text-center">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white">
                @forelse ($teachers as $teacher)
                    <tr class="hover:bg-purple-50 transition">
                        <td class="px-4 py-2 border">{{ $teacher->teacher_id }}</td>
                        <td class="px-4 py-2 border">{{ $teacher->full_name }}</td>
                        <td class="px-4 py-2 border">{{ $teacher->designation }}</td>
                        <td class="px-4 py-2 border">{{ $teacher->department }}</td>
                        <td class="px-4 py-2 border">{{ $teacher->mobile }}</td>
                        <td class="px-4 py-2 border">{{ $teacher->email }}</td>
                        <td class="px-4 py-2 border">{{ $teacher->gender }}</td>
                        <td class="px-4 py-2 border">
                            <span
                                class="inline-block px-3 py-1 rounded-full text-white text-sm font-semibold
                                {{ $teacher->employment_status == 'Active' ? 'bg-green-600' : 'bg-red-600' }}"
                            >
                                {{ $teacher->employment_status }}
                            </span>
                        </td>
                        <td class="px-4 py-2 border">{{ $teacher->class_teacher_of ?? '-' }}</td>

                        <!-- Photo -->

<!-- Photo -->
<td class="px-4 py-2 border text-center align-middle" style="width: 60px; max-width: 60px;">
    @if($teacher->profile_photo)
        <div style="width: 60px; height: 60px; margin: 0 auto; overflow: hidden; border-radius: 50%; border: 1px solid #d1d5db;">
            <img src="{{ asset('storage/'.$teacher->profile_photo) }}" 
                 alt="Photo of {{ $teacher->full_name }}" 
                 style="width: 100%; height: 100%; object-fit: cover; display: block;">
        </div>
    @else
        <span class="text-gray-400">N/A</span>
    @endif
</td>




                        <!-- CV -->
                        <td class="px-4 py-2 border text-center">
                            @if($teacher->cv_attachment)
                                <a href="{{ asset('storage/'.$teacher->cv_attachment) }}" target="_blank" class="text-blue-600 hover:underline">CV</a>
                            @else
                                <span class="text-gray-400">N/A</span>
                            @endif
                        </td>

                        <!-- NID -->
                        <td class="px-4 py-2 border text-center">
                            @if($teacher->nid_attachment)
                                <a href="{{ asset('storage/'.$teacher->nid_attachment) }}" target="_blank" class="text-blue-600 hover:underline">NID</a>
                            @else
                                <span class="text-gray-400">N/A</span>
                            @endif
                        </td>

                        <!-- Joining Letter -->
                        <td class="px-4 py-2 border text-center">
                            @if($teacher->joining_letter)
                                <a href="{{ asset('storage/'.$teacher->joining_letter) }}" target="_blank" class="text-blue-600 hover:underline">Join</a>
                            @else
                                <span class="text-gray-400">N/A</span>
                            @endif
                        </td>

                        <!-- Other Docs -->
                        <td class="px-4 py-2 border text-center">
                            @if($teacher->other_documents)
                                <a href="{{ asset('storage/'.$teacher->other_documents) }}" target="_blank" class="text-blue-600 hover:underline">Docs</a>
                            @else
                                <span class="text-gray-400">N/A</span>
                            @endif
                        </td>

                        <!-- Actions -->
                        <td class="px-4 py-2 border whitespace-nowrap text-center space-x-2 text-sm">
                            <a href="{{ route('admin.teachers.edit', $teacher->id) }}"
                                class="inline-block bg-white border border-sky-600 text-sky-600 px-3 py-1 rounded-md shadow-sm hover:bg-sky-600 hover:text-white transition duration-200"
                            >
                                ✏️ Edit
                            </a>

                            <form action="{{ route('admin.teachers.destroy', $teacher->id) }}" method="POST" class="inline-block"
                                onsubmit="return confirm('Are you sure?');"
                            >
                                @csrf
                                @method('DELETE')
                                <button
                                    type="submit"
                                    class="bg-white border border-rose-600 text-rose-600 px-3 py-1 rounded-md shadow-sm hover:bg-rose-600 hover:text-white transition duration-200"
                                >
                                    🗑️ Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="15" class="text-center py-4 text-gray-600">No teachers found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        {{ $teachers->withQueryString()->links() }}
    </div>
</div>
@endsection
