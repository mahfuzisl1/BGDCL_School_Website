@extends('layouts.adminapp')

@section('content')
<div class="max-w-5xl mx-auto p-6">
    <h2 class="text-3xl font-bold text-purple-700 mb-6"><center>👩‍🏫 Register New Teacher</h2>

    @if ($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 p-4 rounded mb-6">
            <ul class="list-disc pl-5">
                @foreach ($errors->all() as $error)
                    <li>• {{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.teachers.store') }}" method="POST" enctype="multipart/form-data" class="space-y-8">
        @csrf

        {{-- Basic Information --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-6">👤 Personal Information</h3>
            <div class="grid md:grid-cols-2 gap-6">
                <div>
                    <label class="block mb-1 font-medium">Full Name *</label>
                    <input type="text" name="full_name" value="{{ old('full_name') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Designation *</label>
                    <input type="text" name="designation" value="{{ old('designation') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Department</label>
                    <input type="text" name="department" value="{{ old('department') }}" class="w-full input">
                </div>
                <div>
                    <label class="block mb-1 font-medium">Subjects Taught *</label>
                    <select name="subjects[]" multiple class="w-full input" required>
                        @foreach(['Mathematics','English','Bangla','Science','History'] as $sub)
                            <option value="{{ $sub }}" @if(in_array($sub, old('subjects', []))) selected @endif>{{ $sub }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Gender *</label>
                    <select name="gender" class="w-full input" required>
                        <option value="">-- Select Gender --</option>
                        @foreach(['Male','Female','Other'] as $gender)
                            <option value="{{ $gender }}" @selected(old('gender') == $gender)>{{ $gender }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Date of Birth *</label>
                    <input type="date" name="dob" value="{{ old('dob') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Religion *</label>
                    <input type="text" name="religion" value="{{ old('religion') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Blood Group</label>
                    <input type="text" name="blood_group" value="{{ old('blood_group') }}" class="w-full input">
                </div>
            </div>
        </div>

        {{-- Employment Details --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-4">🏢 Employment Information</h3>
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block mb-1 font-medium">Joining Date *</label>
                    <input type="date" name="joining_date" value="{{ old('joining_date') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">National ID *</label>
                    <input type="text" name="national_id" value="{{ old('national_id') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Mobile Number *</label>
                    <input type="text" name="mobile" value="{{ old('mobile') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Email</label>
                    <input type="email" name="email" value="{{ old('email') }}" class="w-full input">
                </div>
                <div>
                    <label class="block mb-1 font-medium">Emergency Contact</label>
                    <input type="text" name="emergency_contact" value="{{ old('emergency_contact') }}" class="w-full input">
                </div>
                <div>
                    <label class="block mb-1 font-medium">Highest Qualification *</label>
                    <input type="text" name="highest_qualification" value="{{ old('highest_qualification') }}" class="w-full input" required>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Professional Degrees</label>
                    <select name="professional_degrees[]" multiple class="w-full input">
                        @foreach(['B.Ed','M.Ed','PhD','MSc','MA'] as $deg)
                            <option value="{{ $deg }}" @if(in_array($deg, old('professional_degrees', []))) selected @endif>{{ $deg }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Experience (years) *</label>
                    <input type="number" min="0" name="experience_years" value="{{ old('experience_years', 0) }}" class="w-full input" required>
                </div>
                <div class="md:col-span-2">
                    <label class="block mb-1 font-medium">Previous Institutions</label>
                    <textarea name="previous_institutions" rows="2" class="w-full input">{{ old('previous_institutions') }}</textarea>
                </div>
                <div class="md:col-span-2">
                    <label class="block mb-1 font-medium">Special Skills / Trainings</label>
                    <textarea name="special_skills" rows="2" class="w-full input">{{ old('special_skills') }}</textarea>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Employment Status *</label>
                    <select name="employment_status" class="w-full input" required>
                        @foreach(['Active', 'On Leave', 'Retired', 'Terminated'] as $status)
                            <option value="{{ $status }}" @selected(old('employment_status') == $status)>{{ $status }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="md:col-span-2">
                    <label class="block mb-1 font-medium">Remarks</label>
                    <textarea name="remarks" rows="2" class="w-full input">{{ old('remarks') }}</textarea>
                </div>

                <div class="flex items-center space-x-2">
                    <input type="checkbox" name="is_class_teacher" id="is_class_teacher" value="1" @checked(old('is_class_teacher'))>
                    <label class="font-semibold">Assign as Class Teacher?</label>
                </div>

                <div id="class_teacher_div" class="{{ old('is_class_teacher') ? '' : 'hidden' }}">
                    <label class="block mb-1 font-medium">Class Teacher of</label>
                    <select name="class_teacher_of" class="w-full input">
                        <option value="">None</option>
                        @foreach(range(1,10) as $c)
                            <option value="{{ $c }}" @selected(old('class_teacher_of') == (string)$c)>{{ $c }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>

        {{-- Address --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-4">📍 Address</h3>
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block mb-1 font-medium">Present Address *</label>
                    <textarea name="present_address" rows="2" class="w-full input" required>{{ old('present_address') }}</textarea>
                </div>
                <div>
                    <label class="block mb-1 font-medium">Permanent Address *</label>
                    <textarea name="permanent_address" rows="2" class="w-full input" required>{{ old('permanent_address') }}</textarea>
                </div>
            </div>
        </div>

        {{-- Documents Upload --}}
        <div class="bg-purple-50 border border-purple-200 p-6 rounded-lg shadow">
            <h3 class="text-xl font-semibold text-purple-600 mb-4">📂 Upload Documents</h3>
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block font-medium">Profile Photo (jpg/png)</label>
                    <input type="file" name="profile_photo" class="w-full input">
                </div>
                <div>
                    <label class="block font-medium">CV (pdf/doc)</label>
                    <input type="file" name="cv_attachment" class="w-full input">
                </div>
                <div>
                    <label class="block font-medium">Certificates (pdf/doc) – multiple</label>
                    <input type="file" name="certificates_attachment[]" multiple class="w-full input">
                </div>
                <div>
                    <label class="block font-medium">NID Attachment (pdf)</label>
                    <input type="file" name="nid_attachment" class="w-full input">
                </div>
                <div>
                    <label class="block font-medium">Joining Letter (pdf)</label>
                    <input type="file" name="joining_letter" class="w-full input">
                </div>
                <div>
                    <label class="block font-medium">Other Documents (pdf/zip)</label>
                    <input type="file" name="other_documents" class="w-full input">
                </div>
            </div>
        </div>

        {{-- Submit --}}
        <div class="flex justify-end gap-4">
            <a href="{{ route('admin.teachers.index') }}" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary bg-purple-600 hover:bg-purple-700 text-white">Save Teacher</button>
        </div>
    </form>
</div>

<script>
document.getElementById('is_class_teacher').addEventListener('change', function(){
    document.getElementById('class_teacher_div').classList.toggle('hidden', !this.checked);
});
</script>
@endsection
