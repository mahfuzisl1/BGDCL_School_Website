@extends('layouts.app')

@section('title', 'Admin Dashboard')

@section('content')
<div class="container mx-auto mt-10 px-4">
    <h1 class="text-4xl font-extrabold mb-6 text-purple-700 text-center flex justify-center items-center gap-3">
        <span>🎓</span> Welcome, Admin!
    </h1>

    <h2 class="text-2xl font-semibold mb-8 text-gray-700 flex items-center gap-2">
        <span>📂</span> Manage Sections
    </h2>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-10">
        <a href="{{ route('admin.gallery.index') }}" class="bg-gradient-to-r from-green-400 to-green-600 text-white rounded-xl shadow-lg p-6 flex items-center gap-4 transform transition duration-300 hover:scale-105 hover:shadow-2xl">
            <span class="text-3xl">🖼️</span>
            <span class="text-lg font-semibold">Manage Gallery</span>
        </a>
        <a href="{{ route('admin.notices.index') }}" class="bg-gradient-to-r from-yellow-400 to-yellow-500 text-gray-900 rounded-xl shadow-lg p-6 flex items-center gap-4 transform transition duration-300 hover:scale-105 hover:shadow-2xl">
            <span class="text-3xl">🔔</span>
            <span class="text-lg font-semibold">Manage Notices</span>
        </a>
        <a href="{{ route('admin.students.index') }}" class="bg-gradient-to-r from-blue-400 to-blue-600 text-white rounded-xl shadow-lg p-6 flex items-center gap-4 transform transition duration-300 hover:scale-105 hover:shadow-2xl">
            <span class="text-3xl">🎓</span>
            <span class="text-lg font-semibold">Manage Students</span>
        </a>
        <a href="{{ route('admin.teachers.index') }}" class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl shadow-lg p-6 flex items-center gap-4 transform transition duration-300 hover:scale-105 hover:shadow-2xl">
            <span class="text-3xl">👩‍🏫</span>
            <span class="text-lg font-semibold">Manage Teachers</span>
        </a>
        <a href="{{ route('admin.staffs.index') }}" class="bg-gradient-to-r from-green-500 to-green-700 text-white rounded-xl shadow-lg p-6 flex items-center gap-4 transform transition duration-300 hover:scale-105 hover:shadow-2xl">
            <span class="text-3xl">🧑‍💼</span>
            <span class="text-lg font-semibold">Manage Staffs</span>
        </a>
        <a href="{{ route('admin.results.index') }}" class="bg-gradient-to-r from-blue-500 to-blue-700 text-white rounded-xl shadow-lg p-6 flex items-center gap-4 transform transition duration-300 hover:scale-105 hover:shadow-2xl">
            <span class="text-3xl">📄</span>
            <span class="text-lg font-semibold">Manage Results</span>
        </a>
        <a href="{{ route('admin.examfiles.index') }}" class="bg-gradient-to-r from-blue-400 to-cyan-500 text-white rounded-xl shadow-lg p-6 flex items-center gap-4 transform transition duration-300 hover:scale-105 hover:shadow-2xl">
            <span class="text-3xl">🗓️</span>
            <span class="text-lg font-semibold">Manage Exam Schedules</span>
        </a>
        <a href="{{ route('admin.classmaterials.index') }}" class="bg-gradient-to-r from-yellow-400 to-yellow-500 text-gray-900 rounded-xl shadow-lg p-6 flex items-center gap-4 transform transition duration-300 hover:scale-105 hover:shadow-2xl">
            <span class="text-3xl">📚</span>
            <span class="text-lg font-semibold">Manage Class Materials</span>
        </a>
        <a href="{{ route('admin.informations.index') }}" class="bg-gradient-to-r from-purple-400 to-purple-600 text-white rounded-xl shadow-lg p-6 flex items-center gap-4 transform transition duration-300 hover:scale-105 hover:shadow-2xl">
            <span class="text-3xl">ℹ️</span>
            <span class="text-lg font-semibold">Manage Informations</span>
        </a>
    </div>

    <form method="POST" action="{{ route('admin.logout') }}" class="max-w-xs mx-auto">
        @csrf
        <button type="submit" class="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white rounded-xl shadow-lg py-3 font-semibold flex justify-center items-center gap-3 transition-transform duration-300 hover:scale-105">
            <span class="text-2xl">🔓</span> Logout
        </button>
    </form>
</div>
@endsection
