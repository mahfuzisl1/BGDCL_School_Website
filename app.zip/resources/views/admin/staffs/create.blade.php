@extends('layouts.adminapp')

@section('content')
<div class="max-w-5xl mx-auto p-6">
    <div class="bg-white shadow-lg rounded-xl p-6">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">নতুন স্টাফ যোগ করুন</h2>

        @if ($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <ul class="list-disc pl-5 text-sm">
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        <form action="{{ route('admin.staffs.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
            @csrf

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <!-- Personal Info -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">নাম (পূর্ণ নাম)</label>
                    <input type="text" name="name" value="{{ old('name') }}" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-blue-300" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">পদবী</label>
                    <input type="text" name="designation" value="{{ old('designation') }}" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-blue-300" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">লিঙ্গ</label>
                    <select name="gender" required class="w-full border rounded-lg px-3 py-2">
                        <option value="">নির্বাচন করুন</option>
                        <option value="পুরুষ" {{ old('gender') == 'পুরুষ' ? 'selected' : '' }}>পুরুষ</option>
                        <option value="মহিলা" {{ old('gender') == 'মহিলা' ? 'selected' : '' }}>মহিলা</option>
                        <option value="অন্যান্য" {{ old('gender') == 'অন্যান্য' ? 'selected' : '' }}>অন্যান্য</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">জন্ম তারিখ</label>
                    <input type="date" name="date_of_birth" value="{{ old('date_of_birth') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">রক্তের গ্রুপ</label>
                    <input type="text" name="blood_group" value="{{ old('blood_group') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">ধর্ম</label>
                    <input type="text" name="religion" value="{{ old('religion') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">জাতীয় পরিচয়পত্র নম্বর</label>
                    <input type="text" name="nid_number" value="{{ old('nid_number') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">মোবাইল নম্বর</label>
                    <input type="text" name="mobile_number" value="{{ old('mobile_number') }}" required class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">ইমেইল</label>
                    <input type="email" name="email" value="{{ old('email') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">বর্তমান ঠিকানা</label>
                    <textarea name="present_address" class="w-full border rounded-lg px-3 py-2">{{ old('present_address') }}</textarea>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">স্থায়ী ঠিকানা</label>
                    <textarea name="permanent_address" class="w-full border rounded-lg px-3 py-2">{{ old('permanent_address') }}</textarea>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">প্রোফাইল ফটো</label>
                    <input type="file" name="profile_photo" class="w-full border rounded-lg px-3 py-2" />
                </div>
            </div>

            <!-- Official Info -->
            <hr class="my-6 border-t" />

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">যোগদানের তারিখ</label>
                    <input type="date" name="joining_date" value="{{ old('joining_date') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">কর্মসংস্থানের ধরন</label>
                    <input type="text" name="employment_type" value="{{ old('employment_type') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">স্টাফ আইডি</label>
                    <input type="text" name="staff_id" value="{{ old('staff_id') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">অভিজ্ঞতা</label>
                    <input type="text" name="experience" value="{{ old('experience') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">কাজের শিফট</label>
                    <input type="text" name="working_shift" value="{{ old('working_shift') }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">দায়িত্ব / কাজের বিবরণ</label>
                    <textarea name="job_description" class="w-full border rounded-lg px-3 py-2">{{ old('job_description') }}</textarea>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">স্ট্যাটাস</label>
                    <select name="status" required class="w-full border rounded-lg px-3 py-2">
                        <option value="">নির্বাচন করুন</option>
                        <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>সক্রিয়</option>
                        <option value="inactive" {{ old('status') == 'inactive' ? 'selected' : '' }}>নিষ্ক্রিয়</option>
                        <option value="retired" {{ old('status') == 'retired' ? 'selected' : '' }}>অবসরপ্রাপ্ত</option>
                    </select>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">জাতীয় পরিচয়পত্র স্ক্যান (PDF/ছবি)</label>
                    <input type="file" name="nid_scan" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">যোগদানের পত্র (PDF/ছবি)</label>
                    <input type="file" name="joining_letter" class="w-full border rounded-lg px-3 py-2" />
                </div>
            </div>

            <div class="mt-6 flex justify-end space-x-3">
                <a href="{{ route('admin.staffs.index') }}" class="px-4 py-2 bg-gray-400 rounded hover:bg-gray-500">বাতিল</a>
                <button type="submit" class="px-4 py-2 bg-white text-black border border-green-600 rounded hover:shadow-md hover:border-green-700 transition duration-200">
    সেভ করুন
</button>

            </div>
        </form>
    </div>
</div>
@endsection
