@extends('layouts.adminapp')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">
    <!-- Header -->
    <div class="bg-purple-100 p-6 rounded-lg shadow-md mb-6 border border-purple-300">
        <h1 class="text-3xl font-bold text-gray-900 mb-2 text-center">🧑‍💼 স্টাফ তালিকা</h1>
        <p class="text-gray-800 text-center">স্টাফ তথ্য এখানে পরিচালনা করুন — সার্চ, যোগ, সম্পাদনা বা মুছে ফেলুন।</p>
    </div>

    <!-- Success Message -->
    @if(session('success'))
        <div class="bg-green-100 border border-green-300 text-gray-900 px-4 py-3 rounded mb-4 shadow">
            {{ session('success') }}
        </div>
    @endif

    <!-- Search + Action Buttons -->
    <div class="bg-white p-6 rounded-lg shadow mb-6 border border-gray-200">
        <form method="GET" action="{{ route('admin.staffs.index') }}" class="md:flex md:items-center md:gap-4 flex-wrap">
            <input type="text" name="search" placeholder="🔍 নাম, পদবী বা মোবাইল নম্বর অনুসন্ধান করুন"
                   value="{{ request('search') }}"
                   class="flex-grow border border-gray-300 rounded-md px-4 py-2 mb-2 md:mb-0 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-300 text-gray-900" />
            <div class="flex items-center gap-3 flex-wrap mt-2 md:mt-0">
                <button type="submit"
                        class="bg-white border border-purple-600 text-purple-600 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-purple-600 hover:text-white transition">
                    🔍 সার্চ
                </button>
                <a href="{{ route('admin.staffs.index') }}"
                   class="bg-white border border-yellow-400 text-yellow-500 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-yellow-400 hover:text-white transition">
                    🔁 রিসেট
                </a>
                <a href="{{ route('admin.staffs.create') }}"
                   class="bg-white border border-green-600 text-green-600 font-semibold px-4 py-2 rounded-md shadow-sm hover:bg-green-600 hover:text-white transition">
                    ➕ নতুন স্টাফ
                </a>
            </div>
        </form>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
        <table class="min-w-full table-auto border border-gray-300 rounded-lg overflow-hidden shadow-md">
            <thead class="bg-purple-200 text-gray-900 text-sm uppercase">
                <tr>
                    <th class="px-4 py-2 border">ছবি</th>
                    <th class="px-4 py-2 border">নাম</th>
                    <th class="px-4 py-2 border">পদবী</th>
                    <th class="px-4 py-2 border">মোবাইল</th>
                    <th class="px-4 py-2 border">NID</th>
                    <th class="px-4 py-2 border">যোগপত্র</th>
                    <th class="px-4 py-2 border">স্ট্যাটাস</th>
                    <th class="px-4 py-2 border">অ্যাকশন</th>
                </tr>
            </thead>
            <tbody class="bg-white text-gray-900">
                @forelse($staffs as $staff)
                    <tr class="hover:bg-purple-50 transition">
                        <!-- Profile Photo -->
                        <td class="px-4 py-2 border text-center align-middle" style="width: 60px;">
                            @if($staff->profile_photo)
                                <div style="width: 50px; height: 50px; margin: auto; overflow: hidden; border-radius: 50%; border: 1px solid #ccc;">
                                    <img src="{{ asset('storage/'.$staff->profile_photo) }}" alt="Photo"
                                         style="width: 100%; height: 100%; object-fit: cover;">
                                </div>
                            @else
                                <span class="text-gray-400 text-sm">N/A</span>
                            @endif
                        </td>

                        <td class="px-4 py-2 border">{{ $staff->name }}</td>
                        <td class="px-4 py-2 border">{{ $staff->designation }}</td>
                        <td class="px-4 py-2 border">{{ $staff->mobile_number }}</td>

                        <!-- NID -->
                        <td class="px-4 py-2 border text-center">
                            @if($staff->nid_scan)
                                <a href="{{ asset('storage/'.$staff->nid_scan) }}" target="_blank"
                                   class="text-blue-600 hover:underline text-sm">ডাউনলোড</a>
                            @else
                                <span class="text-gray-400 text-sm">N/A</span>
                            @endif
                        </td>

                        <!-- Joining Letter -->
                        <td class="px-4 py-2 border text-center">
                            @if($staff->joining_letter)
                                <a href="{{ asset('storage/'.$staff->joining_letter) }}" target="_blank"
                                   class="text-green-600 hover:underline text-sm">ডাউনলোড</a>
                            @else
                                <span class="text-gray-400 text-sm">N/A</span>
                            @endif
                        </td>

                        <!-- Status -->
                        <td class="px-4 py-2 border">
                            <span class="inline-block px-3 py-1 rounded-full text-black text-xs font-semibold {{ $staff->status == 'কর্মরত' ? 'bg-green-600' : 'bg-red-600' }}">
                                {{ $staff->status }}
                            </span>
                        </td>

                        <!-- Actions -->
                        <td class="px-4 py-2 border space-x-1 text-center">
                            <a href="{{ route('admin.staffs.edit', $staff) }}"
                               class="bg-sky-100 border border-sky-500 text-sky-700 px-2 py-1 text-xs rounded hover:bg-sky-600 hover:text-white transition">
                                ✏️
                            </a>
                            <form action="{{ route('admin.staffs.destroy', $staff) }}" method="POST" class="inline"
                                  onsubmit="return confirm('আপনি কি নিশ্চিত মুছে ফেলতে চান?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit"
                                        class="bg-rose-100 border border-rose-500 text-rose-700 px-2 py-1 text-xs rounded hover:bg-rose-600 hover:text-white transition">
                                    🗑️
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" class="text-center py-4 text-gray-600">কোনো স্টাফ পাওয়া যায়নি।</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        {{ $staffs->withQueryString()->links() }}
    </div>
</div>
@endsection
