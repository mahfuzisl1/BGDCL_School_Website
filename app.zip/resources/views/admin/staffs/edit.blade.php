@extends('layouts.adminapp')

@section('content')
<div class="max-w-5xl mx-auto p-6">
    <div class="bg-white shadow-lg rounded-xl p-6">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">স্টাফ তথ্য সম্পাদনা করুন</h2>

        @if ($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <ul class="list-disc pl-5 text-sm">
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        <form action="{{ route('admin.staffs.update', $staff->id) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
            @csrf
            @method('PUT')

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">নাম (পূর্ণ নাম)</label>
                    <input type="text" name="name" value="{{ old('name', $staff->name) }}" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-blue-300" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">পদবী</label>
                    <input type="text" name="designation" value="{{ old('designation', $staff->designation) }}" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-blue-300" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">লিঙ্গ</label>
                    <select name="gender" required class="w-full border rounded-lg px-3 py-2">
                        <option value="">নির্বাচন করুন</option>
                        <option value="পুরুষ" {{ old('gender', $staff->gender) == 'পুরুষ' ? 'selected' : '' }}>পুরুষ</option>
                        <option value="মহিলা" {{ old('gender', $staff->gender) == 'মহিলা' ? 'selected' : '' }}>মহিলা</option>
                        <option value="অন্যান্য" {{ old('gender', $staff->gender) == 'অন্যান্য' ? 'selected' : '' }}>অন্যান্য</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">জন্ম তারিখ</label>
                    <input type="date" name="date_of_birth" value="{{ old('date_of_birth', $staff->date_of_birth) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">রক্তের গ্রুপ</label>
                    <input type="text" name="blood_group" value="{{ old('blood_group', $staff->blood_group) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">ধর্ম</label>
                    <input type="text" name="religion" value="{{ old('religion', $staff->religion) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">জাতীয় পরিচয়পত্র নম্বর</label>
                    <input type="text" name="nid_number" value="{{ old('nid_number', $staff->nid_number) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">মোবাইল নম্বর</label>
                    <input type="text" name="mobile_number" value="{{ old('mobile_number', $staff->mobile_number) }}" required class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">ইমেইল</label>
                    <input type="email" name="email" value="{{ old('email', $staff->email) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">বর্তমান ঠিকানা</label>
                    <textarea name="present_address" class="w-full border rounded-lg px-3 py-2">{{ old('present_address', $staff->present_address) }}</textarea>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">স্থায়ী ঠিকানা</label>
                    <textarea name="permanent_address" class="w-full border rounded-lg px-3 py-2">{{ old('permanent_address', $staff->permanent_address) }}</textarea>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">বর্তমান প্রোফাইল ফটো</label>
                    @if($staff->profile_photo)
                        <img src="{{ asset('storage/'.$staff->profile_photo) }}" alt="Profile Photo" class="w-24 h-24 object-cover rounded mb-2" />
                    @else
                        <p>কোন প্রোফাইল ফটো নেই</p>
                    @endif
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">নতুন প্রোফাইল ফটো (আপডেট করতে)</label>
                    <input type="file" name="profile_photo" class="w-full border rounded-lg px-3 py-2" />
                </div>
            </div>

            <hr class="my-6 border-t" />

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">যোগদানের তারিখ</label>
                    <input type="date" name="joining_date" value="{{ old('joining_date', $staff->joining_date) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">কর্মসংস্থানের ধরন</label>
                    <input type="text" name="employment_type" value="{{ old('employment_type', $staff->employment_type) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">স্টাফ আইডি</label>
                    <input type="text" name="staff_id" value="{{ old('staff_id', $staff->staff_id) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">অভিজ্ঞতা</label>
                    <input type="text" name="experience" value="{{ old('experience', $staff->experience) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">কাজের শিফট</label>
                    <input type="text" name="working_shift" value="{{ old('working_shift', $staff->working_shift) }}" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">দায়িত্ব / কাজের বিবরণ</label>
                    <textarea name="job_description" class="w-full border rounded-lg px-3 py-2">{{ old('job_description', $staff->job_description) }}</textarea>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">স্ট্যাটাস</label>
                    <select name="status" required class="w-full border rounded-lg px-3 py-2">
                        <option value="">নির্বাচন করুন</option>
                        <option value="active" {{ old('status', $staff->status) == 'active' ? 'selected' : '' }}>সক্রিয়</option>
                        <option value="inactive" {{ old('status', $staff->status) == 'inactive' ? 'selected' : '' }}>নিষ্ক্রিয়</option>
                        <option value="retired" {{ old('status', $staff->status) == 'retired' ? 'selected' : '' }}>অবসরপ্রাপ্ত</option>
                    </select>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">বর্তমান জাতীয় পরিচয়পত্র স্ক্যান</label>
                    @if($staff->nid_scan)
                        <a href="{{ asset('storage/'.$staff->nid_scan) }}" target="_blank" class="text-blue-600 hover:underline">ফাইল দেখুন</a>
                    @else
                        <p>কোন ফাইল পাওয়া যায়নি</p>
                    @endif
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">নতুন জাতীয় পরিচয়পত্র স্ক্যান (আপডেট করতে)</label>
                    <input type="file" name="nid_scan" class="w-full border rounded-lg px-3 py-2" />
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">বর্তমান যোগদানের পত্র</label>
                    @if($staff->joining_letter)
                        <a href="{{ asset('storage/'.$staff->joining_letter) }}" target="_blank" class="text-blue-600 hover:underline">ফাইল দেখুন</a>
                    @else
                        <p>কোন ফাইল পাওয়া যায়নি</p>
                    @endif
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">নতুন যোগদানের পত্র (আপডেট করতে)</label>
                    <input type="file" name="joining_letter" class="w-full border rounded-lg px-3 py-2" />
                </div>
            </div>

            <div class="mt-6 flex justify-end space-x-3">
                <a href="{{ route('admin.staffs.index') }}" class="px-4 py-2 bg-gray-400 rounded hover:bg-gray-500">বাতিল</a>
                <button type="submit" class="px-4 py-2 bg-green-600 text-black rounded hover:bg-green-700">সেভ করুন</button>
            </div>
        </form>
    </div>
</div>
@endsection
