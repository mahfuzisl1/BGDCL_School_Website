@extends('layouts.adminapp')

@section('content')
<div class="container mx-auto p-4 max-w-xl">
    <h2 class="text-xl font-bold mb-4">Edit Class Materials for Class {{ $class }}</h2>

    @if ($errors->any())
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <ul class="list-disc pl-5">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.classmaterials.update', ['classmaterial' => $class]) }}" method="POST" enctype="multipart/form-data" class="space-y-4">
        @csrf
        @method('PUT')

        <div>
            <label for="class" class="block font-semibold mb-1">Class</label>
            <select name="class" id="class" class="form-select w-full border rounded px-3 py-2">
                @foreach(range(1,10) as $c)
                    <option value="{{ $c }}" @selected($class == $c)>{{ 'Class ' . $c }}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label class="block font-semibold mt-4 mb-1">Current Routine File:</label>
            @if($routineFile)
                <a href="{{ asset('classmaterials/' . $routineFile) }}" target="_blank" class="text-blue-600 hover:underline">
                    {{ $routineFile }}
                </a>
            @else
                <span class="text-gray-400 italic">No routine file uploaded</span>
            @endif
        </div>

        <div>
            <label for="routine_file" class="block font-semibold mt-2 mb-1">Replace Routine File (optional)</label>
            <input type="file" name="routine_file" id="routine_file" class="form-input w-full border rounded px-3 py-2" accept=".pdf,.jpg,.jpeg,.png">
        </div>

        <div>
            <label class="block font-semibold mt-4 mb-1">Current Syllabus File:</label>
            @if($syllabusFile)
                <a href="{{ asset('classmaterials/' . $syllabusFile) }}" target="_blank" class="text-blue-600 hover:underline">
                    {{ $syllabusFile }}
                </a>
            @else
                <span class="text-gray-400 italic">No syllabus file uploaded</span>
            @endif
        </div>

        <div>
            <label for="syllabus_file" class="block font-semibold mt-2 mb-1">Replace Syllabus File (optional)</label>
            <input type="file" name="syllabus_file" id="syllabus_file" class="form-input w-full border rounded px-3 py-2" accept=".pdf,.jpg,.jpeg,.png">
        </div>

        <button type="submit" class="bg-blue-500 text-black px-4 py-2 rounded hover:bg-blue-600 transition">
            Update Materials
        </button>
    </form>
</div>
@endsection
