@extends('layouts.adminapp')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">

    <!-- Header -->
    <div class="bg-purple-100 p-6 rounded-lg shadow-md mb-6 border border-purple-300">
        <h1 class="text-3xl font-bold text-gray-900 mb-2 text-center">📚 Class Materials</h1>
        <p class="text-gray-800 text-center">Manage class routines and syllabuses — search, upload, edit, or delete.</p>
    </div>

    <!-- Success & Error Messages -->
    @if(session('success'))
        <div class="bg-green-100 border border-green-300 text-green-900 px-4 py-3 rounded mb-4 shadow">
            {{ session('success') }}
        </div>
    @endif
    @if(session('error'))
        <div class="bg-red-100 border border-red-300 text-red-900 px-4 py-3 rounded mb-4 shadow">
            {{ session('error') }}
        </div>
    @endif

    <!-- Search + Upload Button -->
    <div class="bg-white p-6 rounded-lg shadow mb-6 border border-gray-200 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <form method="GET" action="{{ route('admin.classmaterials.index') }}" class="flex flex-wrap items-center gap-2">
            <input
                type="text"
                name="search"
                placeholder="🔍 Search by class"
                value="{{ request('search') }}"
                class="border border-gray-300 rounded-md px-4 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-300 text-gray-900"
            />
            <button type="submit"
                    class="bg-purple-600 text-black font-semibold px-4 py-2 rounded-md shadow hover:bg-purple-700 transition">
                Search
            </button>
            <a href="{{ route('admin.classmaterials.index') }}"
               class="bg-gray-300 text-gray-900 font-semibold px-4 py-2 rounded-md shadow hover:bg-gray-400 transition">
                Reset
            </a>
        </form>

        <a href="{{ route('admin.classmaterials.create') }}"
           class="bg-green-600 text-black font-semibold px-4 py-2 rounded-md shadow hover:bg-green-700 transition text-center whitespace-nowrap">
            ➕ Upload New Materials
        </a>
    </div>

    <!-- Table -->
    @if($materials->isEmpty())
        <p class="text-gray-500 text-center">No class materials found.</p>
    @else
        <div class="overflow-x-auto rounded-lg shadow-md border border-gray-300">
            <table class="min-w-full table-auto text-gray-900 text-sm">
                <thead class="bg-gray-100 uppercase font-semibold text-gray-700">
                    <tr>
                        <th class="border border-gray-300 px-4 py-3 text-left">Class</th>
                        <th class="border border-gray-300 px-4 py-3 text-left">Routine File</th>
                        <th class="border border-gray-300 px-4 py-3 text-left">Syllabus File</th>
                        <th class="border border-gray-300 px-4 py-3 text-left">Uploaded At</th>
                        <th class="border border-gray-300 px-4 py-3 text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($materials as $material)
                        <tr class="hover:bg-purple-50 transition">
                            <td class="border border-gray-300 px-4 py-2 font-semibold">Class {{ $material['class'] }}</td>

                            <td class="border border-gray-300 px-4 py-2">
                                @if($material['routine_url'])
                                    <a href="{{ $material['routine_url'] }}" target="_blank" class="text-blue-600 hover:underline">
                                        {{ $material['routine'] }}
                                    </a>
                                    <br>
                                    <small class="text-gray-500">({{ $material['routine_uploaded_at'] }})</small>
                                @else
                                    <span class="text-gray-400 italic">No routine file</span>
                                @endif
                            </td>

                            <td class="border border-gray-300 px-4 py-2">
                                @if($material['syllabus_url'])
                                    <a href="{{ $material['syllabus_url'] }}" target="_blank" class="text-blue-600 hover:underline">
                                        {{ $material['syllabus'] }}
                                    </a>
                                    <br>
                                    <small class="text-gray-500">({{ $material['syllabus_uploaded_at'] }})</small>
                                @else
                                    <span class="text-gray-400 italic">No syllabus file</span>
                                @endif
                            </td>

                            <td class="border border-gray-300 px-4 py-2 text-center">
                                {{-- Show last updated time for either file --}}
                                @php
                                    $dates = array_filter([$material['routine_uploaded_at'], $material['syllabus_uploaded_at']]);
                                    echo $dates ? max($dates) : '-';
                                @endphp
                            </td>

                            <td class="border border-gray-300 px-4 py-2 text-center space-x-2">
                                <a href="{{ route('admin.classmaterials.edit', ['classmaterial' => $material['class']]) }}"
                                   class="bg-yellow-400 text-black px-3 py-1 rounded hover:bg-yellow-500 transition">
                                    ✏️ Edit
                                </a>

                                <form action="{{ route('admin.classmaterials.destroy', ['classmaterial' => $material['class']]) }}"
                                      method="POST" class="inline"
                                      onsubmit="return confirm('Are you sure you want to delete materials for Class {{ $material['class'] }}?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"
                                            class="bg-red-500 text-black px-3 py-1 rounded hover:bg-red-600 transition">
                                        🗑️ Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
</div>
@endsection
