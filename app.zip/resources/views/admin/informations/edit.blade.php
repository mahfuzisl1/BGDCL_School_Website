@extends('layouts.adminapp')

@section('content')
<div class="container">
    <h2>Edit {{ ucfirst($section) }}</h2>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.informations.update', $section) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="form-group mb-3">
            <label for="content">Content (optional)</label>
            <textarea name="content" id="content" class="form-control" rows="6">{{ old('content', $content) }}</textarea>
        </div>

        <div class="form-group mb-3">
            <label for="file">Upload File (image/pdf, max 5MB)</label>
            <input type="file" name="file" class="form-control">
            
            @if($fileUrl)
                <p class="mt-2">
                    Current File: <a href="{{ $fileUrl }}" target="_blank">{{ $fileName }}</a>
                </p>
            @endif
        </div>

        <button type="submit" class="btn btn-success">Save</button>
        <a href="{{ route('admin.informations.index') }}" class="btn btn-secondary">Cancel</a>
    </form>
</div>
@endsection
