@extends('layouts.adminapp')

@section('content')
<div class="container">
    <h2>Informations</h2>

    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="row">
        @foreach($data as $section => $info)
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <strong>{{ ucfirst($section) }}</strong>
                        <a href="{{ route('admin.informations.edit', $section) }}" class="btn btn-sm btn-primary">Edit</a>
                    </div>
                    <div class="card-body">
                        <p><strong>Content:</strong></p>
                        <p>{{ Str::limit(strip_tags($info['content']), 100, '...') ?? 'No content' }}</p>

                        <p><strong>File:</strong></p>
                        @if($info['file_url'])
                            <a href="{{ $info['file_url'] }}" target="_blank">{{ $info['file'] }}</a>
                            <br>
                            <a href="{{ route('admin.informations.download', $section) }}" class="btn btn-sm btn-secondary mt-2">Download</a>
                        @else
                            <p>No file uploaded.</p>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
