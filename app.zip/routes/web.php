<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\PublicNoticeController;
use App\Http\Controllers\PublicGalleryController;
use App\Http\Controllers\PublicContactInfoController;
use App\Http\Controllers\PublicTeacherController;
use App\Http\Controllers\PublicStaffController;
use App\Http\Controllers\PublicStudentController;
use App\Http\Controllers\PublicExamFileController;
use App\Http\Controllers\NoticeController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\ContactInfoController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\TeacherController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\PublicResultController;
use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ResultController;
use App\Http\Controllers\ExamFileController;
use App\Http\Controllers\ClassMaterialController;
use App\Http\Controllers\InformationController;

// ✅ Homepage
Route::get('/', [HomeController::class, 'index'])->name('home');

// ✅ Public Routes (Visitors)
Route::prefix('public')->name('public.')->group(function () {
    // Notices
    Route::get('notices', [PublicNoticeController::class, 'index'])->name('notices.index');
    Route::get('notices/{notice}', [PublicNoticeController::class, 'show'])->name('notices.show');

    // Gallery
    Route::get('gallery', [PublicGalleryController::class, 'index'])->name('gallery.index');
    Route::get('gallery/{gallery}', [PublicGalleryController::class, 'show'])->name('gallery.show');

    // Contact Info
    Route::get('contactinfo', [PublicContactInfoController::class, 'index'])->name('contactinfo.index');

    // Teachers
    Route::get('teachers', [PublicTeacherController::class, 'index'])->name('teachers.index');
    Route::get('teachers/{teacher}', [PublicTeacherController::class, 'show'])->name('teachers.show');

    // Staffs
    Route::get('staffs', [PublicStaffController::class, 'index'])->name('staffs.index');
    Route::get('staffs/{staff}', [PublicStaffController::class, 'show'])->name('staffs.show');

    // Students
    Route::get('students', [PublicStudentController::class, 'publicIndex'])->name('students.index');

    // Class Materials
    Route::get('classmaterials', [ClassMaterialController::class, 'publicIndex'])->name('classmaterials.index');

    // ✅ Informations (Public)
    Route::get('informations', [InformationController::class, 'publicIndex'])->name('informations.index'); // <-- Added Index
    Route::get('informations/{section}', [InformationController::class, 'showPublic'])->name('informations.showPublic');
    Route::get('informations/{section}/download', [InformationController::class, 'publicDownload'])->name('informations.publicDownload');

    Route::get('/exam-schedules', [PublicExamFileController::class, 'index'])->name('examfiles.index');

    Route::get('/results', [PublicResultController::class, 'index'])->name('results.index');

});

// ✅ Admin Routes
Route::prefix('admin')->name('admin.')->group(function () {
    // Admin Login
    Route::get('login', [AdminAuthController::class, 'showLoginForm'])->name('login');
    Route::post('login', [AdminAuthController::class, 'login'])->name('login.submit');
    Route::post('logout', [AdminAuthController::class, 'logout'])->name('logout');

    // Protected Admin Panel Routes (Requires Auth)
    Route::middleware(['auth:admin'])->group(function () {
        // Dashboard
        Route::get('dashboard', function () {
            return view('admin.dashboard');
        })->name('dashboard');

        // Resource Controllers
        Route::resource('notices', NoticeController::class);
        Route::resource('gallery', GalleryController::class);
        Route::resource('contactinfo', ContactInfoController::class)->only(['index', 'edit', 'update']);
        Route::resource('students', StudentController::class);
        Route::resource('teachers', TeacherController::class);
        Route::resource('staffs', StaffController::class);
        Route::resource('results', ResultController::class);
        Route::resource('classmaterials', ClassMaterialController::class);

        // ✅ Informations (Admin Panel)
        Route::prefix('informations')->name('informations.')->group(function () {
            Route::get('/', [InformationController::class, 'index'])->name('index');
            Route::get('{section}/edit', [InformationController::class, 'edit'])->name('edit');
            Route::put('{section}', [InformationController::class, 'update'])->name('update');
            Route::get('{section}/download', [InformationController::class, 'downloadFile'])->name('download');
        });

        // ✅ Exam Files (Admin Panel)
        Route::prefix('examfiles')->name('examfiles.')->group(function () {
            Route::get('/', [ExamFileController::class, 'index'])->name('index');
            Route::get('/create', [ExamFileController::class, 'create'])->name('create');
            Route::post('/', [ExamFileController::class, 'store'])->name('store');
            Route::get('/{filename}/edit', [ExamFileController::class, 'edit'])->name('edit');
            Route::put('/{filename}', [ExamFileController::class, 'update'])->name('update');
            Route::delete('/{filename}', [ExamFileController::class, 'destroy'])->name('destroy');
        });
    });
});
