<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id();
            $table->string('student_id')->unique();
            $table->string('name');
            $table->unsignedTinyInteger('class'); // 1–10
            $table->enum('section', ['A', 'B', 'C', 'D'])->nullable();
            $table->unsignedSmallInteger('roll')->nullable();
            $table->date('admission_date')->nullable();
            $table->date('dob');
            $table->enum('gender', ['Male', 'Female', 'Other']);
            $table->string('blood_group')->nullable();
            $table->string('religion')->nullable();
            $table->string('nid_or_birth_cert')->nullable();
            $table->string('guardian_name')->nullable();
            $table->string('father_name');
            $table->string('mother_name');
            $table->string('mobile')->nullable();
            $table->string('email')->nullable();
            $table->text('present_address')->nullable();
            $table->text('permanent_address')->nullable();
            $table->string('previous_school')->nullable();
            $table->string('transfer_certificate')->nullable(); // File path
            $table->enum('group', ['Science', 'Commerce', 'Arts'])->nullable();
            $table->text('exam_records')->nullable();
            $table->string('photo')->nullable(); // Profile photo
            $table->string('birth_certificate')->nullable();
            $table->string('admission_form')->nullable();
            $table->string('additional_documents')->nullable(); // Extra files
            $table->enum('status', ['Active', 'Inactive', 'Transferred', 'Dropped Out'])->default('Active');
            $table->text('remarks')->nullable();
            $table->text('special_note')->nullable(); // ✅ New field
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('students');
    }
};

