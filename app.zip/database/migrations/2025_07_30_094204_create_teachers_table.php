<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('teachers', function (Blueprint $table) {
            $table->id();

            $table->string('teacher_id')->unique();
            $table->string('full_name');
            $table->string('designation');
            $table->string('department')->nullable();
            $table->json('subjects');
            $table->string('gender');
            $table->date('dob');
            $table->string('religion');
            $table->string('blood_group')->nullable();
            $table->date('joining_date');
            $table->string('national_id');

            $table->string('mobile');
            $table->string('email')->nullable();
            $table->string('emergency_contact')->nullable();
            $table->text('present_address');
            $table->text('permanent_address');

            $table->string('highest_qualification');
            $table->json('professional_degrees')->nullable();
            $table->integer('experience_years')->default(0);
            $table->text('previous_institutions')->nullable();
            $table->text('special_skills')->nullable();

            $table->string('employment_status')->default('Active');
            $table->text('remarks')->nullable();

            $table->boolean('is_class_teacher')->default(false);
            $table->string('class_teacher_of')->nullable();

            // File uploads - store file paths
            $table->string('profile_photo')->nullable();
            $table->string('cv_attachment')->nullable();
            $table->json('certificates_attachment')->nullable(); // multiple files as json array
            $table->string('nid_attachment')->nullable();
            $table->string('joining_letter')->nullable();
            $table->string('other_documents')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('teachers');
    }
};
