<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   public function up(): void
{
    Schema::create('notices', function (Blueprint $table) {
        $table->id();
        $table->string('title');
        $table->text('content');
        $table->date('publish_date');
        $table->string('status')->default('draft'); // draft, published, archived
        $table->string('attachment')->nullable();
        $table->string('category')->nullable(); // Exam, Holiday, etc.
        $table->string('class')->nullable();    // Class 1–10 or All
        $table->string('section')->nullable();  // A, B, C, D or All
        $table->boolean('is_pinned')->default(false);
        $table->timestamps();
    });
}




    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('notices');
    }
};
