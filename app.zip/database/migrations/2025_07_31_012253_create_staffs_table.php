<?php

// database/migrations/xxxx_xx_xx_create_staffs_table.php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStaffsTable extends Migration
{
    public function up()
    {
        Schema::create('staffs', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('designation');
            $table->string('gender', 20);
            $table->date('date_of_birth')->nullable();
            $table->string('blood_group', 10)->nullable();
            $table->string('religion', 50)->nullable();
            $table->string('nid_number', 100)->nullable();
            $table->string('mobile_number', 20);
            $table->string('email')->nullable();
            $table->text('present_address')->nullable();
            $table->text('permanent_address')->nullable();
            $table->string('profile_photo')->nullable();
            $table->date('joining_date')->nullable();
            $table->string('employment_type', 50)->nullable();
            $table->string('staff_id', 100)->nullable();
            $table->string('experience')->nullable();
            $table->string('working_shift', 50)->nullable();
            $table->text('job_description')->nullable();
            $table->string('status', 50);
            $table->string('nid_scan')->nullable();
            $table->string('joining_letter')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('staffs');
    }
}
